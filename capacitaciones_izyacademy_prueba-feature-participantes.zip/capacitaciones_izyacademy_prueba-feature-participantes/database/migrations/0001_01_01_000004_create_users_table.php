<?php

// Crea la tabla de usuarios y sus credenciales corporativas.

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Crea la estructura de usuarios y sus índices.
     */
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->foreignId('role_id')->constrained('roles')->onDelete('restrict');
            $table->string('name');
            $table->string('email')->unique();
            $table->string('password');
            $table->boolean('is_active')->default(true);
            $table->rememberToken();
            $table->timestamps();

            // Índices de optimización de consultas
            $table->index('role_id');
            $table->index('email');
            $table->index('is_active');
            $table->index(['role_id', 'is_active']);
        });
    }

    /**
     * Elimina la tabla de usuarios al revertir la migración.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};

<?php

// Crea la tabla principal de capacitaciones del catálogo.

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Crea campos, relaciones y opciones de publicación de capacitaciones.
     */
    public function up(): void
    {
        Schema::create('trainings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('category_id')->constrained('training_categories')->onDelete('restrict');
            $table->foreignId('created_by_user_id')->constrained('users')->onDelete('restrict');
            $table->string('title');
            $table->text('description');
            $table->string('expert_name');
            $table->string('expert_avatar_url')->nullable();
            $table->unsignedInteger('duration_hours');
            $table->text('schedule_details');
            $table->boolean('is_public_for_externals')->default(true);
            $table->boolean('has_certificate')->default(false);
            $table->string('certificate_template_url')->nullable();
            $table->timestamps();

            // Índices de optimización y búsqueda
            $table->index('category_id');
            $table->index('created_by_user_id');
            $table->index('is_public_for_externals');
            $table->index('has_certificate');
            $table->index(['category_id', 'is_public_for_externals']);
            $table->index('title');
        });
    }

    /**
     * Elimina la tabla de capacitaciones.
     */
    public function down(): void
    {
        Schema::dropIfExists('trainings');
    }
};

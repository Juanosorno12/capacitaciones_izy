<?php

// Agrega el permiso de consulta del calendario.

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /** Registra y asigna el permiso de calendario. */
    public function up(): void
    {
        DB::table('permissions')->updateOrInsert(
            ['name' => 'calendar.view'],
            [
                'module_group' => 'Capacitaciones',
                'description' => 'Consultar el calendario de sesiones programadas de capacitación.',
                'created_at' => now(),
                'updated_at' => now(),
            ]
        );

        $adminRoleId = DB::table('roles')->where('slug', 'administrador')->value('id');
        $permissionId = DB::table('permissions')->where('name', 'calendar.view')->value('id');

        if ($adminRoleId && $permissionId) {
            DB::table('role_has_permissions')->insertOrIgnore([
                'role_id' => $adminRoleId,
                'permission_id' => $permissionId,
            ]);

            DB::table('users')
                ->where('role_id', $adminRoleId)
                ->pluck('id')
                ->each(fn ($userId) => Cache::forget("user_effective_permissions_{$userId}"));
        }

        Cache::forget('catalog_permissions_grouped');
    }

    /** Revierte la asignación y elimina el permiso. */
    public function down(): void
    {
        $permissionId = DB::table('permissions')->where('name', 'calendar.view')->value('id');

        if (!$permissionId) {
            return;
        }

        DB::table('role_has_permissions')->where('permission_id', $permissionId)->delete();
        DB::table('user_has_permissions')->where('permission_id', $permissionId)->delete();
        DB::table('permissions')->where('id', $permissionId)->delete();
        Cache::forget('catalog_permissions_grouped');
    }
};

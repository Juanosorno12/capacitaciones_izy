<?php

// Agrega el indicador de valor agregado a solicitudes y programaciones.

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /** Añade el indicador utilizado para filtros y reportes. */
    public function up(): void
    {
        Schema::table('training_requests', function (Blueprint $table): void {
            $table->boolean('value_added')->default(false)->after('title');
            $table->index('value_added');
        });

        Schema::table('scheduled_trainings', function (Blueprint $table): void {
            $table->boolean('value_added')->default(false)->after('title');
            $table->index('value_added');
        });
    }

    /** Elimina el indicador de valor agregado. */
    public function down(): void
    {
        Schema::table('scheduled_trainings', function (Blueprint $table): void {
            $table->dropIndex(['value_added']);
            $table->dropColumn('value_added');
        });

        Schema::table('training_requests', function (Blueprint $table): void {
            $table->dropIndex(['value_added']);
            $table->dropColumn('value_added');
        });
    }
};

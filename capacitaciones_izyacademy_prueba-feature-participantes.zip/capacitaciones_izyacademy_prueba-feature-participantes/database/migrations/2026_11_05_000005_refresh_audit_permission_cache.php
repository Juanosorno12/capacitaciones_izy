<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        $roleId = DB::table('roles')->where('slug', 'administrador')->value('id');
        $permissionId = DB::table('permissions')->where('name', 'audit-logs.view')->value('id');
        $userIds = $roleId
            ? DB::table('users')->where('role_id', $roleId)->pluck('id')
            : collect();

        if ($permissionId) {
            $userIds = $userIds->merge(
                DB::table('user_has_permissions')
                    ->where('permission_id', $permissionId)
                    ->pluck('user_id')
            );
        }

        foreach ($userIds->unique() as $userId) {
            Cache::forget("user_effective_permissions_{$userId}");
        }
    }

    public function down(): void
    {
    }
};

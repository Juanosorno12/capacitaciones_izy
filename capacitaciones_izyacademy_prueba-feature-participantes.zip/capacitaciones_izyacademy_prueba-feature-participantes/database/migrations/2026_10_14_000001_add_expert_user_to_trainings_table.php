<?php

// Vincula cada capacitación con un usuario experto opcional.

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /** Añade la relación entre capacitaciones y usuarios expertos. */
    public function up(): void
    {
        Schema::table('trainings', function (Blueprint $table) {
            $table->foreignId('expert_user_id')
                ->nullable()
                ->after('expert_name')
                ->constrained('users')
                ->nullOnDelete();
        });
    }

    /** Elimina la relación con el usuario experto. */
    public function down(): void
    {
        Schema::table('trainings', function (Blueprint $table) {
            $table->dropConstrainedForeignId('expert_user_id');
        });
    }
};

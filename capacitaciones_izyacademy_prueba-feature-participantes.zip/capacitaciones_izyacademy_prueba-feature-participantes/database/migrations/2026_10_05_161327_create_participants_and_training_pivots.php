<?php

// Crea participantes y sus relaciones con solicitudes y capacitaciones.

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /** Crea la tabla de participantes y las tablas intermedias. */
    public function up(): void
    {
        Schema::create('participants', function (Blueprint $table) {
            $table->id();
            $table->string('first_name', 100);
            $table->string('last_name', 150);
            $table->string('email')->unique();
            $table->string('phone', 30)->nullable();
            $table->timestamps();
        });

        Schema::create('participant_training_request', function (Blueprint $table) {
            $table->foreignId('participant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('training_request_id')->constrained()->cascadeOnDelete();
            $table->timestamps();
            $table->primary(['participant_id', 'training_request_id']);
            $table->index('training_request_id');
        });

        Schema::create('participant_training', function (Blueprint $table) {
            $table->foreignId('participant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('training_id')->constrained()->cascadeOnDelete();
            $table->timestamps();
            $table->primary(['participant_id', 'training_id']);
            $table->index('training_id');
        });
    }

    /** Elimina las tablas creadas por esta migración. */
    public function down(): void
    {
        Schema::dropIfExists('participant_training');
        Schema::dropIfExists('participant_training_request');
        Schema::dropIfExists('participants');
    }
};

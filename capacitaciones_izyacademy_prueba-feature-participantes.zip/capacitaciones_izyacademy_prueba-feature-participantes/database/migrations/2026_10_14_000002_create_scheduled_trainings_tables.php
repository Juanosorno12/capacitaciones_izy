<?php

// Crea capacitaciones programadas y sus sesiones independientes.

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /** Crea tablas, relaciones y horarios de capacitaciones programadas. */
    public function up(): void
    {
        Schema::create('scheduled_trainings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('training_id')->constrained('trainings')->restrictOnDelete();
            $table->foreignId('training_request_id')->nullable()->constrained('training_requests')->nullOnDelete();
            $table->foreignId('created_by_user_id')->constrained('users')->restrictOnDelete();
            $table->foreignId('expert_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('category_id')->constrained('training_categories')->restrictOnDelete();
            $table->string('title');
            $table->text('description');
            $table->string('expert_name')->nullable();
            $table->unsignedInteger('duration_hours');
            $table->text('schedule_details');
            $table->string('modality')->nullable();
            $table->boolean('is_public_for_externals')->default(true);
            $table->boolean('has_certificate')->default(false);
            $table->string('certificate_template_url')->nullable();
            $table->timestamps();

            $table->index(['training_id', 'training_request_id']);
            $table->index('category_id');
        });

        Schema::create('scheduled_training_sessions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('scheduled_training_id')->constrained()->cascadeOnDelete();
            $table->date('session_date');
            $table->time('start_time');
            $table->time('end_time');
            $table->timestamps();

            $table->index(['session_date', 'start_time']);
        });

        Schema::create('participant_scheduled_training', function (Blueprint $table) {
            $table->foreignId('participant_id')->constrained()->cascadeOnDelete();
            $table->foreignId('scheduled_training_id')->constrained()->cascadeOnDelete();
            $table->timestamps();
            $table->primary(['participant_id', 'scheduled_training_id']);
        });
    }

    /** Elimina tablas de capacitaciones programadas y sus sesiones. */
    public function down(): void
    {
        Schema::dropIfExists('participant_scheduled_training');
        Schema::dropIfExists('scheduled_training_sessions');
        Schema::dropIfExists('scheduled_trainings');
    }
};

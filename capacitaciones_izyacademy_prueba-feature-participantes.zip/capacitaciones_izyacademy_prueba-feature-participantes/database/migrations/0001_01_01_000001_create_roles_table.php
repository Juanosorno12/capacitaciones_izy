<?php

// Crea la tabla de roles utilizados para agrupar permisos de usuarios.

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Crea la estructura principal de roles.
     */
    public function up(): void
    {
        Schema::create('roles', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('slug')->unique();
            $table->string('description')->nullable();
            $table->timestamps();

            // Índices de optimización
            $table->index('slug');
        });
    }

    /**
     * Elimina la tabla de roles al revertir la migración.
     */
    public function down(): void
    {
        Schema::dropIfExists('roles');
    }
};

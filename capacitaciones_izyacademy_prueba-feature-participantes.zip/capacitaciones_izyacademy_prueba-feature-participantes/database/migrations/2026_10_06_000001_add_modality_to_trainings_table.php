<?php

// Agrega la modalidad de impartición a las capacitaciones.

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /** Añade el campo que distingue modalidad virtual y presencial. */
    public function up(): void
    {
        Schema::table('trainings', function (Blueprint $table) {
            $table->string('modality', 20)->nullable()->after('schedule_details');
        });
    }

    /** Elimina el campo de modalidad. */
    public function down(): void
    {
        Schema::table('trainings', function (Blueprint $table) {
            $table->dropColumn('modality');
        });
    }
};

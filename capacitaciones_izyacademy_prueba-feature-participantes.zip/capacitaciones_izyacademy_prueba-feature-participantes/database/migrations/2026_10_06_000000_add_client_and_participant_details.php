<?php

// Amplía solicitudes y participantes con datos del cliente y contacto.

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /** Agrega campos de cliente y datos adicionales de participantes. */
    public function up(): void
    {
        Schema::table('training_requests', function (Blueprint $table) {
            $table->string('client_name')->nullable()->after('title');
        });

        Schema::table('participants', function (Blueprint $table) {
            $table->string('personal_email')->nullable()->after('email');
            $table->string('city', 100)->nullable()->after('phone');
        });
    }

    /** Elimina los campos agregados en esta migración. */
    public function down(): void
    {
        Schema::table('participants', function (Blueprint $table) {
            $table->dropColumn(['personal_email', 'city']);
        });

        Schema::table('training_requests', function (Blueprint $table) {
            $table->dropColumn('client_name');
        });
    }
};

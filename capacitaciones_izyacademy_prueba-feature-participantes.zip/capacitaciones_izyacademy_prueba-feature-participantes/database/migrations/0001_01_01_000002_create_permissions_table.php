<?php

// Crea el catálogo de permisos funcionales del sistema.

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Crea la estructura del catálogo de permisos.
     */
    public function up(): void
    {
        Schema::create('permissions', function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique();
            $table->string('module_group');
            $table->string('description')->nullable();
            $table->timestamps();

            // Índices de búsqueda y agrupación masiva
            $table->index('name');
            $table->index('module_group');
        });
    }

    /**
     * Elimina la tabla de permisos al revertir la migración.
     */
    public function down(): void
    {
        Schema::dropIfExists('permissions');
    }
};

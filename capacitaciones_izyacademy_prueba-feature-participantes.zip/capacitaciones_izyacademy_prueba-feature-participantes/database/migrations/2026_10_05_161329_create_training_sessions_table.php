<?php

// Crea las sesiones con fecha y horario de cada capacitación.

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /** Crea la tabla de sesiones y su relación con capacitaciones. */
    public function up(): void
    {
        Schema::create('training_sessions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('training_id')->constrained()->cascadeOnDelete();
            $table->date('session_date');
            $table->time('start_time');
            $table->time('end_time');
            $table->timestamps();

            $table->index(['session_date', 'start_time']);
            $table->index('training_id');
        });
    }

    /** Elimina la tabla de sesiones. */
    public function down(): void
    {
        Schema::dropIfExists('training_sessions');
    }
};

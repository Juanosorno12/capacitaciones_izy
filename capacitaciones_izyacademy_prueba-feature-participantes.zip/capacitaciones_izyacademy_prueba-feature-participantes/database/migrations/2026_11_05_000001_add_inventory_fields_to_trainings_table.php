<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Adds the inventory columns used by the mass import/export workflow.
     */
    public function up(): void
    {
        Schema::table('trainings', function (Blueprint $table): void {
            $table->string('course_type')->nullable()->after('title');
            $table->string('training_provider')->nullable()->after('course_type');
            $table->string('shopping_cart_project')->nullable()->after('training_provider');
            $table->text('syllabus')->nullable()->after('description');
            $table->text('subtitles')->nullable()->after('syllabus');
            $table->text('prerequisites')->nullable()->after('subtitles');
            $table->string('level')->nullable()->after('prerequisites');
            $table->boolean('digital_badge')->nullable()->after('has_certificate');
            $table->boolean('for_internal_staff')->nullable()->after('digital_badge');
            $table->boolean('for_external_staff')->nullable()->after('for_internal_staff');
        });

        Schema::table('trainings', function (Blueprint $table): void {
            $table->string('expert_name')->nullable()->change();
            $table->text('schedule_details')->nullable()->change();
        });
    }

    /**
     * Removes the inventory columns.
     */
    public function down(): void
    {
        Schema::table('trainings', function (Blueprint $table): void {
            $table->string('expert_name')->nullable(false)->change();
            $table->text('schedule_details')->nullable(false)->change();
        });

        Schema::table('trainings', function (Blueprint $table): void {
            $table->dropColumn([
                'course_type',
                'training_provider',
                'shopping_cart_project',
                'syllabus',
                'subtitles',
                'prerequisites',
                'level',
                'digital_badge',
                'for_internal_staff',
                'for_external_staff',
            ]);
        });
    }
};

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        DB::table('permissions')->updateOrInsert(
            ['name' => 'audit-logs.view'],
            [
                'module_group' => 'Administración',
                'description' => 'Consultar el registro de auditoría del sistema.',
                'created_at' => now(),
                'updated_at' => now(),
            ]
        );

        $roleId = DB::table('roles')->where('slug', 'administrador')->value('id');
        $permissionId = DB::table('permissions')->where('name', 'audit-logs.view')->value('id');

        if ($roleId && $permissionId) {
            DB::table('role_has_permissions')->insertOrIgnore([
                'role_id' => $roleId,
                'permission_id' => $permissionId,
            ]);
        }

        $userIds = DB::table('user_has_permissions')
            ->where('permission_id', $permissionId)
            ->pluck('user_id')
            ->merge($roleId ? DB::table('users')->where('role_id', $roleId)->pluck('id') : [])
            ->unique();
        foreach ($userIds as $userId) {
            Cache::forget("user_effective_permissions_{$userId}");
        }

        Cache::forget('catalog_permissions_grouped');
    }

    public function down(): void
    {
        $permissionId = DB::table('permissions')->where('name', 'audit-logs.view')->value('id');
        $roleId = DB::table('roles')->where('slug', 'administrador')->value('id');
        $userIds = DB::table('user_has_permissions')
            ->where('permission_id', $permissionId)
            ->pluck('user_id')
            ->merge($roleId ? DB::table('users')->where('role_id', $roleId)->pluck('id') : [])
            ->unique();
        DB::table('role_has_permissions')->where('permission_id', $permissionId)->delete();
        DB::table('user_has_permissions')->where('permission_id', $permissionId)->delete();
        DB::table('permissions')->where('id', $permissionId)->delete();
        foreach ($userIds as $userId) {
            Cache::forget("user_effective_permissions_{$userId}");
        }
        Cache::forget('catalog_permissions_grouped');
    }
};

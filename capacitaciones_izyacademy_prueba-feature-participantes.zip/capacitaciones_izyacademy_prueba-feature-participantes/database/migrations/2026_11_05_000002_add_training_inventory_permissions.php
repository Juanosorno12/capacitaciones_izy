<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /** Registers and assigns the inventory permissions to administrators. */
    public function up(): void
    {
        foreach ([
            [
                'name' => 'trainings.import',
                'description' => 'Cargar y actualizar capacitaciones mediante archivos Excel.',
            ],
            [
                'name' => 'trainings.export',
                'description' => 'Exportar el inventario de capacitaciones a Excel.',
            ],
        ] as $permission) {
            DB::table('permissions')->updateOrInsert(
                ['name' => $permission['name']],
                [
                    'module_group' => 'Capacitaciones',
                    'description' => $permission['description'],
                    'created_at' => now(),
                    'updated_at' => now(),
                ]
            );

            $permissionId = DB::table('permissions')->where('name', $permission['name'])->value('id');
            $adminRoleId = DB::table('roles')->where('slug', 'administrador')->value('id');

            if ($permissionId && $adminRoleId) {
                DB::table('role_has_permissions')->insertOrIgnore([
                    'role_id' => $adminRoleId,
                    'permission_id' => $permissionId,
                ]);
            }
        }

        if ($adminRoleId ?? null) {
            DB::table('users')
                ->where('role_id', $adminRoleId)
                ->pluck('id')
                ->each(fn ($userId) => Cache::forget("user_effective_permissions_{$userId}"));
        }

        Cache::forget('catalog_permissions_grouped');
    }

    /** Removes the permissions and their assignments. */
    public function down(): void
    {
        $permissionIds = DB::table('permissions')
            ->whereIn('name', ['trainings.import', 'trainings.export'])
            ->pluck('id');

        DB::table('role_has_permissions')->whereIn('permission_id', $permissionIds)->delete();
        DB::table('user_has_permissions')->whereIn('permission_id', $permissionIds)->delete();
        DB::table('permissions')->whereIn('id', $permissionIds)->delete();
        Cache::forget('catalog_permissions_grouped');
    }
};

<?php

// Crea la tabla del flujo de solicitudes de capacitación.

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Crea campos, estados y relaciones de las solicitudes.
     */
    public function up(): void
    {
        Schema::create('training_requests', function (Blueprint $table) {
            $table->id();
            $table->foreignId('requested_by_user_id')->constrained('users')->onDelete('cascade');
            $table->foreignId('category_id')->constrained('training_categories')->onDelete('restrict');
            $table->foreignId('approved_training_id')->nullable()->constrained('trainings')->onDelete('set null');
            $table->string('title');
            $table->text('justification');
            $table->unsignedInteger('estimated_participants')->default(1);
            $table->enum('status', ['pending', 'reviewing', 'approved', 'rejected'])->default('pending');
            $table->text('rejection_reason')->nullable();
            $table->timestamps();

            // Índices de optimización y filtrado rápido
            $table->index('requested_by_user_id');
            $table->index('category_id');
            $table->index('approved_training_id');
            $table->index('status');
            $table->index(['requested_by_user_id', 'status']);
            $table->index(['category_id', 'status']);
            $table->index('created_at');
        });
    }

    /**
     * Elimina la tabla de solicitudes.
     */
    public function down(): void
    {
        Schema::dropIfExists('training_requests');
    }
};

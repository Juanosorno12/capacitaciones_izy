<?php

// Crea el catálogo de categorías de capacitación.

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Crea la estructura de categorías.
     */
    public function up(): void
    {
        Schema::create('training_categories', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->timestamps();

            // Índices de optimización
            $table->index('slug');
            $table->index('name');
        });
    }

    /**
     * Elimina la tabla de categorías.
     */
    public function down(): void
    {
        Schema::dropIfExists('training_categories');
    }
};

<?php

// Crea la tabla intermedia para permisos asignados directamente a usuarios.

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Crea las relaciones directas entre usuarios y permisos.
     */
    public function up(): void
    {
        Schema::create('user_has_permissions', function (Blueprint $table) {
            $table->foreignId('user_id')->constrained('users')->onDelete('cascade');
            $table->foreignId('permission_id')->constrained('permissions')->onDelete('cascade');

            $table->primary(['user_id', 'permission_id']);
            $table->index('user_id');
            $table->index('permission_id');
        });
    }

    /**
     * Elimina la tabla intermedia de permisos de usuarios.
     */
    public function down(): void
    {
        Schema::dropIfExists('user_has_permissions');
    }
};

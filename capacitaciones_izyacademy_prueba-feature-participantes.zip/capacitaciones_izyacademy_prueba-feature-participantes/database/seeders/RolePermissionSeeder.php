<?php

namespace Database\Seeders;

use App\Models\Permission;
use App\Models\Role;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

/** Carga roles institucionales y el catálogo de permisos del sistema. */
class RolePermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    /** Inserta roles, permisos y sus asignaciones iniciales. */
    public function run(): void
    {
        // 1. Crear Roles Base
        $roles = [
            [
                'name' => 'Administrador',
                'slug' => Role::SLUG_ADMIN,
                'description' => 'Acceso total y administración global de la plataforma, roles, usuarios y capacitaciones.',
            ],
            [
                'name' => 'Directores y Lideres',
                'slug' => Role::SLUG_LEADER,
                'description' => 'Gestión de solicitudes de capacitación, visualización del catálogo e indicadores de área.',
            ],
            [
                'name' => 'Externos',
                'slug' => Role::SLUG_EXTERNAL,
                'description' => 'Visualización exclusiva de capacitaciones públicas asignadas y descarga de certificados.',
            ],
        ];

        $createdRoles = [];
        foreach ($roles as $roleData) {
            $createdRoles[$roleData['slug']] = Role::firstOrCreate(
                ['slug' => $roleData['slug']],
                $roleData
            );
        }

        // 2. Crear Catálogo de Permisos Granulares agrupados por módulo
        $permissions = [
            // Módulo: Capacitaciones
            [
                'name' => 'trainings.view',
                'module_group' => 'Capacitaciones',
                'description' => 'Visualizar catálogo general de capacitaciones corporativas.',
            ],
            [
                'name' => 'trainings.manage',
                'module_group' => 'Capacitaciones',
                'description' => 'Crear, actualizar y eliminar programas de capacitación.',
            ],
            [
                'name' => 'trainings.import',
                'module_group' => 'Capacitaciones',
                'description' => 'Cargar y actualizar capacitaciones mediante archivos Excel.',
            ],
            [
                'name' => 'trainings.export',
                'module_group' => 'Capacitaciones',
                'description' => 'Exportar el inventario de capacitaciones a Excel.',
            ],
            [
                'name' => 'audit-logs.view',
                'module_group' => 'Administración',
                'description' => 'Consultar el registro de auditoría del sistema.',
            ],
            [
                'name' => 'trainings.certificate',
                'module_group' => 'Capacitaciones',
                'description' => 'Descargar y previsualizar certificados de participación.',
            ],
            [
                'name' => 'calendar.view',
                'module_group' => 'Capacitaciones',
                'description' => 'Consultar el calendario de sesiones programadas de capacitación.',
            ],

            // Módulo: Solicitudes
            [
                'name' => 'requests.view',
                'module_group' => 'Solicitudes',
                'description' => 'Visualizar solicitudes de capacitación en el sistema.',
            ],
            [
                'name' => 'requests.create',
                'module_group' => 'Solicitudes',
                'description' => 'Crear nuevas solicitudes de capacitación para sus equipos.',
            ],
            [
                'name' => 'requests.review',
                'module_group' => 'Solicitudes',
                'description' => 'Evaluar y cambiar estado de solicitudes en curso.',
            ],
            [
                'name' => 'requests.approve',
                'module_group' => 'Solicitudes',
                'description' => 'Aprobar, rechazar y convertir solicitudes en capacitaciones programadas.',
            ],

            // Módulo: Reportes
            [
                'name' => 'reports.view',
                'module_group' => 'Reportes',
                'description' => 'Acceso al Dashboard de analítica, gráficos y métricas de desempeño.',
            ],
            [
                'name' => 'reports.export',
                'module_group' => 'Reportes',
                'description' => 'Exportar datos estadísticos consolidados.',
            ],

            // Módulo: Usuarios
            [
                'name' => 'users.view',
                'module_group' => 'Usuarios',
                'description' => 'Visualizar directorio y perfiles de usuarios de la organización.',
            ],
            [
                'name' => 'users.manage',
                'module_group' => 'Usuarios',
                'description' => 'Crear, editar, activar y desactivar cuentas de usuario.',
            ],
            [
                'name' => 'users.permissions',
                'module_group' => 'Usuarios',
                'description' => 'Gestionar la matriz interactiva y checklist de permisos por usuario.',
            ],
            [
                'name' => 'participants.view',
                'module_group' => 'Participantes',
                'description' => 'Consultar el directorio e historial de capacitaciones de participantes.',
            ],
        ];

        $createdPermissions = [];
        foreach ($permissions as $permData) {
            $createdPermissions[$permData['name']] = Permission::firstOrCreate(
                ['name' => $permData['name']],
                $permData
            );
        }

        // 3. Asignar permisos a roles por defecto
        $adminRole = $createdRoles[Role::SLUG_ADMIN];
        $leaderRole = $createdRoles[Role::SLUG_LEADER];
        $externalRole = $createdRoles[Role::SLUG_EXTERNAL];

        // Administrador: Todos los permisos
        $adminRole->permissions()->sync(collect($createdPermissions)->pluck('id')->toArray());

        // Directores y Líderes
        $leaderPermissions = [
            'trainings.view',
            'trainings.certificate',
            'requests.view',
            'requests.create',
            'reports.view',
        ];
        $leaderRole->permissions()->sync(
            collect($createdPermissions)->only($leaderPermissions)->pluck('id')->toArray()
        );

        // Externos
        $externalPermissions = [
            'trainings.view',
            'trainings.certificate',
        ];
        $externalRole->permissions()->sync(
            collect($createdPermissions)->only($externalPermissions)->pluck('id')->toArray()
        );

        Permission::flushCache();
    }
}

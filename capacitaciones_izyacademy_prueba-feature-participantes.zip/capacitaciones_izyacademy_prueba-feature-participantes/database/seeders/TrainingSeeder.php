<?php

namespace Database\Seeders;

use App\Models\Training;
use App\Models\TrainingCategory;
use App\Models\User;
use Illuminate\Database\Seeder;

/** Carga capacitaciones de ejemplo para el catálogo y dashboard. */
class TrainingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    /** Inserta capacitaciones demo con sus relaciones principales. */
    public function run(): void
    {
        $admin = User::where('email', 'admin@izyacademy.com')->first();
        if (!$admin) {
            return;
        }

        $categories = TrainingCategory::all()->keyBy('slug');

        $trainings = [
            [
                'category_slug' => 'calidad-del-software',
                'title' => 'Fundamentos de Testing y Aseguramiento de Calidad ISTQB',
                'description' => 'Alineación de metodologías de testing estático y dinámico, niveles de prueba, diseño de casos de prueba eficaces y gestión de defectos según el estándar ISTQB Certified Tester.',
                'expert_name' => 'Ing. Valeria Restrepo',
                'expert_avatar_url' => 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
                'duration_hours' => 24,
                'schedule_details' => 'Martes y Jueves: 6:00 PM - 9:00 PM (Modalidad Virtual Sincrónica)',
                'is_public_for_externals' => true,
                'has_certificate' => true,
                'certificate_template_url' => 'https://images.unsplash.com/photo-1589330694653-ded6df03f754?w=800&auto=format&fit=crop&q=80',
            ],
            [
                'category_slug' => 'automatizacion-de-pruebas',
                'title' => 'Automatización E2E Moderna con Playwright y TypeScript',
                'description' => 'Construcción de suites de pruebas automatizadas resistentes con arquitectura Page Object Model (POM), integración CI/CD con GitHub Actions y mocking de llamadas de red.',
                'expert_name' => 'Dr. Camilo Andrés Gil',
                'expert_avatar_url' => 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
                'duration_hours' => 32,
                'schedule_details' => 'Lunes y Miércoles: 6:30 PM - 9:30 PM',
                'is_public_for_externals' => true,
                'has_certificate' => true,
                'certificate_template_url' => 'https://images.unsplash.com/photo-1589330694653-ded6df03f754?w=800&auto=format&fit=crop&q=80',
            ],
            [
                'category_slug' => 'ia-generativa',
                'title' => 'Ingeniería de Prompts y Agentes Inteligentes para Equipos de TI',
                'description' => 'Uso avanzado de modelos fundacionales (Claude, Gemini, GPT-4) para aceleración de refactorización de código, generación de pruebas unitarias y automatización de flujos de soporte.',
                'expert_name' => 'Mg. Juan Esteban Osorno',
                'expert_avatar_url' => 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
                'duration_hours' => 16,
                'schedule_details' => 'Sábados: 8:00 AM - 12:00 PM (4 sesiones)',
                'is_public_for_externals' => true,
                'has_certificate' => true,
                'certificate_template_url' => 'https://images.unsplash.com/photo-1589330694653-ded6df03f754?w=800&auto=format&fit=crop&q=80',
            ],
            [
                'category_slug' => 'ciberseguridad',
                'title' => 'Seguridad Aplicativa OWASP Top 10 y DevSecOps Práctico',
                'description' => 'Detección temprana de vulnerabilidades (XSS, SQL Injection, SSRF, Deserialización insegura) e integración de análisis estático SAST y dinámico DAST en pipelines automatizados.',
                'expert_name' => 'Lic. Fernando Zapata',
                'expert_avatar_url' => 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
                'duration_hours' => 20,
                'schedule_details' => 'Viernes: 5:00 PM - 9:00 PM y Sábados: 8:00 AM - 12:00 PM',
                'is_public_for_externals' => false, // Privado para internos
                'has_certificate' => true,
                'certificate_template_url' => 'https://images.unsplash.com/photo-1589330694653-ded6df03f754?w=800&auto=format&fit=crop&q=80',
            ],
            [
                'category_slug' => 'pruebas-de-performance',
                'title' => 'Pruebas de Carga y Concurrencia con k6 y Grafana',
                'description' => 'Diseño de scripts de carga distribuida, simulación de tráfico pico, medición de latencias p95/p99 y diagnósticos en tiempo real con Grafana y Prometheus.',
                'expert_name' => 'Ing. Mateo Arango',
                'expert_avatar_url' => 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
                'duration_hours' => 18,
                'schedule_details' => 'Martes y Jueves: 7:00 PM - 9:30 PM',
                'is_public_for_externals' => true,
                'has_certificate' => false,
                'certificate_template_url' => null,
            ],
            [
                'category_slug' => 'metodologias-agiles',
                'title' => 'Gestión de Productos Ágiles y Facilitación Scrum Avanzada',
                'description' => 'Refinamiento de backlog, métricas de flujo (Lead Time, Cycle Time, Throughput) y facilitación de retrospectivas de alto impacto para equipos de alto desempeño.',
                'expert_name' => 'Dra. Elena Vargas',
                'expert_avatar_url' => 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
                'duration_hours' => 15,
                'schedule_details' => 'Miércoles: 6:00 PM - 9:00 PM (5 semanas)',
                'is_public_for_externals' => true,
                'has_certificate' => true,
                'certificate_template_url' => 'https://images.unsplash.com/photo-1589330694653-ded6df03f754?w=800&auto=format&fit=crop&q=80',
            ],
        ];

        foreach ($trainings as $item) {
            $cat = $categories->get($item['category_slug']);
            if (!$cat) {
                continue;
            }

            Training::firstOrCreate(
                ['title' => $item['title']],
                [
                    'category_id' => $cat->id,
                    'created_by_user_id' => $admin->id,
                    'title' => $item['title'],
                    'description' => $item['description'],
                    'expert_name' => $item['expert_name'],
                    'expert_avatar_url' => $item['expert_avatar_url'],
                    'duration_hours' => $item['duration_hours'],
                    'schedule_details' => $item['schedule_details'],
                    'is_public_for_externals' => $item['is_public_for_externals'],
                    'has_certificate' => $item['has_certificate'],
                    'certificate_template_url' => $item['certificate_template_url'],
                ]
            );
        }
    }
}

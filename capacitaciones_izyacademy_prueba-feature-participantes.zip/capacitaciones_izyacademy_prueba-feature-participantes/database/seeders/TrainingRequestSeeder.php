<?php

namespace Database\Seeders;

use App\Models\Training;
use App\Models\TrainingCategory;
use App\Models\TrainingRequest;
use App\Models\User;
use Illuminate\Database\Seeder;

/** Carga solicitudes de ejemplo para probar el flujo de aprobación. */
class TrainingRequestSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    /** Inserta solicitudes demo relacionadas con usuarios y categorías. */
    public function run(): void
    {
        $leaderQA = User::where('email', 'lider.qa@izyacademy.com')->first();
        $leaderDev = User::where('email', 'lider.dev@izyacademy.com')->first();

        if (!$leaderQA || !$leaderDev) {
            return;
        }

        $categories = TrainingCategory::all()->keyBy('slug');
        $sampleTraining = Training::first();

        $requests = [
            [
                'requested_by_user_id' => $leaderQA->id,
                'category_slug' => 'automatizacion-de-pruebas',
                'approved_training_id' => null,
                'title' => 'Taller Práctico de Automatización de APIs con Postman y Newman',
                'justification' => 'El equipo de aseguramiento de calidad requiere estandarizar las pruebas de regresión automatizadas sobre el backend de microservicios e integrarlas a la tubería de despliegues.',
                'estimated_participants' => 12,
                'status' => TrainingRequest::STATUS_PENDING,
                'rejection_reason' => null,
            ],
            [
                'requested_by_user_id' => $leaderDev->id,
                'category_slug' => 'ia-generativa',
                'approved_training_id' => null,
                'title' => 'Arquitectura de Software Asistida por LLMs y RAG Empresarial',
                'justification' => 'Buscamos entrenar a los desarrolladores Senior en la implementación de patrones Retrieval-Augmented Generation con bases de datos vectoriales y control de costos de inferencia.',
                'estimated_participants' => 20,
                'status' => TrainingRequest::STATUS_REVIEWING,
                'rejection_reason' => null,
            ],
            [
                'requested_by_user_id' => $leaderQA->id,
                'category_slug' => 'calidad-del-software',
                'approved_training_id' => $sampleTraining ? $sampleTraining->id : null,
                'title' => 'Capacitación en Fundamentos de Testing y Calidad de Software',
                'justification' => 'Alineación de estándares metodológicos para los analistas de testing recién incorporados.',
                'estimated_participants' => 15,
                'status' => TrainingRequest::STATUS_APPROVED,
                'rejection_reason' => null,
            ],
            [
                'requested_by_user_id' => $leaderDev->id,
                'category_slug' => 'requerimientos',
                'approved_training_id' => null,
                'title' => 'Seminario de Gestión Tradicional en Cascada',
                'justification' => 'Revisión teórica de documentación prescriptiva de hace dos décadas.',
                'estimated_participants' => 5,
                'status' => TrainingRequest::STATUS_REJECTED,
                'rejection_reason' => 'La organización opera bajo marcos de trabajo ágiles (Scrum/Kanban). Se sugiere reformular la solicitud hacia "Especificación por Ejemplos (BDD) y User Stories".',
            ],
        ];

        foreach ($requests as $item) {
            $cat = $categories->get($item['category_slug']);
            if (!$cat) {
                continue;
            }

            TrainingRequest::firstOrCreate(
                ['title' => $item['title'], 'requested_by_user_id' => $item['requested_by_user_id']],
                [
                    'requested_by_user_id' => $item['requested_by_user_id'],
                    'category_id' => $cat->id,
                    'approved_training_id' => $item['approved_training_id'],
                    'title' => $item['title'],
                    'justification' => $item['justification'],
                    'estimated_participants' => $item['estimated_participants'],
                    'status' => $item['status'],
                    'rejection_reason' => $item['rejection_reason'],
                ]
            );
        }
    }
}

<?php

namespace Database\Seeders;

use App\Models\TrainingCategory;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

/** Carga categorías base para clasificar las capacitaciones. */
class TrainingCategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    /** Inserta o actualiza las categorías iniciales del catálogo. */
    public function run(): void
    {
        $categories = [
            [
                'name' => 'Calidad del Software',
                'description' => 'Estándares, procesos de QA, aseguramiento estático y dinámico de la calidad en el ciclo de vida de desarrollo.',
            ],
            [
                'name' => 'Automatización de pruebas',
                'description' => 'Frameworks de automatización web, API y móvil (Selenium, Cypress, Playwright, Appium, RestAssured).',
            ],
            [
                'name' => 'Requerimientos',
                'description' => 'Ingeniería de requisitos, historias de usuario, especificación basada en ejemplos (BDD) y análisis funcional.',
            ],
            [
                'name' => 'Pruebas de Performance',
                'description' => 'Evaluación de carga, estrés, concurrencia, resiliencia y monitoreo de cuellos de botella con JMeter y k6.',
            ],
            [
                'name' => 'Metodologías Ágiles',
                'description' => 'Scrum, Kanban, SAFe, Design Thinking y marcos de trabajo colaborativo para entrega continua de valor.',
            ],
            [
                'name' => 'Ciberseguridad',
                'description' => 'OWASP Top 10, seguridad en aplicaciones, DevSecOps, pruebas de penetración y gestión de vulnerabilidades.',
            ],
            [
                'name' => 'IA generativa',
                'description' => 'Integración de modelos LLM, ingeniería de prompts, automatización asistida por IA y desarrollo inteligente de software.',
            ],
        ];

        foreach ($categories as $data) {
            $slug = Str::slug($data['name']);
            TrainingCategory::firstOrCreate(
                ['slug' => $slug],
                [
                    'name' => $data['name'],
                    'slug' => $slug,
                    'description' => $data['description'],
                ]
            );
        }

        TrainingCategory::flushCache();
    }
}

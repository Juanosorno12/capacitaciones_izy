<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

/** Coordina la carga inicial de roles, catálogos, usuarios y datos demo. */
class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    /** Ejecuta los seeders en el orden requerido por sus relaciones. */
    public function run(): void
    {
        $this->call([
            RolePermissionSeeder::class,
            TrainingCategorySeeder::class,
            UserSeeder::class,
            TrainingSeeder::class,
            TrainingRequestSeeder::class,
        ]);
    }
}

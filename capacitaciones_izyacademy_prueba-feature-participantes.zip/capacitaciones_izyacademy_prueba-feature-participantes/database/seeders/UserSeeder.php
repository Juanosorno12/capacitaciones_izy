<?php

namespace Database\Seeders;

use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

/** Carga usuarios demo con sus roles y credenciales de prueba. */
class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    /** Inserta o actualiza las cuentas iniciales del sistema. */
    public function run(): void
    {
        $adminRole = Role::where('slug', Role::SLUG_ADMIN)->firstOrFail();
        $leaderRole = Role::where('slug', Role::SLUG_LEADER)->firstOrFail();
        $externalRole = Role::where('slug', Role::SLUG_EXTERNAL)->firstOrFail();

        $defaultPassword = Hash::make('Password123!');

        // 1. Administrador General
        User::firstOrCreate(
            ['email' => 'admin@izyacademy.com'],
            [
                'role_id' => $adminRole->id,
                'name' => 'Juan Esteban Osorno (Administrador)',
                'email' => 'admin@izyacademy.com',
                'password' => $defaultPassword,
                'is_active' => true,
            ]
        );

        // 2. Directores y Líderes de Área
        User::firstOrCreate(
            ['email' => 'lider.qa@izyacademy.com'],
            [
                'role_id' => $leaderRole->id,
                'name' => 'Carlos Mendoza (Director QA)',
                'email' => 'lider.qa@izyacademy.com',
                'password' => $defaultPassword,
                'is_active' => true,
            ]
        );

        User::firstOrCreate(
            ['email' => 'lider.dev@izyacademy.com'],
            [
                'role_id' => $leaderRole->id,
                'name' => 'Marcela Gómez (Líder Ingeniería)',
                'email' => 'lider.dev@izyacademy.com',
                'password' => $defaultPassword,
                'is_active' => true,
            ]
        );

        // 3. Usuarios Externos (Clientes, Contratistas o Aliados)
        User::firstOrCreate(
            ['email' => 'externo.consultor@cliente.com'],
            [
                'role_id' => $externalRole->id,
                'name' => 'David Ruiz (Consultor Externo)',
                'email' => 'externo.consultor@cliente.com',
                'password' => $defaultPassword,
                'is_active' => true,
            ]
        );

        User::firstOrCreate(
            ['email' => 'externo.auditor@partner.com'],
            [
                'role_id' => $externalRole->id,
                'name' => 'Sofía Morales (Auditora Externa)',
                'email' => 'externo.auditor@partner.com',
                'password' => $defaultPassword,
                'is_active' => true,
            ]
        );
    }
}

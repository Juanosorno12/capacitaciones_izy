<?php

// Textos e identidad visual configurable de la plataforma.

return [
    /*
    |--------------------------------------------------------------------------
    | Corporate Branding & Color Palette
    |--------------------------------------------------------------------------
    |
    | Centralized configuration of institutional corporate colors and branding
    | tokens used across views, emails, PDF certificates, and Chart.js reports.
    |
    */

    'app_name' => env('APP_NAME', 'IzyCapacitaciones Corporativas'),
    'company_name' => env('COMPANY_NAME', 'izyAcademy Corporativo'),

    'colors' => [
        // Primary Dark: Headers, Sidebars, Main Titles
        'primary_navy' => '#1D3A6C',
        'primary_navy_dark' => '#13274A',
        'primary_navy_light' => '#2A5298',

        // Primary Success / Actions: Primary CTA Buttons, confirmations, active badges
        'primary_teal' => '#19A885',
        'primary_teal_hover' => '#14866A',
        'primary_teal_light' => '#E8F6F3',

        // Accent Highlight: Badges, warnings, pending items, highlights
        'accent_orange' => '#FF5F00',
        'accent_orange_hover' => '#D95100',
        'accent_orange_light' => '#FFF2EB',

        // Interactive / Links: Anchors, focus states, interactive borders
        'interactive_blue' => '#0055AF',
        'interactive_blue_hover' => '#003E80',
        'interactive_blue_light' => '#EBF3FC',

        // Neutrals
        'neutral_white' => '#FFFFFF',
        'neutral_card_bg' => '#F8FAFC',
        'neutral_body_bg' => '#F1F5F9',
        'neutral_border' => '#E2E8F0',
        'neutral_text_main' => '#111111',
        'neutral_text_muted' => '#64748B',
    ],

    // Chart.js Color Palette Array
    'chart_palette' => [
        '#1D3A6C', // Primary Navy
        '#19A885', // Primary Teal
        '#FF5F00', // Accent Orange
        '#0055AF', // Interactive Blue
        '#4F46E5', // Indigo
        '#06B6D4', // Cyan
        '#84CC16', // Lime
        '#F59E0B', // Amber
    ],
];

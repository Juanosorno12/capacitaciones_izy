<?php

namespace App\Providers;

use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Route;

/** Registra las rutas web y les aplica el middleware web de Laravel. */
class RouteServiceProvider extends ServiceProvider
{
    /** Carga el archivo de rutas web de la aplicación. */
    public function boot(): void
    {
        $this->routes(function () {
            Route::middleware('web')
                ->group(base_path('routes/web.php'));
        });
    }
}

<?php

namespace App\Providers;

use App\Models\User;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\Gate;

/** Registra autorización por permisos y directivas Blade de seguridad. */
class AuthServiceProvider extends ServiceProvider
{
    /**
     * The model to policy mappings for the application.
     *
     * @var array<class-string, class-string>
     */
    protected $policies = [
        //
    ];

    /** Integra permisos dinámicos con Gate y registra @hasPermission y @hasRole. */
    public function boot(): void
    {
        // 1. Integración universal con Laravel Gate y directiva @can
        Gate::before(function (User $user, string $ability) {
            return $user->hasPermissionTo($ability) ? true : null;
        });

        // 2. Directiva Blade personalizada @hasPermission('...')
        Blade::directive('hasPermission', function ($expression) {
            return "<?php if (auth()->check() && auth()->user()->hasPermissionTo({$expression})): ?>";
        });

        Blade::directive('endhasPermission', function () {
            return '<?php endif; ?>';
        });

        // 3. Directiva Blade personalizada @hasRole('...')
        Blade::directive('hasRole', function ($expression) {
            return "<?php if (auth()->check() && auth()->user()->hasRole({$expression})): ?>";
        });

        Blade::directive('endhasRole', function () {
            return '<?php endif; ?>';
        });
    }
}

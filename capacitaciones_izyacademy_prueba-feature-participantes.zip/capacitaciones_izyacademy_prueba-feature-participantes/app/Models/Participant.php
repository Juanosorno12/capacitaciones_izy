<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

/** Representa a una persona que participa en solicitudes o capacitaciones. */
class Participant extends Model
{
    use HasFactory;

    /** Atributos permitidos para registrar los datos del participante. */
    protected $fillable = [
        'first_name',
        'last_name',
        'email',
        'personal_email',
        'phone',
        'city',
    ];

    /** Obtiene las solicitudes de capacitación asociadas al participante. */
    public function trainingRequests(): BelongsToMany
    {
        return $this->belongsToMany(
            TrainingRequest::class,
            'participant_training_request',
            'participant_id',
            'training_request_id'
        )->withTimestamps();
    }

    /** Obtiene las capacitaciones realizadas por el participante. */
    public function trainings(): BelongsToMany
    {
        return $this->belongsToMany(
            Training::class,
            'participant_training',
            'participant_id',
            'training_id'
        )->withTimestamps();
    }

    /** Obtiene las capacitaciones programadas en las que participa. */
    public function scheduledTrainings(): BelongsToMany
    {
        return $this->belongsToMany(
            ScheduledTraining::class,
            'participant_scheduled_training',
            'participant_id',
            'scheduled_training_id'
        )->withTimestamps();
    }

    /**
     * Scope para buscar por nombre, apellidos o cualquiera de sus correos.
     *
     * Cada palabra escrita debe coincidir con al menos uno de esos campos.
     */
    public function scopeSearch(Builder $query, ?string $term): Builder
    {
        $term = trim($term ?? '');

        if ($term === '') {
            return $query;
        }

        foreach (preg_split('/\s+/', $term, -1, PREG_SPLIT_NO_EMPTY) as $word) {
            $query->where(function (Builder $query) use ($word) {
                $query->where('first_name', 'like', "%{$word}%")
                    ->orWhere('last_name', 'like', "%{$word}%")
                    ->orWhere('email', 'like', "%{$word}%")
                    ->orWhere('personal_email', 'like', "%{$word}%");
            });
        }

        return $query;
    }
}

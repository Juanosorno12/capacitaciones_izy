<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/** Representa una sesión de una capacitación programada. */
class ScheduledTrainingSession extends Model
{
    use HasFactory;

    /** Atributos permitidos para registrar fecha y horario de la sesión. */
    protected $fillable = ['session_date', 'start_time', 'end_time'];

    /** Convierte la fecha de sesión al tipo fecha de Laravel. */
    protected $casts = ['session_date' => 'date'];

    /** Obtiene la capacitación programada a la que pertenece esta sesión. */
    public function training(): BelongsTo
    {
        return $this->belongsTo(ScheduledTraining::class, 'scheduled_training_id');
    }
}

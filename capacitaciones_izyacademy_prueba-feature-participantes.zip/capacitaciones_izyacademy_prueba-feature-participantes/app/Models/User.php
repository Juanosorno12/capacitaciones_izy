<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Storage;

/**
 * Representa a un usuario autenticado de la plataforma.
 *
 * Además de sus datos de acceso, relaciona el usuario con su rol,
 * permisos directos, capacitaciones creadas y solicitudes realizadas.
 */
class User extends Authenticatable
{
    use HasFactory, Notifiable;

    /** Atributos que pueden asignarse masivamente desde formularios. */
    protected $fillable = [
        'role_id',
        'name',
        'email',
        'password',
        'is_active',
        'profile_photo_path',
    ];

    /** Atributos que no deben exponerse al serializar el usuario. */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /** Conversión automática de tipos al leer o guardar atributos. */
    protected $casts = [
        'is_active' => 'boolean',
        'password' => 'hashed',
    ];

    /**
     * In-memory memoized permission names for current request cycle
     */
    protected ?array $memoizedPermissions = null;

    /** Obtiene el rol asignado al usuario. */
    public function role(): BelongsTo
    {
        return $this->belongsTo(Role::class, 'role_id');
    }

    /** Obtiene los permisos asignados directamente al usuario. */
    public function directPermissions(): BelongsToMany
    {
        return $this->belongsToMany(Permission::class, 'user_has_permissions', 'user_id', 'permission_id');
    }

    /** Obtiene las capacitaciones creadas por el usuario. */
    public function trainings(): HasMany
    {
        return $this->hasMany(Training::class, 'created_by_user_id');
    }

    /** Obtiene las solicitudes de capacitación creadas por el usuario. */
    public function trainingRequests(): HasMany
    {
        return $this->hasMany(TrainingRequest::class, 'requested_by_user_id');
    }

    /** Indica si la cuenta del usuario está habilitada. */
    public function isActive(): bool
    {
        return (bool) $this->is_active;
    }

    /** Construye la URL pública de la foto de perfil o devuelve null si no existe. */
    public function getProfilePhotoUrlAttribute(): ?string
    {
        return $this->profile_photo_path
            ? Storage::disk('public')->url($this->profile_photo_path)
            : null;
    }

    /** Comprueba si el usuario tiene uno de los roles indicados por su slug. */
    public function hasRole(string|array $roles): bool
    {
        if (!$this->relationLoaded('role')) {
            $this->load('role');
        }

        if (!$this->role) {
            return false;
        }

        if (is_array($roles)) {
            return in_array($this->role->slug, $roles);
        }

        return $this->role->slug === $roles;
    }

    /**
     * Devuelve los permisos efectivos del usuario.
     *
     * Combina permisos del rol y permisos directos, evitando consultas
     * repetidas mediante memoización en la instancia y caché de aplicación.
     */
    public function getEffectivePermissionNames(): array
    {
        if ($this->memoizedPermissions !== null) {
            return $this->memoizedPermissions;
        }

        if (!$this->isActive()) {
            return $this->memoizedPermissions = [];
        }

        // Cache tag/key per user
        $cacheKey = "user_effective_permissions_{$this->id}";
        $this->memoizedPermissions = Cache::remember($cacheKey, 3600, function () {
            // Eager load if not loaded
            if (!$this->relationLoaded('role') || !$this->role?->relationLoaded('permissions')) {
                $this->load(['role.permissions', 'directPermissions']);
            }

            $rolePermissions = $this->role ? $this->role->permissions->pluck('name')->toArray() : [];
            $directPermissions = $this->directPermissions->pluck('name')->toArray();

            return array_values(array_unique(array_merge($rolePermissions, $directPermissions)));
        });

        return $this->memoizedPermissions;
    }

    /** Comprueba rápidamente si el usuario activo posee un permiso específico. */
    public function hasPermissionTo(string $permissionName): bool
    {
        if (!$this->isActive()) {
            return false;
        }

        return in_array($permissionName, $this->getEffectivePermissionNames(), true);
    }

    /** Limpia la caché de permisos del usuario después de cambios de autorización. */
    public function flushPermissionCache(): void
    {
        $this->memoizedPermissions = null;
        Cache::forget("user_effective_permissions_{$this->id}");
    }

    /** Scope para filtrar únicamente usuarios activos. */
    public function scopeActive(Builder $query): Builder
    {
        return $query->where('is_active', true);
    }

    /** Scope para buscar usuarios por nombre o correo electrónico. */
    public function scopeSearch(Builder $query, ?string $term): Builder
    {
        if (empty($term)) {
            return $query;
        }

        return $query->where(function ($q) use ($term) {
            $q->where('name', 'like', "%{$term}%")
              ->orWhere('email', 'like', "%{$term}%");
        });
    }

    /**
     * Registra eventos del modelo para invalidar la caché de permisos
     * cuando el usuario se guarda o elimina.
     */
    protected static function booted()
    {
        static::saved(function (User $user) {
            $user->flushPermissionCache();
        });

        static::deleted(function (User $user) {
            $user->flushPermissionCache();
        });
    }
}

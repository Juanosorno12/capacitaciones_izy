<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/** Immutable security and business activity record. */
class AuditLog extends Model
{
    public const REPORTABLE_ACTIONS = [
        'auth.login',
        'training.imported',
        'training.exported',
        'training.created',
        'training.updated',
        'training.deleted',
        'user.created',
        'user.updated',
        'user.permissions_updated',
        'request.approved',
        'request.rejected',
    ];

    public const ACTION_LABELS = [
        'auth.login' => 'Inicio de sesión exitoso',
        'training.imported' => 'Importación de capacitaciones',
        'training.exported' => 'Exportación de capacitaciones',
        'training.created' => 'Creación de curso',
        'training.updated' => 'Edición de curso',
        'training.deleted' => 'Eliminación de curso',
        'user.created' => 'Creación de usuario',
        'user.updated' => 'Edición de usuario',
        'user.permissions_updated' => 'Cambio de permisos de usuario',
        'request.approved' => 'Aprobación de solicitud',
        'request.rejected' => 'Rechazo de solicitud',
    ];

    public $timestamps = false;

    protected $fillable = [
        'user_id',
        'action',
        'entity_type',
        'entity_id',
        'description',
        'ip_address',
        'user_agent',
        'metadata',
        'created_at',
    ];

    protected $casts = [
        'metadata' => 'array',
        'created_at' => 'datetime',
    ];

    public function getActionLabelAttribute(): string
    {
        return static::actionLabel($this->action);
    }

    public static function actionLabel(string $action): string
    {
        return self::ACTION_LABELS[$action] ?? $action;
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function scopeAction(Builder $query, ?string $action): Builder
    {
        return $action ? $query->where('action', $action) : $query;
    }

    /** Limits the administrative report to the approved audit events. */
    public function scopeReportable(Builder $query): Builder
    {
        return $query->whereIn('action', self::REPORTABLE_ACTIONS);
    }

    public function scopeSearch(Builder $query, ?string $term): Builder
    {
        if (!$term) {
            return $query;
        }

        return $query->where(function (Builder $query) use ($term): void {
            $query->where('description', 'like', "%{$term}%")
                ->orWhere('entity_type', 'like', "%{$term}%");
        });
    }
}

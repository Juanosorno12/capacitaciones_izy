<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

/** Representa un rol y los permisos que puede heredar un usuario. */
class Role extends Model
{
    use HasFactory;

    const SLUG_ADMIN = 'administrador';
    const SLUG_LEADER = 'directores-y-lideres';
    const SLUG_EXTERNAL = 'externos';

    /** Atributos permitidos para asignación masiva. */
    protected $fillable = [
        'name',
        'slug',
        'description',
    ];

    /** Obtiene los usuarios que tienen este rol. */
    public function users(): HasMany
    {
        return $this->hasMany(User::class);
    }

    /** Obtiene los permisos del rol mediante la tabla intermedia. */
    public function permissions(): BelongsToMany
    {
        return $this->belongsToMany(Permission::class, 'role_has_permissions', 'role_id', 'permission_id');
    }

    /** Indica si el rol contiene un permiso con el nombre indicado. */
    public function hasPermission(string $permissionName): bool
    {
        return $this->permissions->contains('name', $permissionName);
    }
}

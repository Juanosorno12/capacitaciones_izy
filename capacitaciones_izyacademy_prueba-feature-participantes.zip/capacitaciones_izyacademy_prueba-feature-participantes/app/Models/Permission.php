<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Support\Facades\Cache;

/** Representa un permiso funcional del sistema. */
class Permission extends Model
{
    use HasFactory;

    /** Traduce el nombre técnico del permiso a una etiqueta legible. */
    public function getDisplayNameAttribute(): string
    {
        return [
            'trainings.view' => 'Ver capacitaciones',
            'trainings.manage' => 'Administrar capacitaciones',
            'trainings.import' => 'Importar capacitaciones',
            'trainings.export' => 'Exportar capacitaciones',
            'audit-logs.view' => 'Consultar registro de auditoría',
            'trainings.certificate' => 'Ver y descargar certificados',
            'calendar.view' => 'Ver calendario',
            'requests.view' => 'Ver solicitudes',
            'requests.create' => 'Crear solicitudes',
            'requests.review' => 'Revisar solicitudes',
            'requests.approve' => 'Aprobar o rechazar solicitudes',
            'reports.view' => 'Ver reportes',
            'reports.export' => 'Descargar reportes',
            'users.view' => 'Ver usuarios',
            'users.manage' => 'Administrar usuarios',
            'users.permissions' => 'Gestionar permisos de usuarios',
            'participants.view' => 'Consultar participantes e historial formativo',
        ][$this->name] ?? $this->name;
    }

    /** Devuelve el nombre visible del módulo al que pertenece el permiso. */
    public function getDisplayModuleAttribute(): string
    {
        return [
            'Capacitaciones' => 'Capacitaciones',
            'Solicitudes' => 'Solicitudes de capacitación',
            'Reportes' => 'Reportes y estadísticas',
            'Usuarios' => 'Usuarios y permisos',
            'Participantes' => 'Directorio de participantes',
        ][$this->module_group] ?? $this->module_group;
    }

    /** Atributos permitidos para asignación masiva. */
    protected $fillable = [
        'name',
        'module_group',
        'description',
    ];

    /** Obtiene los roles que incluyen este permiso. */
    public function roles(): BelongsToMany
    {
        return $this->belongsToMany(Role::class, 'role_has_permissions', 'permission_id', 'role_id');
    }

    /** Obtiene los usuarios que reciben este permiso directamente. */
    public function users(): BelongsToMany
    {
        return $this->belongsToMany(User::class, 'user_has_permissions', 'permission_id', 'user_id');
    }

    /** Scope para filtrar permisos por grupo o módulo. */
    public function scopeByModule(Builder $query, string $module): Builder
    {
        return $query->where('module_group', $module);
    }

    /** Obtiene todos los permisos agrupados por módulo usando caché permanente. */
    public static function getCachedGrouped()
    {
        return Cache::rememberForever('catalog_permissions_grouped', function () {
            return static::query()
                ->orderBy('module_group')
                ->orderBy('name')
                ->get()
                ->groupBy('module_group');
        });
    }

    /** Elimina la caché del catálogo de permisos. */
    public static function flushCache(): void
    {
        Cache::forget('catalog_permissions_grouped');
    }

    /** Invalida el catálogo en caché al guardar o eliminar un permiso. */
    protected static function booted()
    {
        static::saved(function () {
            static::flushCache();
        });

        static::deleted(function () {
            static::flushCache();
        });
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

/** Representa una capacitación programada a partir de una solicitud aprobada. */
class ScheduledTraining extends Model
{
    use HasFactory;

    /** Atributos permitidos para crear o actualizar la capacitación programada. */
    protected $fillable = [
        'training_id',
        'training_request_id',
        'created_by_user_id',
        'expert_user_id',
        'category_id',
        'title',
        'value_added',
        'description',
        'expert_name',
        'duration_hours',
        'schedule_details',
        'modality',
        'is_public_for_externals',
        'has_certificate',
        'certificate_template_url',
    ];

    /** Conversión automática de indicadores booleanos y duración. */
    protected $casts = [
        'is_public_for_externals' => 'boolean',
        'has_certificate' => 'boolean',
        'value_added' => 'boolean',
        'duration_hours' => 'integer',
    ];

    /** Obtiene la capacitación base relacionada. */
    public function training(): BelongsTo
    {
        return $this->belongsTo(Training::class);
    }

    /** Obtiene la categoría de la capacitación programada. */
    public function category(): BelongsTo
    {
        return $this->belongsTo(TrainingCategory::class);
    }

    /** Obtiene el usuario que actúa como experto. */
    public function expert(): BelongsTo
    {
        return $this->belongsTo(User::class, 'expert_user_id');
    }

    /** Obtiene la solicitud que originó la programación. */
    public function request(): BelongsTo
    {
        return $this->belongsTo(TrainingRequest::class, 'training_request_id');
    }

    /** Obtiene sus sesiones ordenadas por fecha y hora de inicio. */
    public function sessions(): HasMany
    {
        return $this->hasMany(ScheduledTrainingSession::class)->orderBy('session_date')->orderBy('start_time');
    }

    /** Obtiene los participantes inscritos mediante la tabla intermedia. */
    public function participants(): BelongsToMany
    {
        return $this->belongsToMany(
            Participant::class,
            'participant_scheduled_training',
            'scheduled_training_id',
            'participant_id'
        )->withTimestamps();
    }
}

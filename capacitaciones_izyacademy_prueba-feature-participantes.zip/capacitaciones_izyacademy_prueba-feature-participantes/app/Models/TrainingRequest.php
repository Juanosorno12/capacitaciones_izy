<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

/** Representa una solicitud de capacitación y su flujo de aprobación. */
class TrainingRequest extends Model
{
    use HasFactory;

    const STATUS_PENDING = 'pending';
    const STATUS_REVIEWING = 'reviewing';
    const STATUS_APPROVED = 'approved';
    const STATUS_REJECTED = 'rejected';

    /** Atributos permitidos para crear o actualizar una solicitud. */
    protected $fillable = [
        'requested_by_user_id',
        'category_id',
        'approved_training_id',
        'title',
        'value_added',
        'client_name',
        'justification',
        'estimated_participants',
        'status',
        'rejection_reason',
    ];

    /** Conversión automática de cantidades e indicadores booleanos. */
    protected $casts = [
        'estimated_participants' => 'integer',
        'value_added' => 'boolean',
    ];

    /** Obtiene el usuario que creó la solicitud. */
    public function requester(): BelongsTo
    {
        return $this->belongsTo(User::class, 'requested_by_user_id');
    }

    /** Obtiene la categoría solicitada. */
    public function category(): BelongsTo
    {
        return $this->belongsTo(TrainingCategory::class, 'category_id');
    }

    /** Obtiene la capacitación base creada cuando la solicitud fue aprobada. */
    public function approvedTraining(): BelongsTo
    {
        return $this->belongsTo(Training::class, 'approved_training_id');
    }

    /** Obtiene la programación generada para esta solicitud, si existe. */
    public function scheduledTraining(): HasOne
    {
        return $this->hasOne(ScheduledTraining::class);
    }

    /** Obtiene los participantes asociados directamente a la solicitud. */
    public function participants(): BelongsToMany
    {
        return $this->belongsToMany(
            Participant::class,
            'participant_training_request',
            'training_request_id',
            'participant_id'
        )->withTimestamps();
    }

    /** Scope que carga las relaciones habituales para evitar consultas N+1. */
    public function scopeWithStandardRelations(Builder $query): Builder
    {
        return $query->with([
            'requester:id,name,email,role_id',
            'requester.role:id,name',
            'category:id,name,slug',
            'approvedTraining:id,title',
        ]);
    }

    /** Scope para filtrar solicitudes por estado. */
    public function scopeByStatus(Builder $query, ?string $status): Builder
    {
        if (empty($status)) {
            return $query;
        }

        return $query->where('status', $status);
    }

    /** Scope para filtrar solicitudes creadas por un usuario. */
    public function scopeForUser(Builder $query, int $userId): Builder
    {
        return $query->where('requested_by_user_id', $userId);
    }

    /** Scope para obtener únicamente solicitudes pendientes. */
    public function scopePending(Builder $query): Builder
    {
        return $query->where('status', self::STATUS_PENDING);
    }

    /** Indica si la solicitud continúa pendiente y puede editarse. */
    public function isPending(): bool
    {
        return $this->status === self::STATUS_PENDING;
    }

    /** Indica si la solicitud fue aprobada. */
    public function isApproved(): bool
    {
        return $this->status === self::STATUS_APPROVED;
    }
}

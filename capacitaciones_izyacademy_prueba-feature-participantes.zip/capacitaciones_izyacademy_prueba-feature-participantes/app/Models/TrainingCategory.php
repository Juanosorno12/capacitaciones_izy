<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Facades\Cache;

/** Representa una categoría utilizada para clasificar capacitaciones. */
class TrainingCategory extends Model
{
    use HasFactory;

    /** Atributos permitidos para asignación masiva. */
    protected $fillable = [
        'name',
        'slug',
        'description',
    ];

    /** Obtiene las capacitaciones pertenecientes a la categoría. */
    public function trainings(): HasMany
    {
        return $this->hasMany(Training::class, 'category_id');
    }

    /** Obtiene las solicitudes asociadas a la categoría. */
    public function trainingRequests(): HasMany
    {
        return $this->hasMany(TrainingRequest::class, 'category_id');
    }

    /** Obtiene todas las categorías ordenadas por nombre usando caché permanente. */
    public static function getCachedAll()
    {
        return Cache::rememberForever('catalog_training_categories', function () {
            return static::query()
                ->orderBy('name', 'asc')
                ->get();
        });
    }

    /** Elimina la caché del catálogo de categorías. */
    public static function flushCache(): void
    {
        Cache::forget('catalog_training_categories');
    }

    /** Invalida el catálogo en caché al guardar o eliminar una categoría. */
    protected static function booted()
    {
        static::saved(function () {
            static::flushCache();
        });

        static::deleted(function () {
            static::flushCache();
        });
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/** Representa una fecha y horario concreto dentro de una capacitación. */
class TrainingSession extends Model
{
    use HasFactory;

    /** Atributos permitidos para registrar la fecha y el horario. */
    protected $fillable = [
        'session_date',
        'start_time',
        'end_time',
    ];

    /** Convierte la fecha de sesión en una instancia de fecha de Laravel. */
    protected $casts = [
        'session_date' => 'date',
    ];

    /** Obtiene la capacitación a la que pertenece esta sesión. */
    public function training(): BelongsTo
    {
        return $this->belongsTo(Training::class);
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

/** Representa una capacitación disponible o creada en la plataforma. */
class Training extends Model
{
    use HasFactory;

    /** Atributos permitidos para asignación masiva desde formularios. */
    protected $fillable = [
        'category_id',
        'created_by_user_id',
        'title',
        'course_type',
        'training_provider',
        'shopping_cart_project',
        'description',
        'syllabus',
        'subtitles',
        'prerequisites',
        'level',
        'expert_user_id',
        'expert_name',
        'expert_avatar_url',
        'duration_hours',
        'schedule_details',
        'modality',
        'is_public_for_externals',
        'has_certificate',
        'digital_badge',
        'for_internal_staff',
        'for_external_staff',
        'certificate_template_url',
    ];

    /** Conversión automática de indicadores booleanos y duración. */
    protected $casts = [
        'is_public_for_externals' => 'boolean',
        'has_certificate' => 'boolean',
        'digital_badge' => 'boolean',
        'for_internal_staff' => 'boolean',
        'for_external_staff' => 'boolean',
        'duration_hours' => 'integer',
    ];

    /** Obtiene la categoría de la capacitación. */
    public function category(): BelongsTo
    {
        return $this->belongsTo(TrainingCategory::class, 'category_id');
    }

    /** Obtiene el usuario que creó la capacitación. */
    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by_user_id');
    }

    /** Obtiene el usuario interno que actúa como experto, si existe. */
    public function expert(): BelongsTo
    {
        return $this->belongsTo(User::class, 'expert_user_id');
    }

    /** Obtiene las solicitudes que originaron esta capacitación aprobada. */
    public function requests(): HasMany
    {
        return $this->hasMany(TrainingRequest::class, 'approved_training_id');
    }

    /** Obtiene los participantes inscritos mediante la tabla intermedia. */
    public function participants(): BelongsToMany
    {
        return $this->belongsToMany(
            Participant::class,
            'participant_training',
            'training_id',
            'participant_id'
        )->withTimestamps();
    }

    /** Obtiene las sesiones ordenadas por fecha y hora de inicio. */
    public function sessions(): HasMany
    {
        return $this->hasMany(TrainingSession::class)->orderBy('session_date')->orderBy('start_time');
    }

    /** Scope para mostrar solo capacitaciones públicas para externos. */
    public function scopePublicForExternals(Builder $query): Builder
    {
        return $query->where(function (Builder $query): void {
            $query->where('for_external_staff', true)
                ->orWhere(function (Builder $query): void {
                    $query->whereNull('for_external_staff')
                        ->where('is_public_for_externals', true);
                });
        });
    }

    /** Uses the catalog audience, falling back only for legacy rows not yet migrated. */
    public function getIsAvailableForExternalsAttribute(): bool
    {
        return (bool) ($this->for_external_staff ?? $this->is_public_for_externals);
    }

    /** Scope para filtrar por el identificador de una categoría. */
    public function scopeByCategory(Builder $query, ?int $categoryId): Builder
    {
        if (empty($categoryId)) {
            return $query;
        }

        return $query->where('category_id', $categoryId);
    }

    /** Scope para buscar por título, descripción o nombre del experto. */
    public function scopeSearch(Builder $query, ?string $term): Builder
    {
        if (empty($term)) {
            return $query;
        }

        return $query->where(function ($q) use ($term) {
            $q->where('title', 'like', "%{$term}%")
              ->orWhere('description', 'like', "%{$term}%")
              ->orWhere('expert_name', 'like', "%{$term}%");
        });
    }

    /** Scope que carga relaciones frecuentes para evitar consultas N+1. */
    public function scopeWithStandardRelations(Builder $query): Builder
    {
        return $query->with([
            'category:id,name,slug',
            'creator:id,name,email',
            'expert:id,name,profile_photo_path',
        ]);
    }

    /**
     * Obtiene el avatar del experto.
     *
     * Prioriza la foto del usuario relacionado, luego la URL guardada y,
     * como último recurso, genera un avatar SVG con las iniciales.
     */
    public function getAvatarUrlAttribute(): string
    {
        if ($this->expert_user_id !== null) {
            if ($this->expert?->profile_photo_url) {
                return $this->expert->profile_photo_url;
            }
        } elseif ($this->expert_avatar_url) {
            return $this->expert_avatar_url;
        }

        $nameParts = preg_split('/\s+/u', trim((string) ($this->expert_name ?? '')), -1, PREG_SPLIT_NO_EMPTY) ?: [];
        $initials = mb_strtoupper(
            mb_substr($nameParts[0] ?? '?', 0, 1)
                . (count($nameParts) > 1 ? mb_substr($nameParts[count($nameParts) - 1], 0, 1) : ''),
            'UTF-8'
        );
        $escapedInitials = htmlspecialchars($initials, ENT_QUOTES | ENT_XML1, 'UTF-8');
        $svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96">'
            . '<rect width="96" height="96" rx="48" fill="#1D3A6C"/>'
            . '<text x="48" y="52" fill="#FFFFFF" font-family="Arial,sans-serif" font-size="36"'
            . ' font-weight="bold" text-anchor="middle" dominant-baseline="middle">'
            . $escapedInitials
            . '</text></svg>';

        return 'data:image/svg+xml;base64,' . base64_encode($svg);
    }
}

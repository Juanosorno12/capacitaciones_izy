<?php

namespace App\Imports;

use Illuminate\Support\Collection;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Concerns\ToCollection;

/**
 * Reads the inventory sheet without assuming a fixed number of introductory rows.
 */
class TrainingInventoryImport implements ToCollection
{
    private const REQUIRED_HEADINGS = [
        'categoria',
        'curso o certificacion',
        'nombre del curso o certificacion',
        'descripcion',
        'temario del curso',
        'intensidad horaria',
        'insignia digital',
        'para personal interno',
        'para personal externo',
    ];

    /** Rows mapped by the canonical inventory headings. */
    public array $rows = [];

    /** Missing or unrecognized workbook headings. */
    public array $headerErrors = [];

    /** Reads the workbook and locates the row containing the inventory headings. */
    public function collection(Collection $collection): void
    {
        $headerIndex = null;
        $headers = [];

        foreach ($collection as $index => $row) {
            $candidate = [];
            foreach ($row as $column => $value) {
                $candidate[$column] = $this->normalizeHeading((string) $value);
            }

            if (
                in_array('categoria', $candidate, true)
                && in_array('nombre del curso o certificacion', $candidate, true)
            ) {
                $headerIndex = $index;
                $headers = $candidate;
                break;
            }
        }

        if ($headerIndex === null) {
            $this->headerErrors[] = 'No se encontró una fila de encabezados válida.';
            return;
        }

        $missingHeadings = array_diff(self::REQUIRED_HEADINGS, $headers);
        if ($missingHeadings !== []) {
            $this->headerErrors[] = 'Faltan encabezados obligatorios: '.implode(', ', $missingHeadings).'.';
            return;
        }

        foreach ($collection->slice($headerIndex + 1) as $rowIndex => $row) {
            $mapped = [];
            foreach ($headers as $column => $heading) {
                $mapped[$heading] = $this->cleanValue($row[$column] ?? null);
            }

            if ($this->isEmptyRow($mapped)) {
                continue;
            }

            $mapped['_row'] = $rowIndex + 1;
            $this->rows[] = $mapped;
        }
    }

    /** Makes headings stable across accents, casing and line breaks. */
    private function normalizeHeading(string $heading): string
    {
        $heading = Str::ascii(trim(str_replace(["\r", "\n"], ' ', $heading)));
        $heading = preg_replace('/\s+/', ' ', $heading) ?? $heading;

        return Str::lower($heading);
    }

    /** Converts spreadsheet values to safe scalar strings for validation. */
    private function cleanValue(mixed $value): ?string
    {
        if ($value === null) {
            return null;
        }

        $value = trim((string) $value);

        return $value === '' ? null : $value;
    }

    /** Ignores formatting-only rows. */
    private function isEmptyRow(array $row): bool
    {
        foreach ($row as $key => $value) {
            if ($key !== '_row' && $value !== null && $value !== '') {
                return false;
            }
        }

        return true;
    }
}

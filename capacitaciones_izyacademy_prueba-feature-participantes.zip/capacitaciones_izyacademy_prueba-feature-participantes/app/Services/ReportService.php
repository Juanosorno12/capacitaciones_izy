<?php

namespace App\Services;

use App\Models\Training;
use App\Models\TrainingCategory;
use App\Models\TrainingRequest;
use App\Models\ScheduledTrainingSession;
use App\Models\TrainingSession;
use App\Models\User;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\LengthAwarePaginator as ConcreteLengthAwarePaginator;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/** Genera métricas, listados y exportaciones de capacitaciones realizadas. */
class ReportService
{
    /** Calcula indicadores y pagina las sesiones entregadas del periodo. */
    public function getDeliveredTrainingReport(array $bounds): array
    {
        $sessions = $this->reportSessions($bounds);
        $sessionCount = $sessions->count();
        $trainingCount = $sessions->map(fn ($session) => $session->training->getKey())->unique()->count();
        $participantCount = $sessions
            ->map(fn ($session) => $session->training->participants->pluck('id'))
            ->flatten()
            ->unique()
            ->count();
        $totalMinutes = $sessions
            ->sum(fn ($session): int => $this->sessionMinutes($session));

        return [
            'metrics' => [
                'trainings' => $trainingCount,
                'sessions' => $sessionCount,
                'hours' => round($totalMinutes / 60, 1),
                'participants' => $participantCount,
            ],
            'sessions' => $this->paginate($sessions->sortByDesc(
                fn ($session) => $session->session_date->format('Y-m-d').' '.$session->start_time
            ), 25),
        ];
    }

    /** Convierte las sesiones entregadas en filas listas para exportar. */
    public function exportDeliveredTrainingSessions(array $bounds): Collection
    {
        return $this->reportSessions($bounds)
            ->sortBy(fn ($session) => $session->session_date->format('Y-m-d').' '.$session->start_time)
            ->map(function ($session): array {
                $training = $session->training;
                $request = $training->request;

                return [
                    'date' => $session->session_date->format('d/m/Y'),
                    'training' => $training->title,
                    'client' => $request?->client_name ?? '',
                    'value_added' => $training->value_added ? 'Sí' : 'No',
                    'category' => $training->category->name,
                    'expert' => $training->expert_name,
                    'modality' => match ($training->modality) {
                        'virtual' => 'Virtual',
                        'presencial' => 'Presencial',
                        default => 'No especificada',
                    },
                    'start_time' => substr((string) $session->start_time, 0, 5),
                    'end_time' => substr((string) $session->end_time, 0, 5),
                    'hours' => round($this->sessionMinutes($session) / 60, 2),
                    'participant_count' => $training->participants->count(),
                    'participants' => $training->participants
                        ->map(fn ($participant): string => "{$participant->first_name} {$participant->last_name} ({$participant->email})")
                        ->implode('; '),
                ];
            })
            ->values();
    }

    /** Construye la consulta de sesiones programadas y filtros de valor agregado. */
    private function scheduledSessionQuery(array $bounds)
    {
        return ScheduledTrainingSession::query()
            ->when(
                ($bounds['value_added'] ?? 'all') !== 'all',
                fn ($query) => $query->whereHas(
                    'training',
                    fn ($trainingQuery) => $trainingQuery->where(
                        'value_added',
                        ($bounds['value_added'] ?? 'all') === 'yes'
                    )
                )
            )
            ->whereBetween('session_date', [$bounds['from'], $bounds['to']])
            ->whereHas('training');
    }

    /** Une sesiones nuevas y heredadas, elimina duplicados y carga relaciones. */
    private function reportSessions(array $bounds): Collection
    {
        $scheduled = $this->scheduledSessionQuery($bounds)
            ->with([
                'training.category:id,name',
                'training.participants:id,first_name,last_name,email',
                'training.request:id,client_name',
                'training.training:id,title',
            ])
            ->get();

        $legacy = TrainingSession::query()
            ->with([
                'training.category:id,name',
                'training.participants:id,first_name,last_name,email',
                'training.requests' => fn ($query) => $query
                    ->where('status', 'approved')
                    ->select('id', 'approved_training_id', 'client_name', 'value_added'),
            ])
            ->whereBetween('session_date', [$bounds['from'], $bounds['to']])
            ->whereHas('training.requests', function ($query) use ($bounds): void {
                $query->where('status', 'approved')
                    ->when(
                        ($bounds['value_added'] ?? 'all') !== 'all',
                        fn ($requestQuery) => $requestQuery->where(
                            'value_added',
                            ($bounds['value_added'] ?? 'all') === 'yes'
                        )
                    );
            })
            ->get()
            ->each(function (TrainingSession $session): void {
                $training = $session->training;
                $request = $training->requests->first();
                $training->setRelation('request', $request);
                $training->setRelation('training', $training);
                $training->setAttribute('value_added', (bool) ($request?->value_added ?? false));
            });

        return $scheduled
            ->concat($legacy)
            ->unique(fn ($session): string => implode('|', [
                $session->session_date->toDateString(),
                $session->start_time,
                $session->end_time,
                $session->training->title,
            ]));
    }

    /** Adapta una colección en memoria al paginador de Laravel. */
    private function paginate(Collection $sessions, int $perPage): LengthAwarePaginator
    {
        $page = Paginator::resolveCurrentPage();

        return new ConcreteLengthAwarePaginator(
            $sessions->forPage($page, $perPage)->values(),
            $sessions->count(),
            $perPage,
            $page,
            ['path' => Paginator::resolveCurrentPath()]
        );
    }

    /** Calcula la duración de una sesión en minutos. */
    private function sessionMinutes($session): int
    {
        $start = Carbon::createFromFormat('H:i:s', (string) $session->start_time);
        $end = Carbon::createFromFormat('H:i:s', (string) $session->end_time);

        return (int) $start->diffInMinutes($end, false);
    }

    /** Calcula KPIs y series agregadas para el dashboard y Chart.js. */
    public function getDashboardMetrics(): array
    {
        // 1. KPI Cards (Consultas directas a nivel de motor de base de datos)
        $totalTrainings = Training::count();
        $totalHours = (int) Training::sum('duration_hours');
        $totalRequests = TrainingRequest::count();
        $pendingRequests = TrainingRequest::where('status', TrainingRequest::STATUS_PENDING)->count();
        $approvedRequests = TrainingRequest::where('status', TrainingRequest::STATUS_APPROVED)->count();
        $activeUsers = User::where('is_active', true)->count();
        $estimatedBeneficiaries = (int) TrainingRequest::where('status', TrainingRequest::STATUS_APPROVED)
            ->sum('estimated_participants');

        // 2. Gráfico 1: Capacitaciones por Categoría (Doughnut Chart)
        $categoriesWithCounts = TrainingCategory::withCount('trainings')
            ->having('trainings_count', '>', 0)
            ->orderByDesc('trainings_count')
            ->get();

        $categoryChartData = [
            'labels' => $categoriesWithCounts->pluck('name')->toArray(),
            'values' => $categoriesWithCounts->pluck('trainings_count')->toArray(),
        ];

        // 3. Gráfico 2: Solicitudes por Estado (Bar Chart)
        $statusCounts = TrainingRequest::select('status', DB::raw('count(*) as count'))
            ->groupBy('status')
            ->pluck('count', 'status')
            ->toArray();

        $statusChartData = [
            'labels' => ['Pendientes', 'En Revisión', 'Aprobadas', 'Rechazadas'],
            'values' => [
                $statusCounts[TrainingRequest::STATUS_PENDING] ?? 0,
                $statusCounts[TrainingRequest::STATUS_REVIEWING] ?? 0,
                $statusCounts[TrainingRequest::STATUS_APPROVED] ?? 0,
                $statusCounts[TrainingRequest::STATUS_REJECTED] ?? 0,
            ],
        ];

        // 4. Gráfico 3: Horas Acumuladas por Categoría Top
        $topCategoriesHours = Training::join('training_categories', 'trainings.category_id', '=', 'training_categories.id')
            ->select('training_categories.name', DB::raw('SUM(trainings.duration_hours) as total_hours'))
            ->groupBy('training_categories.name')
            ->orderByDesc('total_hours')
            ->limit(6)
            ->get();

        $trendChartData = [
            'labels' => $topCategoriesHours->pluck('name')->toArray(),
            'values' => $topCategoriesHours->pluck('total_hours')->map(fn($v) => (int)$v)->toArray(),
        ];

        return [
            'kpis' => [
                'total_trainings' => $totalTrainings,
                'total_hours' => $totalHours,
                'total_requests' => $totalRequests,
                'pending_requests' => $pendingRequests,
                'approved_requests' => $approvedRequests,
                'active_users' => $activeUsers,
                'estimated_beneficiaries' => $estimatedBeneficiaries,
            ],
            'chart_categories' => $categoryChartData,
            'chart_statuses' => $statusChartData,
            'chart_trends' => $trendChartData,
        ];
    }
}

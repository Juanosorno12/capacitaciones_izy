<?php

namespace App\Services;

use App\Models\Participant;
use App\Models\ScheduledTraining;
use App\Models\Training;
use App\Models\TrainingRequest;
use App\Models\User;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/** Contiene la lógica del flujo de solicitudes y su conversión a capacitaciones. */
class TrainingRequestService
{
    /** Lista solicitudes aplicando permisos, filtros, relaciones y paginación. */
    public function listRequests(array $filters = [], User $currentUser, int $perPage = 12): LengthAwarePaginator
    {
        $query = TrainingRequest::query()
            ->withStandardRelations();

        // Si el usuario no tiene permiso de aprobar, solo puede ver sus propias solicitudes
        if (!$currentUser->hasPermissionTo('requests.approve') && !$currentUser->hasPermissionTo('requests.review')) {
            $query->forUser($currentUser->id);
        }

        if (!empty($filters['status'])) {
            $query->byStatus($filters['status']);
        }

        if (!empty($filters['category_id'])) {
            $query->where('category_id', (int) $filters['category_id']);
        }

        if (($filters['value_added'] ?? 'all') !== 'all') {
            $query->where('value_added', $filters['value_added'] === 'yes');
        }

        if (!empty($filters['search'])) {
            $term = $filters['search'];
            $query->where(function ($q) use ($term) {
                $q->where('title', 'like', "%{$term}%")
                  ->orWhere('client_name', 'like', "%{$term}%")
                  ->orWhere('justification', 'like', "%{$term}%");
            });
        }

        return $query->latest()->paginate($perPage)->withQueryString();
    }

    /** Crea una solicitud y sincroniza sus participantes dentro de una transacción. */
    public function createRequest(array $data, int $requesterId): TrainingRequest
    {
        return DB::transaction(function () use ($data, $requesterId) {
            $training = Training::query()
                ->whereKey($data['training_id'])
                ->where('category_id', $data['category_id'])
                ->firstOrFail();

            $request = TrainingRequest::create([
                'requested_by_user_id' => $requesterId,
                'category_id' => $data['category_id'],
                'approved_training_id' => $training->id,
                'title' => $training->title,
                'value_added' => $data['value_added'],
                'client_name' => $data['client_name'],
                'justification' => $data['justification'],
                'estimated_participants' => $data['estimated_participants'] ?? 1,
                'status' => TrainingRequest::STATUS_PENDING,
            ]);

            $participantIds = [];
            foreach ($data['participants'] as $participantData) {
                $participantValues = [
                    'first_name' => trim($participantData['first_name']),
                    'last_name' => trim($participantData['last_name']),
                ];

                if (filled($participantData['phone'] ?? null)) {
                    $participantValues['phone'] = trim($participantData['phone']);
                }

                $participantValues['personal_email'] = filled($participantData['personal_email'] ?? null)
                    ? mb_strtolower(trim($participantData['personal_email']))
                    : null;
                $participantValues['city'] = trim($participantData['city']);

                $participant = Participant::updateOrCreate(
                    ['email' => mb_strtolower(trim($participantData['email']))],
                    $participantValues
                );

                $participantIds[] = $participant->id;
            }

            $request->participants()->sync($participantIds);

            return $request;
        });
    }

    /** Actualiza una solicitud únicamente mientras permanece pendiente. */
    public function updateRequest(TrainingRequest $request, array $data): TrainingRequest
    {
        if (!$request->isPending()) {
            throw ValidationException::withMessages([
                'status' => 'Solo es posible modificar solicitudes en estado Pendiente.',
            ]);
        }

        return DB::transaction(function () use ($request, $data) {
            $request->update([
                'category_id' => $data['category_id'],
                'title' => $data['title'],
                'justification' => $data['justification'],
                'estimated_participants' => $data['estimated_participants'] ?? $request->estimated_participants,
            ]);

            return $request;
        });
    }

    /** Cambia el estado de una solicitud a revisión. */
    public function markAsReviewing(TrainingRequest $request): TrainingRequest
    {
        if ($request->status === TrainingRequest::STATUS_APPROVED) {
            throw ValidationException::withMessages([
                'status' => 'Una solicitud ya aprobada no puede volver a revisión.',
            ]);
        }

        $request->update(['status' => TrainingRequest::STATUS_REVIEWING]);
        return $request;
    }

    /** Rechaza una solicitud y registra el motivo proporcionado. */
    public function rejectRequest(TrainingRequest $request, string $reason): TrainingRequest
    {
        return DB::transaction(function () use ($request, $reason) {
            $request->update([
                'status' => TrainingRequest::STATUS_REJECTED,
                'rejection_reason' => $reason,
            ]);

            return $request;
        });
    }

    /** Aprueba una solicitud y crea atómicamente su capacitación programada. */
    public function approveAndConvertToTraining(TrainingRequest $request, array $trainingData, int $adminUserId): array
    {
        return DB::transaction(function () use ($request, $trainingData, $adminUserId) {
            $expert = User::query()
                ->active()
                ->findOrFail($trainingData['expert_user_id']);

            $catalogTraining = $request->approvedTraining
                ?? Training::query()
                    ->where('category_id', $request->category_id)
                    ->where('title', $request->title)
                    ->latest('id')
                    ->first();
            if (!$catalogTraining) {
                throw ValidationException::withMessages([
                    'training_id' => 'La capacitación base de la solicitud no existe en el catálogo.',
                ]);
            }

            // 1. Crear una programación independiente vinculada al curso del catálogo
            $scheduledTraining = ScheduledTraining::create([
                'training_id' => $catalogTraining->id,
                'training_request_id' => $request->id,
                'created_by_user_id' => $adminUserId,
                'category_id' => $catalogTraining->category_id,
                'title' => $trainingData['title'] ?? $catalogTraining->title,
                'value_added' => $request->value_added,
                'description' => $trainingData['description'] ?? $catalogTraining->description,
                'expert_user_id' => $expert->id,
                'expert_name' => $expert->name,
                'duration_hours' => $trainingData['duration_hours'],
                'schedule_details' => 'Modalidad: '.($trainingData['modality'] === 'virtual' ? 'Virtual' : 'Presencial'),
                'modality' => $trainingData['modality'],
                'is_public_for_externals' => $catalogTraining->is_available_for_externals,
                'has_certificate' => (bool) $catalogTraining->has_certificate,
                'certificate_template_url' => $catalogTraining->certificate_template_url,
            ]);

            $scheduledTraining->sessions()->createMany($trainingData['sessions']);
            $scheduledTraining->participants()->sync($request->participants()->allRelatedIds()->all());

            // 2. Vincular la capacitación aprobada a la solicitud y actualizar estado
            $request->update([
                'status' => TrainingRequest::STATUS_APPROVED,
                'rejection_reason' => null,
            ]);

            return [
                'request' => $request,
                'training' => $catalogTraining,
                'scheduledTraining' => $scheduledTraining,
            ];
        });
    }

}

<?php

namespace App\Services;

use App\Models\Permission;
use App\Models\User;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;
use RuntimeException;
use Throwable;

/** Contiene la lógica de negocio para usuarios, fotos y permisos directos. */
class UserService
{
    /** Lista usuarios paginados con rol y permisos cargados anticipadamente. */
    public function listUsers(array $filters = [], int $perPage = 12): LengthAwarePaginator
    {
        $query = User::query()
            ->with(['role:id,name,slug', 'directPermissions:id,name']);

        if (!empty($filters['search'])) {
            $query->search($filters['search']);
        }

        if (!empty($filters['role_id'])) {
            $query->where('role_id', $filters['role_id']);
        }

        if (isset($filters['is_active']) && $filters['is_active'] !== '') {
            $query->where('is_active', (bool) $filters['is_active']);
        }

        return $query->latest()->paginate($perPage)->withQueryString();
    }

    /** Crea un usuario, almacena su foto y revierte la foto si la transacción falla. */
    public function createUser(array $data): User
    {
        $profilePhotoPath = null;

        if (isset($data['profile_photo'])) {
            $profilePhotoPath = $data['profile_photo']->storePublicly('users/profile-photos', 'public');

            if ($profilePhotoPath === false) {
                throw new RuntimeException('No fue posible guardar la foto de perfil.');
            }
        }

        try {
            return DB::transaction(function () use ($data, $profilePhotoPath) {
                return User::create([
                    'name' => $data['name'],
                    'email' => $data['email'],
                    'password' => Hash::make($data['password']),
                    'role_id' => $data['role_id'],
                    'is_active' => $data['is_active'] ?? true,
                    'profile_photo_path' => $profilePhotoPath,
                ]);
            });
        } catch (Throwable $exception) {
            if ($profilePhotoPath !== null) {
                Storage::disk('public')->delete($profilePhotoPath);
            }

            throw $exception;
        }
    }

    /** Actualiza datos del usuario aplicando protección contra auto-desactivación. */
    public function updateUser(User $user, array $data, int $currentUserId): User
    {
        // Regla de Auto-Protección: Un Administrador no puede desactivarse a sí mismo
        if ($user->id === $currentUserId && isset($data['is_active']) && ! $data['is_active']) {
            throw ValidationException::withMessages([
                'is_active' => 'Acción denegada: Un Administrador no puede desactivar su propia cuenta activa.',
            ]);
        }

        $previousProfilePhotoPath = $user->profile_photo_path;
        $newProfilePhotoPath = null;

        if (isset($data['profile_photo'])) {
            $newProfilePhotoPath = $data['profile_photo']->storePublicly('users/profile-photos', 'public');

            if ($newProfilePhotoPath === false) {
                throw new RuntimeException('No fue posible guardar la foto de perfil.');
            }
        }

        try {
            $updatedUser = DB::transaction(function () use ($user, $data, $newProfilePhotoPath) {
                $updateData = [
                    'name' => $data['name'],
                    'email' => $data['email'],
                    'role_id' => $data['role_id'],
                    'is_active' => $data['is_active'] ?? $user->is_active,
                ];

                if (!empty($data['password'])) {
                    $updateData['password'] = Hash::make($data['password']);
                }

                if ($newProfilePhotoPath !== null) {
                    $updateData['profile_photo_path'] = $newProfilePhotoPath;
                }

                $user->update($updateData);
                $user->flushPermissionCache();

                return $user;
            });
        } catch (Throwable $exception) {
            if ($newProfilePhotoPath !== null) {
                Storage::disk('public')->delete($newProfilePhotoPath);
            }

            throw $exception;
        }

        if ($newProfilePhotoPath !== null && $previousProfilePhotoPath !== null) {
            Storage::disk('public')->delete($previousProfilePhotoPath);
        }

        return $updatedUser;
    }

    /** Sincroniza permisos directos y evita que el usuario se quite su administración. */
    public function syncUserPermissions(User $user, array $permissionIds, int $currentUserId): void
    {
        // Regla de Auto-Protección: Un Administrador no puede despojarse del permiso de administración de usuarios
        if ($user->id === $currentUserId) {
            $userManagePermission = Permission::where('name', 'users.manage')->first();
            if ($userManagePermission && !in_array($userManagePermission->id, $permissionIds)) {
                // Si el permiso no viene en su rol base ni en directos, impedir revocarlo
                if (!$user->role?->hasPermission('users.manage')) {
                    throw ValidationException::withMessages([
                        'permissions' => 'Acción denegada: No puedes revocar tu propio permiso de administración de usuarios (users.manage).',
                    ]);
                }
            }
        }

        DB::transaction(function () use ($user, $permissionIds) {
            $user->directPermissions()->sync($permissionIds);
            $user->flushPermissionCache();
        });
    }
}

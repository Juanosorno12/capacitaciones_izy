<?php

namespace App\Services;

use App\Models\Role;
use App\Models\Training;
use App\Models\User;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;

/** Contiene las reglas de negocio para consultar y administrar capacitaciones. */
class TrainingService
{
    /** Lista capacitaciones con filtros, paginación y control de visibilidad externa. */
    public function listTrainings(array $filters = [], ?User $currentUser = null, int $perPage = 12): LengthAwarePaginator
    {
        $query = Training::query()
            ->withStandardRelations();

        // Control de visibilidad estricto para rol Externos
        if ($currentUser && $currentUser->hasRole(Role::SLUG_EXTERNAL)) {
            $query->publicForExternals();
        }

        if (!empty($filters['category_id'])) {
            $query->byCategory((int) $filters['category_id']);
        }

        if (!empty($filters['search'])) {
            $query->search($filters['search']);
        }

        if (isset($filters['has_certificate']) && $filters['has_certificate'] !== '') {
            $query->where('has_certificate', (bool) $filters['has_certificate']);
        }

        return $query->latest()->paginate($perPage)->withQueryString();
    }

    /** Crea un registro de catálogo dentro de una transacción. */
    public function createTraining(array $data, int $creatorId): Training
    {
        return DB::transaction(function () use ($data, $creatorId) {
            $data['created_by_user_id'] = $creatorId;
            $data['is_public_for_externals'] = (bool) ($data['for_external_staff'] ?? false);
            $data['expert_name'] = 'izyacademy';

            return Training::create($data);
        });
    }

    /** Actualiza la capacitación y reemplaza sus sesiones en una transacción. */
    public function updateTraining(Training $training, array $data): Training
    {
        return DB::transaction(function () use ($training, $data) {
            $data['is_public_for_externals'] = (bool) ($data['for_external_staff'] ?? false);
            $training->update($data);

            return $training;
        });
    }

    /** Elimina una capacitación dentro de una transacción. */
    public function deleteTraining(Training $training): bool
    {
        return DB::transaction(function () use ($training) {
            return $training->delete();
        });
    }
}

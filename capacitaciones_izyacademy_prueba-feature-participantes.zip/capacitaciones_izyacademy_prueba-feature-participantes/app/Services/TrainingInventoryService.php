<?php

namespace App\Services;

use App\Imports\TrainingInventoryImport;
use App\Models\Training;
use App\Models\TrainingCategory;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Facades\Excel;

/** Validates and persists the mass training inventory workflow. */
class TrainingInventoryService
{
    public const REQUIRED_FIELDS = [
        'categoria',
        'curso o certificacion',
        'nombre del curso o certificacion',
        'descripcion',
        'temario del curso',
        'intensidad horaria',
        'insignia digital',
        'para personal interno',
        'para personal externo',
    ];

    /** Parses and validates a workbook without changing the database. */
    public function preview(string $path): array
    {
        $import = new TrainingInventoryImport();
        Excel::import($import, Storage::disk('local')->path($path));
        $rows = $import->rows;
        $errors = [];
        $validRows = [];
        $seenIds = [];

        foreach ($rows as $row) {
            $rowErrors = $this->validateRow($row, $seenIds);
            if ($rowErrors !== []) {
                $errors[] = [
                    'row' => $row['_row'],
                    'messages' => $rowErrors,
                ];
            }

            if (!empty($row['id sistema'])) {
                $seenIds[(int) $row['id sistema']] = true;
            }

            if ($rowErrors === []) {
                $validRows[] = $row;
            }
        }

        foreach ($import->headerErrors as $headerError) {
            $errors[] = ['row' => 'Encabezados', 'messages' => [$headerError]];
        }

        return [
            'rows' => $rows,
            'valid_rows' => $validRows,
            'errors' => $errors,
            'header_errors' => $import->headerErrors,
            'total' => count($rows),
            'valid_count' => count($validRows),
            'invalid_count' => count($errors),
        ];
    }

    /** Persists valid rows and returns a summary while preserving row-level failures. */
    public function process(string $path, int $creatorId): array
    {
        $preview = $this->preview($path);
        $created = 0;
        $updated = 0;

        foreach ($preview['valid_rows'] as $row) {
            DB::transaction(function () use ($row, $creatorId, &$created, &$updated): void {
                $categoryName = $row['categoria'];
                $category = TrainingCategory::firstOrCreate(
                    ['name' => $categoryName],
                    ['slug' => $this->uniqueCategorySlug($categoryName)]
                );

                $isUpdate = !empty($row['id sistema']);
                $training = $isUpdate ? Training::findOrFail((int) $row['id sistema']) : null;
                $externalEligibility = $this->parseBoolean($row['para personal externo'] ?? null)
                    ?? $training?->for_external_staff
                    ?? $training?->is_public_for_externals;
                $attributes = [
                    'category_id' => $category->id,
                    'title' => $row['nombre del curso o certificacion'] ?? $training?->title,
                    'course_type' => $row['curso o certificacion'] ?? $training?->course_type,
                    'training_provider' => array_key_exists('proveedor de formacion', $row)
                        ? $row['proveedor de formacion']
                        : $training?->training_provider,
                    'shopping_cart_project' => array_key_exists('proyecto carrito de compras', $row)
                        ? $row['proyecto carrito de compras']
                        : $training?->shopping_cart_project,
                    'description' => $row['descripcion'] ?? $training?->description,
                    'syllabus' => $row['temario del curso'] ?? $training?->syllabus,
                    'subtitles' => array_key_exists('subtitulos', $row) ? $row['subtitulos'] : $training?->subtitles,
                    'prerequisites' => array_key_exists('prerequisitos', $row) ? $row['prerequisitos'] : $training?->prerequisites,
                    'level' => array_key_exists('nivel', $row) ? $row['nivel'] : $training?->level,
                    'duration_hours' => isset($row['intensidad horaria']) ? (int) $row['intensidad horaria'] : $training?->duration_hours,
                    'digital_badge' => $this->parseBoolean($row['insignia digital'] ?? null) ?? $training?->digital_badge,
                    'for_internal_staff' => $this->parseBoolean($row['para personal interno'] ?? null) ?? $training?->for_internal_staff,
                    'for_external_staff' => $externalEligibility,
                    'is_public_for_externals' => $externalEligibility,
                    'has_certificate' => array_key_exists('genera certificado', $row)
                        ? ($this->parseBoolean($row['genera certificado']) ?? false)
                        : ($training?->has_certificate ?? false),
                ];

                if ($isUpdate) {
                    $training->update($attributes);
                    $updated++;
                } else {
                    $attributes['created_by_user_id'] = $creatorId;
                    Training::create($attributes);
                    $created++;
                }
            });
        }

        $preview['created_count'] = $created;
        $preview['updated_count'] = $updated;

        return $preview;
    }

    /** Validates the canonical required fields and duplicate/existing IDs. */
    private function validateRow(array $row, array $seenIds): array
    {
        $errors = [];

        $training = null;
        $idValue = $row['id sistema'] ?? null;
        if ($idValue !== null && $idValue !== '') {
            if (!ctype_digit((string) $idValue) || (int) $idValue < 1) {
                $errors[] = 'ID Sistema debe ser un número entero positivo.';
            } elseif (isset($seenIds[(int) $idValue])) {
                $errors[] = 'El ID Sistema aparece repetido en el archivo.';
            } else {
                $training = Training::find((int) $idValue);
                if (!$training) {
                    $errors[] = 'El ID Sistema no existe en el catálogo.';
                }
            }
        }

        foreach (self::REQUIRED_FIELDS as $field) {
            if (empty($row[$field]) && !$training) {
                $errors[] = "El campo '{$field}' es obligatorio.";
            }
        }

        if (
            !empty($row['curso o certificacion'])
            && !in_array($row['curso o certificacion'], ['Curso', 'Certificación'], true)
            && (!$training || $row['curso o certificacion'] !== $training->course_type)
        ) {
            $errors[] = "El campo 'curso o certificacion' debe ser Curso o Certificación.";
        }

        $duration = $row['intensidad horaria'] ?? null;
        if ($duration !== null && $duration !== '' && (
            !ctype_digit((string) $duration)
            || (int) $duration < 1
            || (int) $duration > 500
        )) {
            $errors[] = 'Intensidad Horaria debe ser un número entero entre 1 y 500.';
        }

        foreach (['insignia digital', 'para personal interno', 'para personal externo', 'genera certificado'] as $field) {
            if (!empty($row[$field]) && $this->parseBoolean($row[$field]) === null) {
                $errors[] = "El campo '{$field}' solo acepta Sí o No.";
            }
        }

        return $errors;
    }

    private function parseBoolean(?string $value): ?bool
    {
        if ($value === null) {
            return null;
        }

        return match (Str::lower(Str::ascii(trim($value)))) {
            'si' => true,
            'no' => false,
            default => null,
        };
    }

    private function uniqueCategorySlug(string $name): string
    {
        $base = Str::slug($name);
        $slug = $base;
        $counter = 2;

        while (TrainingCategory::where('slug', $slug)->exists()) {
            $slug = "{$base}-{$counter}";
            $counter++;
        }

        return $slug;
    }
}

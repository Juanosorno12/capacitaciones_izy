<?php

namespace App\Services;

use App\Models\AuditLog;
use Illuminate\Http\Request;

/** Centralizes creation of immutable audit records without sensitive payloads. */
class AuditLogService
{
    public function record(
        string $action,
        string $description,
        ?string $entityType = null,
        ?int $entityId = null,
        array $metadata = [],
        ?Request $request = null,
        ?int $userId = null
    ): AuditLog {
        $request ??= request();
        $userId ??= $request->user()?->id;

        return AuditLog::create([
            'user_id' => $userId,
            'action' => $action,
            'entity_type' => $entityType,
            'entity_id' => $entityId,
            'description' => $description,
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent(),
            'metadata' => $metadata,
        ]);
    }
}

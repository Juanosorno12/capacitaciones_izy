<?php

namespace App\Exports;

use App\Models\Training;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Events\AfterSheet;

/** Exports the complete training inventory in the import-compatible format. */
class TrainingInventoryExport implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize, WithEvents
{
    /** Returns all catalog records with their categories. */
    public function collection(): Collection
    {
        return Training::query()
            ->with('category:id,name')
            ->orderBy('id')
            ->get();
    }

    /** Defines the stable import/export contract. */
    public function headings(): array
    {
        return [
            'ID Sistema',
            'Categoria',
            'Curso o Certificación',
            'Proveedor de Formación',
            'Proyecto Carrito de Compras',
            'Nombre del Curso o Certificación',
            'Descripción',
            'Temario del Curso',
            'Subtítulos',
            'Prerequisitos',
            'Nivel',
            'Intensidad Horaria',
            'Insignia Digital',
            'Para Personal Interno',
            'Para Personal Externo',
            'Genera Certificado',
        ];
    }

    /** Maps a training model to the canonical inventory columns. */
    public function map($training): array
    {
        return [
            $training->id,
            $training->category?->name,
            $training->course_type,
            $training->training_provider,
            $training->shopping_cart_project,
            $training->title,
            $training->description,
            $training->syllabus,
            $training->subtitles,
            $training->prerequisites,
            $training->level,
            $training->duration_hours,
            $this->booleanLabel($training->digital_badge),
            $this->booleanLabel($training->for_internal_staff),
            $this->booleanLabel($training->for_external_staff),
            $this->booleanLabel($training->has_certificate),
        ];
    }

    /** Keeps the backend identifier available for round-trip updates without displaying it. */
    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event): void {
                $event->sheet->getDelegate()->getColumnDimension('A')->setVisible(false);
            },
        ];
    }

    private function booleanLabel(?bool $value): ?string
    {
        return $value === null ? null : ($value ? 'Sí' : 'No');
    }
}

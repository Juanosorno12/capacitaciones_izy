<?php

namespace App\Exceptions;

use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Throwable;

/** Centraliza la configuración de reporte y manejo de excepciones. */
class Handler extends ExceptionHandler
{
    /**
     * The list of the inputs that are never flashed to the session on validation exceptions.
     *
     * @var array<int, string>
     */
    protected $dontFlash = [
        'current_password',
        'password',
        'password_confirmation',
    ];

    /** Registra callbacks para reportar excepciones de la aplicación. */
    public function register(): void
    {
        $this->reportable(function (Throwable $e) {
            //
        });
    }
}

<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

/** Configura el kernel de comandos y tareas programadas de la aplicación. */
class Kernel extends ConsoleKernel
{
    /** Define las tareas que Laravel ejecutará de forma programada. */
    protected function schedule(Schedule $schedule): void
    {
        // $schedule->command('inspire')->hourly();
    }

    /** Carga comandos propios y las definiciones de routes/console.php. */
    protected function commands(): void
    {
        $this->load(__DIR__.'/Commands');

        if (file_exists(base_path('routes/console.php'))) {
            require base_path('routes/console.php');
        }
    }
}

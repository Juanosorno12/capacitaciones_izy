<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/** Autoriza una ruta usando un permiso dinámico del usuario autenticado. */
class CheckPermission
{
    /** Verifica autenticación, estado activo y permiso antes de continuar. */
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     * @param  string  $permission
     */
    public function handle(Request $request, Closure $next, string $permission): Response
    {
        $user = $request->user();

        if (!$user) {
            return redirect()->route('login');
        }

        if (!$user->isActive()) {
            auth()->logout();
            return redirect()->route('login')->withErrors([
                'email' => 'Tu cuenta corporativa ha sido desactivada. Comunícate con el Administrador.',
            ]);
        }

        if (!$user->hasPermissionTo($permission)) {
            abort(403, "Acceso restringido: No cuentas con el permiso institucional requerido [{$permission}].");
        }

        return $next($request);
    }
}

<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/** Evita que usuarios autenticados accedan a pantallas de invitados. */
class RedirectIfAuthenticated
{
    /** Redirige al dashboard si alguno de los guardias ya tiene una sesión activa. */
    public function handle(Request $request, Closure $next, ...$guards): Response
    {
        foreach ($guards ?: [null] as $guard) {
            if (auth()->guard($guard)->check()) {
                return redirect()->route('dashboard');
            }
        }

        return $next($request);
    }
}

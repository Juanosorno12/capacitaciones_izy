<?php

namespace App\Http\Requests;

use App\Rules\WebpImage;
use Illuminate\Foundation\Http\FormRequest;

/** Valida la creación de un usuario corporativo. */
class StoreUserRequest extends FormRequest
{
    /** Autoriza la operación mediante el permiso de administración de usuarios. */
    public function authorize(): bool
    {
        return $this->user()?->hasPermissionTo('users.manage') ?? false;
    }

    /** Define reglas para identidad, rol, contraseña, estado y foto. */
    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users,email'],
            'password' => [
                'required',
                'string',
                'min:10',
                'regex:~^(?=.*\p{Lu})(?=.*\p{N})(?=.*[^\p{L}\p{N}\s]).+$~u',
                'confirmed',
            ],
            'role_id' => ['required', 'exists:roles,id'],
            'is_active' => ['nullable', 'boolean'],
            'profile_photo' => ['nullable', 'file', new WebpImage, 'max:2048'],
        ];
    }

    /** Personaliza los mensajes de validación del usuario. */
    public function messages(): array
    {
        return [
            'email.unique' => 'Ya existe un usuario registrado con este correo electrónico.',
            'password.min' => 'La contraseña debe tener al menos 10 caracteres.',
            'password.regex' => 'La contraseña debe incluir al menos una mayúscula, un número y un carácter especial.',
            'password.confirmed' => 'La confirmación de contraseña no coincide.',
            'role_id.exists' => 'El rol seleccionado no es válido.',
            'profile_photo.max' => 'La foto de perfil no puede superar los 2 MB.',
        ];
    }
}

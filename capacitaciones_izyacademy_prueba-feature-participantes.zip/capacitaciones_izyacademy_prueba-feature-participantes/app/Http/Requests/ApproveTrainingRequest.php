<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Validator;

/** Valida acciones de revisión, aprobación y rechazo de solicitudes. */
class ApproveTrainingRequest extends FormRequest
{
    /** Autoriza únicamente a usuarios con permiso de aprobación. */
    public function authorize(): bool
    {
        return $this->user()?->hasPermissionTo('requests.approve') ?? false;
    }

    /** Define los campos y reglas según la acción solicitada. */
    public function rules(): array
    {
        return [
            'action' => ['required', 'in:approve,reject,review'],
            'rejection_reason' => ['required_if:action,reject', 'nullable', 'string', 'max:1000'],

            // Datos requeridos solo si action == approve (conversión a capacitación programada)
            'expert_user_id' => ['required_if:action,approve', 'nullable', 'exists:users,id,is_active,1'],
            'duration_hours' => ['required_if:action,approve', 'nullable', 'integer', 'min:1', 'max:500'],
            'modality' => ['required_if:action,approve', 'nullable', 'in:virtual,presencial'],
            'sessions' => ['required_if:action,approve', 'array', 'min:1', 'max:100'],
            'sessions.*.session_date' => ['required_if:action,approve', 'date_format:Y-m-d'],
            'sessions.*.start_time' => ['required_if:action,approve', 'date_format:H:i'],
            'sessions.*.end_time' => ['required_if:action,approve', 'date_format:H:i'],
        ];
    }

    /** Agrega validaciones condicionales para datos de aprobación. */
    public function withValidator(Validator $validator): void
    {
        $validator->after(function (Validator $validator): void {
            if ($this->input('action') !== 'approve') {
                return;
            }

            foreach ($this->input('sessions', []) as $index => $session) {
                $start = $session['start_time'] ?? null;
                $end = $session['end_time'] ?? null;

                if (
                    is_string($start)
                    && is_string($end)
                    && preg_match('/^\d{2}:\d{2}$/', $start)
                    && preg_match('/^\d{2}:\d{2}$/', $end)
                    && $end <= $start
                ) {
                    $validator->errors()->add(
                        "sessions.{$index}.end_time",
                        'La hora de finalización debe ser posterior a la hora de inicio.'
                    );
                }
            }
        });
    }

    /** Personaliza los mensajes de validación mostrados al usuario. */
    public function messages(): array
    {
        return [
            'rejection_reason.required_if' => 'Debes especificar el motivo corporativo del rechazo.',
            'expert_user_id.required_if' => 'Para aprobar y programar la capacitación, debes seleccionar el facilitador/experto.',
            'duration_hours.required_if' => 'Debes indicar la duración estimada en horas.',
            'modality.required_if' => 'Debes seleccionar la modalidad de la capacitación.',
            'sessions.required_if' => 'Debes agregar al menos una sesión con fecha y horario para programar la capacitación.',
        ];
    }
}

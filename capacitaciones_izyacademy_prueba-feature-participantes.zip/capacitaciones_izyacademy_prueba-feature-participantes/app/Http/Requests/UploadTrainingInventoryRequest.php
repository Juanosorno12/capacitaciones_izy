<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

/** Authorizes and validates inventory workbook uploads. */
class UploadTrainingInventoryRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->hasPermissionTo('trainings.import') ?? false;
    }

    public function rules(): array
    {
        return [
            'inventory_file' => [
                'required',
                'file',
                'mimes:xlsx,xls',
                'max:8000',
            ],
        ];
    }

    public function attributes(): array
    {
        return [
            'inventory_file' => 'archivo de inventario',
        ];
    }
}

<?php

namespace App\Http\Requests;

use App\Rules\WebpImage;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

/** Valida la actualización de un usuario corporativo. */
class UpdateUserRequest extends FormRequest
{
    /** Autoriza la operación mediante el permiso de administración de usuarios. */
    public function authorize(): bool
    {
        return $this->user()?->hasPermissionTo('users.manage') ?? false;
    }

    /** Define reglas para datos, rol, estado, contraseña y foto opcional. */
    public function rules(): array
    {
        $userId = $this->route('user')?->id ?? $this->route('user');

        return [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', Rule::unique('users', 'email')->ignore($userId)],
            'password' => ['nullable', 'string', 'min:8', 'confirmed'],
            'role_id' => ['required', 'exists:roles,id'],
            'is_active' => ['nullable', 'boolean'],
            'profile_photo' => ['nullable', 'file', new WebpImage, 'max:2048'],
        ];
    }

    /** Personaliza los mensajes de validación de actualización. */
    public function messages(): array
    {
        return [
            'email.unique' => 'Este correo electrónico ya está en uso por otra cuenta.',
            'password.confirmed' => 'La confirmación de la nueva contraseña no coincide.',
            'profile_photo.max' => 'La foto de perfil no puede superar los 2 MB.',
        ];
    }
}

<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Validator;

/** Valida y normaliza los filtros utilizados por los reportes. */
class ReportFilterRequest extends FormRequest
{
    /** Completa valores de periodo antes de ejecutar la validación. */
    protected function prepareForValidation(): void
    {
        $this->merge([
            'period' => $this->input('period', 'month'),
            'month' => $this->input('month', now(config('app.timezone'))->format('Y-m')),
        ]);
    }

    /** Autoriza el acceso cuando el usuario tiene permiso de reportes. */
    public function authorize(): bool
    {
        return $this->user()?->hasPermissionTo('reports.view') ?? false;
    }

    /** Define los filtros de periodo y valor agregado permitidos. */
    public function rules(): array
    {
        return [
            'period' => ['required', 'in:month,date_range,month_range'],
            'month' => ['required_if:period,month', 'nullable', 'date_format:Y-m'],
            'date_from' => ['required_if:period,date_range', 'nullable', 'date_format:Y-m-d'],
            'date_to' => ['required_if:period,date_range', 'nullable', 'date_format:Y-m-d'],
            'month_from' => ['required_if:period,month_range', 'nullable', 'date_format:Y-m'],
            'month_to' => ['required_if:period,month_range', 'nullable', 'date_format:Y-m'],
            'value_added' => ['nullable', 'in:all,yes,no'],
        ];
    }

    /** Verifica que las fechas y rangos enviados sean coherentes. */
    public function withValidator(Validator $validator): void
    {
        $validator->after(function (Validator $validator): void {
            $period = $this->input('period');
            $from = $period === 'date_range' ? $this->input('date_from') : $this->input('month_from');
            $to = $period === 'date_range' ? $this->input('date_to') : $this->input('month_to');

            if (
                in_array($period, ['date_range', 'month_range'], true)
                && is_string($from)
                && is_string($to)
                && $from > $to
            ) {
                $validator->errors()->add(
                    $period === 'date_range' ? 'date_to' : 'month_to',
                    'La fecha final debe ser igual o posterior a la fecha inicial.'
                );
            }
        });
    }

    /** Define mensajes claros para errores de filtros. */
    public function messages(): array
    {
        return [
            'period.required' => 'Selecciona el tipo de periodo que deseas consultar.',
            'period.in' => 'El tipo de periodo seleccionado no es válido.',
            'month.required_if' => 'Selecciona el mes que deseas consultar.',
            'date_from.required_if' => 'Selecciona la fecha inicial del reporte.',
            'date_to.required_if' => 'Selecciona la fecha final del reporte.',
            'month_from.required_if' => 'Selecciona el mes inicial del reporte.',
            'month_to.required_if' => 'Selecciona el mes final del reporte.',
        ];
    }
}

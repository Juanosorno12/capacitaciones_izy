<?php

namespace App\Http\Requests;

use App\Models\Training;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Validator;

/** Valida el formulario de creación de solicitudes de capacitación. */
class StoreTrainingRequestForm extends FormRequest
{
    /** Autoriza la creación de solicitudes para usuarios autenticados. */
    public function authorize(): bool
    {
        return $this->user()?->hasPermissionTo('requests.create') ?? false;
    }

    /** Define reglas para necesidad, categoría y participantes. */
    public function rules(): array
    {
        return [
            'category_id' => ['required', 'exists:training_categories,id'],
            'training_id' => ['required', Rule::exists('trainings', 'id')],
            'value_added' => ['required', 'boolean'],
            'client_name' => ['required', 'string', 'max:255'],
            'justification' => ['required', 'string', 'min:20', 'max:2000'],
            'estimated_participants' => ['required', 'integer', 'min:1', 'max:1000'],
            ...self::participantRules(),
        ];
    }

    /** Normaliza valores recibidos antes de validar el formulario. */
    protected function prepareForValidation(): void
    {
        $this->merge([
            'value_added' => $this->boolean('value_added'),
        ]);
    }

    /** Verifica consistencia adicional entre capacitación y categoría. */
    public function withValidator(Validator $validator): void
    {
        $validator->after(function (Validator $validator): void {
            if (
                $validator->errors()->has('category_id')
                || $validator->errors()->has('training_id')
            ) {
                return;
            }

            $trainingMatchesCategory = Training::query()
                ->whereKey($this->input('training_id'))
                ->where('category_id', $this->input('category_id'))
                ->exists();

            if (! $trainingMatchesCategory) {
                $validator->errors()->add(
                    'training_id',
                    'La capacitación seleccionada no pertenece a la categoría elegida.'
                );
            }
        });
    }

    public static function participantRules(): array
    {
        return [
            'participants' => ['required', 'array', 'min:1', 'max:1000'],
            'participants.*.first_name' => ['required', 'string', 'max:100'],
            'participants.*.last_name' => ['required', 'string', 'max:150'],
            'participants.*.email' => [
                'required',
                "regex:~^(?:[A-Z0-9!#$%&'*+/=?^_`{|}\\~-]|ñ|Ñ)+(?:\\.(?:[A-Z0-9!#$%&'*+/=?^_`{|}\\~-]|ñ|Ñ)+)*@(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\\.)+[A-Z]{2,}(?:\\.[A-Z]{2,})*$~iu",
                'max:255',
                'distinct:ignore_case',
            ],
            'participants.*.personal_email' => [
                'nullable',
                "regex:~^(?:[A-Z0-9!#$%&'*+/=?^_`{|}\\~-]|ñ|Ñ)+(?:\\.(?:[A-Z0-9!#$%&'*+/=?^_`{|}\\~-]|ñ|Ñ)+)*@(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\\.)+[A-Z]{2,}(?:\\.[A-Z]{2,})*$~iu",
                'max:255',
            ],
            'participants.*.phone' => ['required', 'string', 'max:30'],
            'participants.*.city' => ['required', 'string', 'max:100'],
        ];
    }

    /** Personaliza los mensajes de validación del formulario. */
    public function messages(): array
    {
        return [
            'category_id.required' => 'Debes seleccionar una categoría temática para la capacitación.',
            'training_id.required' => 'Debes seleccionar una capacitación de la categoría elegida.',
            'training_id.exists' => 'La capacitación seleccionada no es válida.',
            'value_added.boolean' => 'El indicador de valor agregado no es válido.',
            'justification.min' => 'La justificación corporativa debe contener al menos 20 caracteres detallando la necesidad técnica.',
            'estimated_participants.min' => 'Debes ingresar al menos 1 participante estimado.',
            'participants.required' => 'Debes agregar al menos un participante.',
            'participants.min' => 'Debes agregar al menos un participante.',
            'participants.max' => 'No puedes agregar más de 1000 participantes.',
            'participants.*.first_name.required' => 'El nombre de cada participante es obligatorio.',
            'participants.*.last_name.required' => 'Los apellidos de cada participante son obligatorios.',
            'participants.*.email.required' => 'El correo electrónico de cada participante es obligatorio.',
            'participants.*.email.regex' => 'Ingresa un correo electrónico válido para cada participante.',
            'participants.*.email.distinct' => 'No puedes registrar el mismo correo más de una vez en esta solicitud.',
            'participants.*.personal_email.regex' => 'Ingresa un correo personal válido para cada participante.',
            'participants.*.phone.required' => 'El celular de cada participante es obligatorio.',
            'participants.*.city.required' => 'La ciudad de cada participante es obligatoria.',
        ];
    }
}

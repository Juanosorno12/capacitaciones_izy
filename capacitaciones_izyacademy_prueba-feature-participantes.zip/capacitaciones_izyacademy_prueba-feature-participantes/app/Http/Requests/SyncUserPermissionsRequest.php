<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

/** Valida la sincronización de permisos directos de un usuario. */
class SyncUserPermissionsRequest extends FormRequest
{
    /** Autoriza a quien posee permiso para gestionar permisos. */
    public function authorize(): bool
    {
        return $this->user()?->hasPermissionTo('users.permissions') ?? false;
    }

    /** Acepta una lista opcional de identificadores de permisos válidos. */
    public function rules(): array
    {
        return [
            'permissions' => ['nullable', 'array'],
            'permissions.*' => ['exists:permissions,id'],
        ];
    }
}

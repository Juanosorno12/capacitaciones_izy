<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

/** Valida los datos necesarios para crear una capacitación. */
class StoreTrainingRequest extends FormRequest
{
    /** Autoriza a usuarios con permiso para administrar capacitaciones. */
    public function authorize(): bool
    {
        return $this->user()?->hasPermissionTo('trainings.manage') ?? false;
    }

    /** Define las reglas del registro académico del catálogo. */
    public function rules(): array
    {
        return [
            'category_id' => ['required', 'exists:training_categories,id'],
            'course_type' => ['required', 'in:Curso,Certificación'],
            'training_provider' => ['nullable', 'string', 'max:255'],
            'shopping_cart_project' => ['nullable', 'string', 'max:255'],
            'title' => ['required', 'string', 'max:255'],
            'description' => ['required', 'string'],
            'syllabus' => ['required', 'string'],
            'subtitles' => ['nullable', 'string'],
            'prerequisites' => ['nullable', 'string'],
            'level' => ['nullable', 'string', 'max:255'],
            'duration_hours' => ['required', 'integer', 'min:1', 'max:500'],
            'digital_badge' => ['required', 'boolean'],
            'for_internal_staff' => ['required', 'boolean'],
            'for_external_staff' => ['required', 'boolean'],
            'has_certificate' => ['required', 'boolean'],
            'certificate_template_url' => ['nullable', 'url', 'max:500'],
        ];
    }

}

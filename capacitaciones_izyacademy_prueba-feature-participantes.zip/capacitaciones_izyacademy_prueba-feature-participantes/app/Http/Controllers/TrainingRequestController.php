<?php

namespace App\Http\Controllers;

use App\Http\Requests\ApproveTrainingRequest;
use App\Http\Requests\StoreTrainingRequestForm;
use App\Models\Training;
use App\Models\TrainingCategory;
use App\Models\TrainingRequest;
use App\Models\User;
use App\Services\TrainingRequestService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use App\Services\AuditLogService;

/** Gestiona las solicitudes de capacitación y su flujo de aprobación. */
class TrainingRequestController extends Controller
{
    /** Servicio que aplica las reglas del flujo de solicitudes. */
    public function __construct(
        protected TrainingRequestService $requestService,
        protected AuditLogService $auditLog
    ) {}

    /** Lista solicitudes filtradas por estado, categoría, texto y valor agregado. */
    public function index(Request $request): View
    {
        $filters = $request->validate([
            'status' => ['nullable', 'in:pending,reviewing,approved,rejected'],
            'category_id' => ['nullable', 'integer', 'exists:training_categories,id'],
            'search' => ['nullable', 'string', 'max:255'],
            'value_added' => ['nullable', 'in:all,yes,no'],
            'view' => ['nullable', 'in:grid,table'],
        ]);
        $requests = $this->requestService->listRequests($filters, $request->user(), 12);
        $categories = TrainingCategory::getCachedAll();

        return view('requests.index', [
            'requests' => $requests,
            'categories' => $categories,
            'filters' => $filters,
        ]);
    }

    /** Prepara el formulario de solicitud y las capacitaciones agrupadas por categoría. */
    public function create(Request $request): View
    {
        $categories = TrainingCategory::getCachedAll();
        $selectedTraining = $request->query('training_id') !== null
            ? Training::query()->findOrFail($request->integer('training_id'))
            : null;
        $trainingsByCategory = Training::query()
            ->orderBy('title')
            ->get(['id', 'category_id', 'title'])
            ->groupBy('category_id')
            ->map(fn ($trainings) => $trainings->map(fn (Training $training) => [
                'id' => $training->id,
                'title' => $training->title,
            ])->values());

        return view('requests.create', [
            'categories' => $categories,
            'selectedTraining' => $selectedTraining,
            'trainingsByCategory' => $trainingsByCategory,
        ]);
    }

    /** Valida y registra una nueva solicitud mediante el servicio correspondiente. */
    public function store(StoreTrainingRequestForm $request): RedirectResponse
    {
        $trainingRequest = $this->requestService->createRequest(
            $request->validated(),
            $request->user()->id
        );

        return redirect()->route('requests.index')
            ->with('success', "Solicitud '{$trainingRequest->title}' registrada exitosamente.");
    }

    /** Muestra el detalle de una solicitud y los expertos activos disponibles. */
    public function show(Request $request, TrainingRequest $trainingRequest): View
    {
        // Si no tiene permiso de aprobación ni revisión, solo puede ver sus propias solicitudes
        if (!$request->user()->hasPermissionTo('requests.approve') && !$request->user()->hasPermissionTo('requests.review')) {
            if ($trainingRequest->requested_by_user_id !== $request->user()->id) {
                abort(403, 'No tienes autorización para ver esta solicitud.');
            }
        }

        $trainingRequest->load(['category', 'requester', 'approvedTraining', 'participants']);
        $experts = User::query()
            ->active()
            ->orderBy('name')
            ->get(['id', 'name']);

        return view('requests.show', [
            'trainingRequest' => $trainingRequest,
            'experts' => $experts,
        ]);
    }

    /** Ejecuta la transición solicitada: revisión, aprobación o rechazo. */
    public function review(ApproveTrainingRequest $request, TrainingRequest $trainingRequest): RedirectResponse
    {
        $action = $request->input('action');

        if ($action === 'review') {
            $this->requestService->markAsReviewing($trainingRequest);
            return back()->with('info', "La solicitud #{$trainingRequest->id} ha pasado a estado 'En Revisión'.");
        }

        if ($action === 'reject') {
            $this->requestService->rejectRequest($trainingRequest, $request->input('rejection_reason'));
            $this->auditLog->record('request.rejected', "Solicitud #{$trainingRequest->id} rechazada.", TrainingRequest::class, $trainingRequest->id);
            return back()->with('warning', "La solicitud #{$trainingRequest->id} ha sido rechazada.");
        }

        if ($action === 'approve') {
            $result = $this->requestService->approveAndConvertToTraining(
                $trainingRequest,
                $request->validated(),
                $request->user()->id
            );
            $this->auditLog->record('request.approved', "Solicitud #{$trainingRequest->id} aprobada y programada.", TrainingRequest::class, $trainingRequest->id);

            return redirect()->route('trainings.show', $result['training'])
                ->with('success', "¡Solicitud aprobada con éxito! Se ha programado la capacitación institucional automáticamente.");
        }

        return back();
    }
}

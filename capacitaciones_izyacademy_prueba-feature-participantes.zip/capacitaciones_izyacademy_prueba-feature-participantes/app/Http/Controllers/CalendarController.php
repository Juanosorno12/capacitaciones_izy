<?php

namespace App\Http\Controllers;

use App\Models\Role;
use App\Models\ScheduledTrainingSession;
use App\Models\TrainingSession;
use Carbon\CarbonImmutable;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** Construye el calendario de sesiones de capacitación para administradores. */
class CalendarController extends Controller
{
    /**
     * Obtiene las sesiones del periodo solicitado y prepara la vista diaria,
     * semanal o mensual con navegación entre periodos.
     */
    public function index(Request $request): View
    {
        abort_unless($request->user()->hasRole(Role::SLUG_ADMIN), 403);

        $filters = $request->validate([
            'view' => ['sometimes', 'in:day,week,month'],
            'date' => ['sometimes', 'date_format:Y-m-d'],
        ]);

        $view = $filters['view'] ?? 'month';
        $selectedDate = isset($filters['date'])
            ? CarbonImmutable::createFromFormat('!Y-m-d', $filters['date'], config('app.timezone'))
            : CarbonImmutable::now(config('app.timezone'));

        $periodStart = match ($view) {
            'day' => $selectedDate->startOfDay(),
            'week' => $selectedDate->startOfWeek(CarbonImmutable::MONDAY),
            default => $selectedDate->startOfMonth()->startOfWeek(CarbonImmutable::MONDAY),
        };
        $periodEnd = match ($view) {
            'day' => $selectedDate->endOfDay(),
            'week' => $selectedDate->endOfWeek(CarbonImmutable::SUNDAY),
            default => $selectedDate->endOfMonth()->endOfWeek(CarbonImmutable::SUNDAY),
        };

        $scheduledSessions = ScheduledTrainingSession::query()
            ->with('training:id,title,expert_name,training_id')
            ->with('training.training:id,title')
            ->whereDate('session_date', '>=', $periodStart->toDateString())
            ->whereDate('session_date', '<=', $periodEnd->toDateString())
            ->orderBy('session_date')
            ->orderBy('start_time')
            ->get();

        $legacySessions = TrainingSession::query()
            ->with('training:id,title,expert_name')
            ->whereHas('training.requests', fn ($query) => $query->where('status', 'approved'))
            ->whereDate('session_date', '>=', $periodStart->toDateString())
            ->whereDate('session_date', '<=', $periodEnd->toDateString())
            ->orderBy('session_date')
            ->orderBy('start_time')
            ->get();

        $sessions = $scheduledSessions
            ->concat($legacySessions)
            ->unique(fn ($session): string => implode('|', [
                $session->session_date->toDateString(),
                $session->start_time,
                $session->end_time,
                $session->training->title,
            ]))
            ->groupBy(fn ($session): string => $session->session_date->toDateString());

        $days = collect();
        for ($date = $periodStart; $date->lte($periodEnd); $date = $date->addDay()) {
            $days->push($date);
        }

        $previousDate = match ($view) {
            'day' => $selectedDate->subDay(),
            'week' => $selectedDate->subWeek(),
            default => $selectedDate->subMonthNoOverflow(),
        };
        $nextDate = match ($view) {
            'day' => $selectedDate->addDay(),
            'week' => $selectedDate->addWeek(),
            default => $selectedDate->addMonthNoOverflow(),
        };

        return view('calendar.index', [
            'view' => $view,
            'selectedDate' => $selectedDate,
            'days' => $days,
            'sessions' => $sessions,
            'previousDate' => $previousDate,
            'nextDate' => $nextDate,
            'hours' => range(6, 23),
        ]);
    }
}

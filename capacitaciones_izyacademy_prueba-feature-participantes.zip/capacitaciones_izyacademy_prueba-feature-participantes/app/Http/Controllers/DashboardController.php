<?php

namespace App\Http\Controllers;

use App\Models\Role;
use App\Models\Training;
use App\Models\TrainingCategory;
use App\Models\TrainingRequest;
use App\Services\ReportService;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** Prepara el panel principal con información adaptada al rol del usuario. */
class DashboardController extends Controller
{
    /** Servicio utilizado para calcular métricas y datos analíticos. */
    public function __construct(
        protected ReportService $reportService
    ) {}

    /**
     * Carga métricas, solicitudes o capacitaciones según el rol del usuario:
     * administrador, director/líder o usuario externo.
     */
    public function index(Request $request): View
    {
        $user = $request->user();

        // 1. Datos para Rol Administrador
        if ($user->hasRole(Role::SLUG_ADMIN)) {
            $metrics = $this->reportService->getDashboardMetrics();
            $recentTrainings = Training::withStandardRelations()->latest()->limit(5)->get();
            $recentRequests = TrainingRequest::withStandardRelations()->latest()->limit(5)->get();

            return view('dashboard.index', [
                'user' => $user,
                'metrics' => $metrics,
                'recentTrainings' => $recentTrainings,
                'recentRequests' => $recentRequests,
            ]);
        }

        // 2. Datos para Rol Directores y Líderes
        if ($user->hasRole(Role::SLUG_LEADER)) {
            $myRequests = TrainingRequest::withStandardRelations()
                ->forUser($user->id)
                ->latest()
                ->limit(6)
                ->get();

            $availableTrainings = Training::withStandardRelations()
                ->latest()
                ->limit(6)
                ->get();

            $pendingCount = TrainingRequest::forUser($user->id)->pending()->count();
            $approvedCount = TrainingRequest::forUser($user->id)->byStatus('approved')->count();

            return view('dashboard.index', [
                'user' => $user,
                'myRequests' => $myRequests,
                'availableTrainings' => $availableTrainings,
                'pendingCount' => $pendingCount,
                'approvedCount' => $approvedCount,
            ]);
        }

        // 3. Datos para Rol Externos
        $publicTrainings = Training::withStandardRelations()
            ->publicForExternals()
            ->latest()
            ->paginate(6);

        return view('dashboard.index', [
            'user' => $user,
            'publicTrainings' => $publicTrainings,
        ]);
    }
}

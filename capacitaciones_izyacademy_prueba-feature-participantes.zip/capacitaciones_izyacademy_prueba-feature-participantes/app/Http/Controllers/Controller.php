<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;

/**
 * Controlador base de la aplicación.
 *
 * Proporciona a los controladores hijos las funcionalidades estándar de
 * autorización, validación de solicitudes y despacho de trabajos.
 */
abstract class Controller
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
}

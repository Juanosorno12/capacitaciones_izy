<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Services\AuditLogService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

/** Gestiona el inicio y cierre de sesión de los usuarios corporativos. */
class AuthController extends Controller
{
    public function __construct(
        protected AuditLogService $auditLog
    ) {}

    /** Muestra el formulario de acceso o redirige al dashboard si ya hay sesión. */
    public function showLoginForm(): View|RedirectResponse
    {
        if (Auth::check()) {
            return redirect()->route('dashboard');
        }

        return view('auth.login');
    }

    /**
     * Valida las credenciales, inicia la sesión y verifica que la cuenta esté activa.
     */
    public function login(Request $request): RedirectResponse
    {
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required', 'string'],
        ]);

        $remember = $request->boolean('remember');

        if (Auth::attempt($credentials, $remember)) {
            $user = Auth::user();

            if (!$user->isActive()) {
                Auth::logout();
                $request->session()->invalidate();
                $request->session()->regenerateToken();
                return back()->withErrors([
                    'email' => 'Tu cuenta corporativa se encuentra inactiva. Contacta al Administrador del sistema.',
                ])->onlyInput('email');
            }

            $request->session()->regenerate();
            $this->auditLog->record(
                'auth.login',
                'Inicio de sesión exitoso.',
                User::class,
                $user->id,
                [],
                $request,
                $user->id
            );

            return redirect()->intended(route('dashboard'))
                ->with('success', "Bienvenido nuevamente, {$user->name}.");
        }

        return back()->withErrors([
            'email' => 'Las credenciales proporcionadas no coinciden con nuestros registros.',
        ])->onlyInput('email');
    }

    /** Cierra la sesión, invalida los datos de sesión y regenera el token CSRF. */
    public function logout(Request $request): RedirectResponse
    {
        Auth::logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('home')
            ->with('info', 'Has cerrado sesión exitosamente.');
    }
}

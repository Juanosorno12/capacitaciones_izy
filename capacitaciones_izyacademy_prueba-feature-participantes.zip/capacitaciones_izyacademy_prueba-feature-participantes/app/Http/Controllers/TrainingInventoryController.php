<?php

namespace App\Http\Controllers;

use App\Exports\TrainingInventoryExport;
use App\Http\Requests\UploadTrainingInventoryRequest;
use App\Services\TrainingInventoryService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\View\View;
use Maatwebsite\Excel\Facades\Excel;
use App\Services\AuditLogService;

/** Handles the administrator-only inventory import and export screens. */
class TrainingInventoryController extends Controller
{
    public function __construct(
        protected TrainingInventoryService $inventoryService,
        protected AuditLogService $auditLog
    ) {}

    /** Shows the upload screen. */
    public function index(): View
    {
        return view('trainings.import');
    }

    /** Stores a workbook temporarily and displays its validation preview. */
    public function preview(UploadTrainingInventoryRequest $request): View
    {
        $this->ensureExcelSupport();
        $token = (string) Str::uuid();
        $extension = $request->file('inventory_file')->getClientOriginalExtension();
        $path = $request->file('inventory_file')->storeAs(
            'imports/pending',
            "{$token}.{$extension}",
            'local'
        );
        $preview = $this->inventoryService->preview($path);
        session(["training_import_pending.{$token}" => $path]);

        return view('trainings.import', [
            'preview' => $preview,
            'token' => $token,
        ]);
    }

    /** Processes valid rows after the administrator confirms the preview. */
    public function confirm(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'token' => ['required', 'uuid'],
        ]);
        $sessionKey = "training_import_pending.{$validated['token']}";
        $path = session($sessionKey);

        if (!is_string($path) || !Storage::disk('local')->exists($path)) {
            return redirect()->route('trainings.import')
                ->withErrors(['inventory_file' => 'La vista previa expiró. Carga el archivo nuevamente.']);
        }

        $result = $this->inventoryService->process($path, $request->user()->id);
        $this->auditLog->record('training.imported', 'Importación de inventario confirmada.', null, null, [
            'created' => $result['created_count'],
            'updated' => $result['updated_count'],
            'invalid' => $result['invalid_count'],
        ]);
        Storage::disk('local')->delete($path);
        session()->forget($sessionKey);

        return redirect()->route('trainings.import')
            ->with('training_import_result', $result);
    }

    /** Downloads all catalog records using the import-compatible headings. */
    public function export()
    {
        $this->ensureExcelSupport();
        $this->auditLog->record('training.exported', 'Inventario de capacitaciones exportado.');

        return Excel::download(
            new TrainingInventoryExport(),
            'inventario_cursos_izyacademy.xlsx'
        );
    }

    /** Stops the workflow with an actionable message when PHP ZIP is unavailable. */
    private function ensureExcelSupport(): void
    {
        if (!extension_loaded('zip')) {
            abort(
                503,
                'La extensión ZIP de PHP no está habilitada. Activa extension=zip en el php.ini de Laragon y reinicia Apache.'
            );
        }
    }
}

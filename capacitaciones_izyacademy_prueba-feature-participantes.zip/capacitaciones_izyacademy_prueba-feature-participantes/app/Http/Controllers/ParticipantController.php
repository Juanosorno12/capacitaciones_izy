<?php

namespace App\Http\Controllers;

use App\Models\Participant;
use App\Models\Role;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** Gestiona el directorio y el historial de participantes. */
class ParticipantController extends Controller
{
    /**
     * Lista participantes con búsqueda, conteo de capacitaciones y paginación.
     */
    public function index(Request $request): View
    {
        abort_unless($request->user()->hasRole(Role::SLUG_ADMIN), 403);

        $filters = $request->validate([
            'search' => ['nullable', 'string', 'max:255'],
        ]);
        $search = trim($filters['search'] ?? '');

        $participants = Participant::query()
            ->search($search)
            ->withCount('trainings')
            ->orderBy('last_name')
            ->orderBy('first_name')
            ->paginate(15)
            ->withQueryString();

        return view('participants.index', [
            'participants' => $participants,
            'search' => $search,
        ]);
    }

    /** Muestra los datos y el historial de capacitaciones de un participante. */
    public function show(Request $request, Participant $participant): View
    {
        abort_unless($request->user()->hasRole(Role::SLUG_ADMIN), 403);

        $participant->load([
            'trainings' => fn ($query) => $query
                ->with('category:id,name')
                ->orderByDesc('trainings.created_at'),
        ]);

        return view('participants.show', [
            'participant' => $participant,
        ]);
    }
}

<?php

namespace App\Http\Controllers;

use App\Http\Requests\ReportFilterRequest;
use App\Services\ReportService;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Carbon;
use Illuminate\View\View;

/** Gestiona los reportes analíticos y la exportación de capacitaciones realizadas. */
class ReportController extends Controller
{
    /** Servicio encargado de calcular métricas y preparar datos de reportes. */
    public function __construct(
        protected ReportService $reportService
    ) {}

    /** Carga indicadores, datos para gráficos, filtros y sesiones entregadas. */
    public function index(ReportFilterRequest $request): View
    {
        $metrics = $this->reportService->getDashboardMetrics();
        $filters = $request->validated();
        $bounds = $this->reportBounds($filters);
        $deliveredReport = $this->reportService->getDeliveredTrainingReport($bounds);

        return view('reports.index', [
            'kpis' => $metrics['kpis'],
            'chartCategories' => $metrics['chart_categories'],
            'chartStatuses' => $metrics['chart_statuses'],
            'chartTrends' => $metrics['chart_trends'],
            'filters' => $filters,
            'periodLabel' => $bounds['label'],
            'deliveredMetrics' => $deliveredReport['metrics'],
            'deliveredSessions' => $deliveredReport['sessions'],
        ]);
    }

    /** Devuelve en formato JSON las sesiones entregadas para exportación. */
    public function exportTrainings(ReportFilterRequest $request): JsonResponse
    {
        $report = $this->reportService->exportDeliveredTrainingSessions(
            $this->reportBounds($request->validated())
        );

        return response()->json(['rows' => $report]);
    }

    /**
     * Convierte los filtros de periodo en fechas inicial y final legibles.
     *
     * Soporta un mes, un rango de fechas o un rango de meses.
     */
    private function periodBounds(array $filters): array
    {
        if ($filters['period'] === 'month') {
            $start = Carbon::createFromFormat('!Y-m', $filters['month'], config('app.timezone'))->startOfMonth();
            $end = $start->copy()->endOfMonth();
        } elseif ($filters['period'] === 'date_range') {
            $start = Carbon::createFromFormat('!Y-m-d', $filters['date_from'], config('app.timezone'))->startOfDay();
            $end = Carbon::createFromFormat('!Y-m-d', $filters['date_to'], config('app.timezone'))->endOfDay();
        } else {
            $start = Carbon::createFromFormat('!Y-m', $filters['month_from'], config('app.timezone'))->startOfMonth();
            $end = Carbon::createFromFormat('!Y-m', $filters['month_to'], config('app.timezone'))->endOfMonth();
        }

        return [
            'from' => $start->toDateString(),
            'to' => $end->toDateString(),
            'label' => $start->format('d/m/Y').' - '.$end->format('d/m/Y'),
        ];
    }

    /** Añade el filtro de valor agregado a los límites del reporte. */
    private function reportBounds(array $filters): array
    {
        return array_merge($this->periodBounds($filters), [
            'value_added' => $filters['value_added'] ?? 'all',
        ]);
    }
}

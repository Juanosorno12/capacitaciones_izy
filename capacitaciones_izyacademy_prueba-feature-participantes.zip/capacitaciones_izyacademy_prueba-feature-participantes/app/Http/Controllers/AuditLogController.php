<?php

namespace App\Http\Controllers;

use App\Models\AuditLog;
use App\Models\Role;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** Provides administrators with a read-only audit log. */
class AuditLogController extends Controller
{
    public function index(Request $request): View
    {
        abort_unless($request->user()?->hasRole(Role::SLUG_ADMIN), 403);

        $filters = $request->validate([
            'action' => ['nullable', 'string', 'max:100'],
            'search' => ['nullable', 'string', 'max:255'],
        ]);

        $logs = AuditLog::query()
            ->with('user:id,name,email')
            ->reportable()
            ->action($filters['action'] ?? null)
            ->search($filters['search'] ?? null)
            ->latest('created_at')
            ->paginate(25)
            ->withQueryString();

        $actions = collect(AuditLog::REPORTABLE_ACTIONS);

        return view('audit-logs.index', compact('logs', 'actions', 'filters'));
    }
}

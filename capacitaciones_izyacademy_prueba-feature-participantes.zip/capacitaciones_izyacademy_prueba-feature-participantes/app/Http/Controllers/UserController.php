<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreUserRequest;
use App\Http\Requests\SyncUserPermissionsRequest;
use App\Http\Requests\UpdateUserRequest;
use App\Models\Permission;
use App\Models\Role;
use App\Models\User;
use App\Services\UserService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use App\Services\AuditLogService;

/** Gestiona usuarios, roles y permisos directos. */
class UserController extends Controller
{
    /** Servicio que contiene las operaciones de negocio de usuarios. */
    public function __construct(
        protected UserService $userService,
        protected AuditLogService $auditLog
    ) {}

    /** Lista usuarios paginados aplicando filtros de búsqueda, rol y estado. */
    public function index(Request $request): View
    {
        $filters = $request->only(['search', 'role_id', 'is_active']);
        $users = $this->userService->listUsers($filters, 12);
        $roles = Role::orderBy('name')->get();

        return view('users.index', [
            'users' => $users,
            'roles' => $roles,
            'filters' => $filters,
        ]);
    }

    /** Muestra el formulario de creación con los roles disponibles. */
    public function create(): View
    {
        $roles = Role::orderBy('name')->get();

        return view('users.create', [
            'roles' => $roles,
        ]);
    }

    /** Valida y crea un usuario mediante el servicio de usuarios. */
    public function store(StoreUserRequest $request): RedirectResponse
    {
        $user = $this->userService->createUser($request->validated());
        $this->auditLog->record('user.created', "Usuario '{$user->name}' creado.", User::class, $user->id);

        return redirect()->route('users.index')
            ->with('success', "Usuario {$user->name} creado exitosamente.");
    }

    /** Carga el usuario, sus permisos y roles para mostrar el formulario de edición. */
    public function edit(User $user): View
    {
        $user->load(['role', 'directPermissions']);
        $roles = Role::orderBy('name')->get();

        return view('users.edit', [
            'user' => $user,
            'roles' => $roles,
        ]);
    }

    /** Valida y actualiza un usuario mediante el servicio de usuarios. */
    public function update(UpdateUserRequest $request, User $user): RedirectResponse
    {
        $this->userService->updateUser($user, $request->validated(), $request->user()->id);
        $this->auditLog->record('user.updated', "Usuario '{$user->name}' actualizado.", User::class, $user->id);

        return redirect()->route('users.index')
            ->with('success', "Usuario {$user->name} actualizado exitosamente.");
    }

    /** Prepara la matriz de permisos heredados y directos del usuario. */
    public function permissions(User $user): View
    {
        $user->load(['role.permissions', 'directPermissions']);

        // Obtener permisos agrupados desde caché en memoria
        $groupedPermissions = Permission::getCachedGrouped();

        // Identificar permisos heredados por el rol
        $rolePermissionIds = $user->role ? $user->role->permissions->pluck('id')->toArray() : [];

        // Identificar permisos asignados de forma directa al usuario
        $directPermissionIds = $user->directPermissions->pluck('id')->toArray();

        return view('users.permissions', [
            'user' => $user,
            'groupedPermissions' => $groupedPermissions,
            'rolePermissionIds' => $rolePermissionIds,
            'directPermissionIds' => $directPermissionIds,
        ]);
    }

    /** Sincroniza los permisos directos seleccionados para el usuario. */
    public function syncPermissions(SyncUserPermissionsRequest $request, User $user): RedirectResponse
    {
        $permissionIds = $request->input('permissions', []);
        $this->userService->syncUserPermissions($user, $permissionIds, $request->user()->id);
        $this->auditLog->record('user.permissions_updated', "Permisos de '{$user->name}' actualizados.", User::class, $user->id);

        return redirect()->route('users.permissions', $user)
            ->with('success', "Matriz de permisos de {$user->name} actualizada correctamente.");
    }
}

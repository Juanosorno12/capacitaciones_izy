<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreTrainingRequest;
use App\Http\Requests\UpdateTrainingRequest;
use App\Models\Training;
use App\Models\TrainingCategory;
use App\Services\TrainingService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use App\Services\AuditLogService;

/** Gestiona el catálogo y las operaciones CRUD de capacitaciones. */
class TrainingController extends Controller
{
    /** Servicio que contiene las reglas de negocio de capacitaciones. */
    public function __construct(
        protected TrainingService $trainingService,
        protected AuditLogService $auditLog
    ) {}

    /** Muestra el catálogo público de capacitaciones paginado. */
    public function publicIndex(): View
    {
        $trainings = Training::query()
            ->publicForExternals()
            ->withStandardRelations()
            ->latest()
            ->paginate(12);

        return view('public.trainings.index', [
            'trainings' => $trainings,
        ]);
    }

    /** Lista capacitaciones corporativas aplicando filtros y modo de visualización. */
    public function index(Request $request): View
    {
        $filters = $request->only(['category_id', 'search', 'has_certificate']);
        $trainings = $this->trainingService->listTrainings($filters, $request->user(), 12);

        // Categorías obtenidas desde la caché de alto rendimiento
        $categories = TrainingCategory::getCachedAll();
        $viewMode = $request->query('view', 'grid'); // 'grid' o 'table'

        return view('trainings.index', [
            'trainings' => $trainings,
            'categories' => $categories,
            'filters' => $filters,
            'viewMode' => $viewMode,
        ]);
    }

    /** Muestra el formulario de creación junto con las categorías disponibles. */
    public function create(): View
    {
        $categories = TrainingCategory::getCachedAll();

        return view('trainings.create', [
            'categories' => $categories,
        ]);
    }

    /** Valida y registra una nueva capacitación mediante el servicio de negocio. */
    public function store(StoreTrainingRequest $request): RedirectResponse
    {
        $training = $this->trainingService->createTraining(
            $request->validated(),
            $request->user()->id
        );
        $this->auditLog->record('training.created', "Curso '{$training->title}' creado.", Training::class, $training->id);

        return redirect()->route('trainings.index')
            ->with('success', "Curso o certificación '{$training->title}' creado exitosamente.");
    }

    /** Muestra el detalle de una capacitación y sus relaciones asociadas. */
    public function show(Request $request, Training $training): View
    {
        // Verificar visibilidad para usuarios externos
        if ($request->user()->hasRole('externos') && !$training->is_available_for_externals) {
            abort(403, 'Esta capacitación es de carácter privado interno.');
        }

        $training->load(['category', 'creator', 'expert', 'sessions']);

        return view('trainings.show', [
            'training' => $training,
        ]);
    }

    /** Muestra el formulario de edición de una capacitación existente. */
    public function edit(Training $training): View
    {
        $categories = TrainingCategory::getCachedAll();

        return view('trainings.edit', [
            'training' => $training,
            'categories' => $categories,
        ]);
    }

    /** Valida y actualiza una capacitación mediante el servicio de negocio. */
    public function update(UpdateTrainingRequest $request, Training $training): RedirectResponse
    {
        $this->trainingService->updateTraining($training, $request->validated());
        $this->auditLog->record('training.updated', "Curso '{$training->title}' actualizado.", Training::class, $training->id);

        return redirect()->route('trainings.index')
            ->with('success', "Capacitación '{$training->title}' actualizada exitosamente.");
    }

    /** Elimina una capacitación mediante el servicio y redirige al listado. */
    public function destroy(Training $training): RedirectResponse
    {
        $title = $training->title;
        $this->trainingService->deleteTraining($training);
        $this->auditLog->record('training.deleted', "Curso '{$title}' eliminado.", Training::class, $training->id);

        return redirect()->route('trainings.index')
            ->with('success', "Capacitación '{$title}' eliminada exitosamente.");
    }
}

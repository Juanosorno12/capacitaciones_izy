<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Http\UploadedFile;

/** Regla que comprueba que una imagen subida tenga la firma real del formato WebP. */
class WebpImage implements ValidationRule
{
    /** Valida el archivo cargado y notifica si no es un WebP válido. */
    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        if (! $value instanceof UploadedFile || ! $value->isValid()) {
            $fail('La foto de perfil debe estar en formato WebP.');

            return;
        }

        $header = file_get_contents($value->getRealPath(), false, null, 0, 12);

        if ($header === false || strlen($header) < 12 || substr($header, 0, 4) !== 'RIFF' || substr($header, 8, 4) !== 'WEBP') {
            $fail('La foto de perfil debe estar en formato WebP.');
        }
    }
}

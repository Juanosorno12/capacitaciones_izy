/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./resources/**/*.blade.php",
    "./resources/**/*.js",
    "./resources/**/*.vue",
    "./app/Http/Controllers/**/*.php",
    "./app/Services/**/*.php",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          navy: {
            DEFAULT: '#1D3A6C',
            dark: '#13274A',
            light: '#2A5298',
          },
          teal: {
            DEFAULT: '#19A885',
            hover: '#14866A',
            light: '#E8F6F3',
          },
          orange: {
            DEFAULT: '#FF5F00',
            hover: '#D95100',
            light: '#FFF2EB',
          },
          blue: {
            DEFAULT: '#0055AF',
            hover: '#003E80',
            light: '#EBF3FC',
          },
          dark: '#111111',
          bg: '#F8FAFC',
        }
      },
      fontFamily: {
        sans: ['Inter', 'Nunito', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
      },
    },
  },
  plugins: [
    require('@tailwindcss/forms'),
  ],
}


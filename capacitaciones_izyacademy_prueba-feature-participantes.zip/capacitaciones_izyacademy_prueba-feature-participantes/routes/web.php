<?php

// Controladores utilizados por las rutas web de la plataforma.
use App\Http\Controllers\AuthController;
use App\Http\Controllers\AuditLogController;
use App\Http\Controllers\CalendarController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ParticipantController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\TrainingController;
use App\Http\Controllers\TrainingInventoryController;
use App\Http\Controllers\TrainingRequestController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes - Plataforma de Capacitaciones Corporativas
|--------------------------------------------------------------------------
|
| Definición exhaustiva de rutas web protegidas por autenticación y control
| de permisos dinámicos (RBAC + user_has_permissions).
|
*/

// Rutas Públicas de Autenticación
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
});

Route::post('/logout', [AuthController::class, 'logout'])->name('logout')->middleware('auth');

Route::get('/', [TrainingController::class, 'publicIndex'])->name('home');

// Rutas Corporativas Autenticadas
Route::middleware(['auth'])->group(function () {

    // 1. Dashboard Principal (Adaptado por Rol)
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    Route::get('/audit-logs', [AuditLogController::class, 'index'])
        ->middleware('permission:audit-logs.view')
        ->name('audit-logs.index');

    // 2. Módulo de Capacitaciones
    Route::prefix('trainings')->name('trainings.')->group(function () {
        Route::get('/', [TrainingController::class, 'index'])
            ->middleware('permission:trainings.view')
            ->name('index');

        Route::get('/create', [TrainingController::class, 'create'])
            ->middleware('permission:trainings.manage')
            ->name('create');

        Route::post('/', [TrainingController::class, 'store'])
            ->middleware('permission:trainings.manage')
            ->name('store');

        Route::get('/import', [TrainingInventoryController::class, 'index'])
            ->middleware('permission:trainings.import')
            ->name('import');

        Route::post('/import/preview', [TrainingInventoryController::class, 'preview'])
            ->middleware('permission:trainings.import')
            ->name('import.preview');

        Route::post('/import/confirm', [TrainingInventoryController::class, 'confirm'])
            ->middleware('permission:trainings.import')
            ->name('import.confirm');

        Route::get('/export', [TrainingInventoryController::class, 'export'])
            ->middleware('permission:trainings.export')
            ->name('export');

        Route::get('/{training}', [TrainingController::class, 'show'])
            ->middleware('permission:trainings.view')
            ->name('show');

        Route::get('/{training}/edit', [TrainingController::class, 'edit'])
            ->middleware('permission:trainings.manage')
            ->name('edit');

        Route::put('/{training}', [TrainingController::class, 'update'])
            ->middleware('permission:trainings.manage')
            ->name('update');

        Route::delete('/{training}', [TrainingController::class, 'destroy'])
            ->middleware('permission:trainings.manage')
            ->name('destroy');
    });

    Route::get('/calendar', [CalendarController::class, 'index'])
        ->middleware('permission:calendar.view')
        ->name('calendar.index');

    // 3. Módulo de Solicitudes de Capacitación (Workflow)
    Route::prefix('requests')->name('requests.')->group(function () {
        Route::get('/', [TrainingRequestController::class, 'index'])
            ->middleware('permission:requests.view')
            ->name('index');

        Route::get('/create', [TrainingRequestController::class, 'create'])
            ->middleware('permission:requests.create')
            ->name('create');

        Route::post('/', [TrainingRequestController::class, 'store'])
            ->middleware('permission:requests.create')
            ->name('store');

        Route::get('/{training_request}', [TrainingRequestController::class, 'show'])
            ->middleware('permission:requests.view')
            ->name('show');

        Route::post('/{training_request}/review', [TrainingRequestController::class, 'review'])
            ->middleware('permission:requests.approve')
            ->name('review');
    });

    // Directorio e historial de participantes (permiso asignado únicamente al rol administrador)
    Route::prefix('participants')->name('participants.')->middleware('permission:participants.view')->group(function () {
        Route::get('/', [ParticipantController::class, 'index'])->name('index');
        Route::get('/{participant}', [ParticipantController::class, 'show'])->name('show');
    });

    // 4. Módulo de Reportes y Analítica
    Route::prefix('reports')->name('reports.')->group(function () {
        Route::get('/', [ReportController::class, 'index'])
            ->middleware('permission:reports.view')
            ->name('index');

        Route::get('/trainings/export', [ReportController::class, 'exportTrainings'])
            ->middleware('permission:reports.view')
            ->name('trainings.export');
    });

    // 5. Módulo de Administración de Usuarios y Matriz de Permisos
    Route::prefix('users')->name('users.')->group(function () {
        Route::get('/', [UserController::class, 'index'])
            ->middleware('permission:users.view')
            ->name('index');

        Route::get('/create', [UserController::class, 'create'])
            ->middleware('permission:users.manage')
            ->name('create');

        Route::post('/', [UserController::class, 'store'])
            ->middleware('permission:users.manage')
            ->name('store');

        Route::get('/{user}/edit', [UserController::class, 'edit'])
            ->middleware('permission:users.manage')
            ->name('edit');

        Route::put('/{user}', [UserController::class, 'update'])
            ->middleware('permission:users.manage')
            ->name('update');

        // Matriz / Checklist de Permisos Dinámicos por Usuario
        Route::get('/{user}/permissions', [UserController::class, 'permissions'])
            ->middleware('permission:users.permissions')
            ->name('permissions');

        Route::put('/{user}/permissions', [UserController::class, 'syncPermissions'])
            ->middleware('permission:users.permissions')
            ->name('permissions.sync');
    });

});

# Referencia del código fuente

Esta guía explica la responsabilidad de cada parte mantenida de la aplicación, cómo se conectan sus módulos y dónde iniciar un cambio. Describe el comportamiento que implementa el código; no sustituye a la validación de permisos ni a las reglas de negocio.

- Para cambiar una pantalla o un proceso, sigue la [Guía práctica para desarrolladores](DEVELOPER_GUIDE.md).
- Para columnas, relaciones e índices, consulta [Base de datos](DATABASE.md).
- Para rutas HTTP y permisos, consulta el [Diccionario de datos y rutas](DATA_DICTIONARY_AND_ROUTES.md).
- Para configuración del servidor, consulta [Despliegue y optimización](DEPLOYMENT_AND_OPTIMIZATION.md).

## 1. Principio de organización

El proyecto sigue Laravel MVC con una capa de servicios:

| Capa | Responsabilidad | Ubicación |
| --- | --- | --- |
| Rutas | Asignar URL, método HTTP, controlador, nombre y middleware. | `routes/web.php` |
| Middleware | Aplicar autenticación y permisos antes de ejecutar una acción. | `app/Http/Kernel.php`, `app/Http/Middleware/` |
| Form Request | Autorizar una operación y validar/normalizar sus datos. | `app/Http/Requests/` |
| Controlador | Leer la petición, llamar servicios y escoger la respuesta. | `app/Http/Controllers/` |
| Servicio | Aplicar reglas de negocio, coordinar modelos y transacciones. | `app/Services/` |
| Modelo | Representar una tabla, sus relaciones, scopes y comportamiento local. | `app/Models/` |
| Vista | Presentar HTML y formularios con datos preparados por el servidor. | `resources/views/` |
| JavaScript/CSS | Mejoras interactivas y recursos del navegador. | `resources/js/`, `resources/css/` |

Una petición web típica recorre:

```text
routes/web.php
  -> middleware (auth / permission)
  -> FormRequest (authorize + rules, cuando se usa)
  -> Controller
  -> Service
  -> Model y base de datos
  -> Blade, redirección o JSON
```

No se debe confiar en que ocultar un botón proteja una operación: la autorización efectiva está en el middleware, el Form Request y las comprobaciones del servidor.

## 2. Módulos y flujos de negocio

### 2.1. Autenticación y permisos

1. `AuthController` valida credenciales, inicia o termina la sesión y rechaza usuarios inactivos.
2. `CheckPermission` exige usuario autenticado, comprueba que la cuenta siga activa y verifica el permiso requerido.
3. `User::hasPermissionTo()` consulta la unión de permisos del rol y permisos directos asignados al usuario. Una cuenta inactiva no recibe permisos efectivos.
4. Los permisos y asignaciones iniciales se definen en `RolePermissionSeeder`; una migración que agregue un permiso debe ocuparse también de cómo se asigna a los roles existentes.

Los usuarios no reciben un permiso directo como denegación que quite uno heredado: el código une los permisos del rol y los directos. Cambiar esa semántica afecta autorización en toda la aplicación.

### 2.2. Crear y revisar una solicitud

1. `requests.create` protege el formulario y el envío.
2. `StoreTrainingRequestForm` exige categoría, título, cliente, justificación y al menos un participante; limita la solicitud a 1000 participantes y valida correos y campos obligatorios.
3. Los participantes se capturan en `requests/create.blade.php` o se incorporan desde un archivo `.xlsx` en el navegador.
4. `TrainingRequestService::createRequest()` crea la solicitud y resuelve cada participante por correo corporativo normalizado en minúsculas. Si ya existe, actualiza sus datos básicos; luego sincroniza los participantes a la solicitud. La operación ocurre en una transacción.
5. `TrainingRequestService::listRequests()` limita las solicitudes visibles a las propias para usuarios sin `requests.approve` ni `requests.review`; también aplica filtros y paginación.
6. La acción de revisión puede marcar la solicitud como `reviewing`, rechazarla con motivo o aprobarla. La revisión y aprobación están protegidas por autorización de servidor.

Los estados almacenados son `pending`, `reviewing`, `approved` y `rejected`; el texto en español se presenta en las vistas. No reemplaces estos valores por etiquetas traducidas en la base de datos.

### 2.3. Importar participantes desde Excel

`resources/js/participant-spreadsheet.js` procesa el `.xlsx` en el cliente mediante `fflate` y las API XML del navegador. Lee la primera hoja, reconoce las filas de encabezado sin distinguir mayúsculas ni tildes y devuelve objetos que rellena el formulario.

- Acepta archivos `.xlsx` de hasta 5 MB y hasta 1000 filas de participantes.
- Encabezados requeridos: `Nombre`, `Apellido`, `Correo corporativo`, `Celular` y `Ciudad`.
- Encabezado opcional: `Correo personal`; se admiten alias como `Apellidos`, `Correo electrónico corporativo`, `Teléfono` y variantes con/sin tildes.
- La primera fila no vacía se interpreta como encabezado; los renglones vacíos posteriores se ignoran.
- La validación del navegador ayuda a preparar el formulario, pero el servidor vuelve a validar los datos mediante `StoreTrainingRequestForm`.

Al cambiar los nombres de campos o encabezados, coordina `resources/js/participant-spreadsheet.js`, el formulario, `StoreTrainingRequestForm`, `TrainingRequestService` y el modelo `Participant`.

### 2.4. Aprobar y programar una capacitación

1. El formulario de aprobación añade facilitador, duración, modalidad y una o más sesiones.
2. `ApproveTrainingRequest` valida acción, modalidad y formatos de fecha/hora; también exige que cada hora final sea posterior a su inicio.
3. `training-session-fields.blade.php` proporciona controles para duración predefinida o personalizada y campos de horario. La interfaz mejora la captura; la validación de servidor es la autoridad.
4. `TrainingRequestService::approveAndConvertToTraining()` crea la capacitación, guarda sesiones, copia los participantes de la solicitud y enlaza la capacitación aprobada, todo en una transacción.
5. Si cualquier paso falla, la transacción evita dejar una capacitación parcial o una solicitud en un estado inconsistente.

Las sesiones se guardan en `training_sessions`; modalidad en `trainings.modality`. La duración total académica de la capacitación (`duration_hours`) no reemplaza las fechas ni los intervalos específicos de sus sesiones.

### 2.5. Catálogo, calendario y participantes

- `TrainingService` arma el catálogo paginado, aplica búsqueda/categoría/certificado y restringe a programas públicos cuando el usuario tiene el rol externo.
- `TrainingController::show()` también impide al rol externo abrir una capacitación privada por URL directa.
- `CalendarController` valida vista y fecha, obtiene las sesiones del periodo y arma días anterior/siguiente. Además del permiso de ruta, limita el calendario al rol administrador. La vista diaria incluye las horas 06:00–23:00.
- `ParticipantController` muestra directorio e historial con el rol administrador; el alcance también está en el middleware de ruta.
- `Participant` es un registro reutilizable por correo corporativo que puede asociarse a muchas solicitudes y capacitaciones.

### 2.6. Reportes

`ReportService::getDashboardMetrics()` prepara los KPI y datasets agregados de gráficos generales; `reports.js` los presenta mediante Chart.js.

El informe de sesiones impartidas usa filtros `month`, `date_range` o `month_range`. `ReportFilterRequest` valida formatos y orden de los extremos; `ReportController` traduce el periodo a límites inclusivos. `ReportService`:

- incluye sesiones anteriores a hoy;
- de hoy, incluye solo las que ya terminaron según la hora local de `config('app.timezone')`;
- calcula conteos y horas desde los horarios de sesión y participantes únicos asociados a capacitaciones con sesiones en el periodo;
- pagina la pantalla, pero exporta el conjunto completo de filas filtradas en orden cronológico.

La condición de finalización es una **inferencia por horario**. No existe registro de asistencia real en este modelo, así que “impartida” no prueba que el instructor realizara la sesión.

La ruta `reports.trainings.export` responde JSON. `resources/js/report-export.js` solicita sus filas, genera un libro Open XML `.xlsx` con `fflate` y dispara la descarga en el navegador. Si se cambian campos de exportación, sincroniza `ReportService`, los encabezados y celdas de `report-export.js` y la documentación del endpoint.

## 3. Inventario de `app/`

### 3.1. Controladores (`app/Http/Controllers/`)

| Archivo | Responsabilidad |
| --- | --- |
| `Controller.php` | Clase base compartida por los controladores web. |
| `AuthController.php` | Formulario de acceso, autenticación, regeneración de sesión y cierre de sesión. |
| `DashboardController.php` | Prepara datos distintos para administrador, líder y usuario externo. |
| `TrainingController.php` | Catálogo público e interno, detalle y operaciones CRUD de capacitaciones. |
| `TrainingRequestController.php` | Listado, formulario, detalle y acciones de revisión/aprobación/rechazo de solicitudes. |
| `CalendarController.php` | Selecciona el periodo y las sesiones que muestra el calendario. |
| `ParticipantController.php` | Directorio de participantes e historial de capacitaciones. |
| `ReportController.php` | Monta la vista de analítica, calcula límites de periodo y expone la exportación JSON. |
| `UserController.php` | Directorio, altas/ediciones y pantalla de permisos individuales. |

Los controladores reciben servicios por inyección de dependencias cuando hay lógica que debe compartirse o aislarse. Mantén los controladores como coordinadores HTTP y evita mover las reglas de negocio a Blade.

### 3.2. Solicitudes validadas (`app/Http/Requests/`)

| Archivo | Operación y validación principal |
| --- | --- |
| `StoreTrainingRequestForm.php` | Crear solicitudes y validar sus participantes; comparte las reglas base de participantes. |
| `ApproveTrainingRequest.php` | Marcar en revisión, rechazar o aprobar/programar; valida acción y horarios. |
| `ReportFilterRequest.php` | Validar modalidad del periodo, fechas/meses y que el rango no esté invertido. |
| `StoreTrainingRequest.php` | Validar la creación manual de una capacitación y sus sesiones. |
| `UpdateTrainingRequest.php` | Validar la edición de una capacitación y sus sesiones. |
| `StoreUserRequest.php` | Validar alta de usuario. |
| `UpdateUserRequest.php` | Validar actualización de usuario y campos opcionales. |
| `SyncUserPermissionsRequest.php` | Validar el conjunto de IDs de permisos a asignar directamente. |

Un `FormRequest` contiene `authorize()`, reglas `rules()` y, cuando corresponde, mensajes/reglas posteriores. Para nuevos datos, modifica la validación en servidor antes de depender de restricciones del formulario.

### 3.3. Servicios (`app/Services/`)

| Archivo | Responsabilidad |
| --- | --- |
| `TrainingRequestService.php` | Listado con alcance por usuario, alta, transiciones de estado y conversión transaccional solicitud→capacitación. |
| `TrainingService.php` | Consulta filtrada/paginada del catálogo y CRUD transaccional de capacitaciones y sesiones. |
| `ReportService.php` | Métricas del dashboard, agregaciones de gráficos e informe/exportación de sesiones. |
| `UserService.php` | Listado, creación, actualización, asignación de permisos y reglas de autoprotección del administrador. |

Las consultas compartidas o cálculos de negocio del módulo pertenecen en su servicio. Usa eager loading y paginación en listados; revisa los consumidores antes de cambiar el formato de retorno de un servicio.

### 3.4. Modelos (`app/Models/`)

| Archivo | Entidad y comportamiento |
| --- | --- |
| `User.php` | Usuario autenticable; rol, permisos directos, capacitaciones/solicitudes propias, estado activo y permisos efectivos con caché. |
| `Role.php` | Rol institucional, usuarios asignados y permisos heredados. |
| `Permission.php` | Permiso RBAC, etiquetas de presentación, agrupación y caché del catálogo. |
| `TrainingCategory.php` | Categoría; relación con capacitaciones/solicitudes y caché de categorías. |
| `Training.php` | Capacitación, creador, categoría, solicitud asociada, participantes y sesiones; scopes de visibilidad/búsqueda. |
| `TrainingRequest.php` | Solicitud, solicitante, categoría, capacitación aprobada y participantes; constantes de estado y scopes. |
| `TrainingSession.php` | Fecha/hora de una sesión perteneciente a una capacitación. |
| `Participant.php` | Datos personales y relaciones muchos-a-muchos con solicitudes y capacitaciones. |

Cuando cambie una relación o un campo persistido, verifica conjuntamente el modelo, migración, servicio, validación, vista, reportes y diccionario de datos.

### 3.5. Middleware, proveedores y ciclo HTTP

| Archivo | Responsabilidad |
| --- | --- |
| `app/Http/Kernel.php` | Middleware global y grupos `web`/`api`; registra el alias `permission`. |
| `app/Http/Middleware/CheckPermission.php` | Rechaza usuarios ausentes/inactivos o sin el permiso nombrado en la ruta. |
| `app/Http/Middleware/RedirectIfAuthenticated.php` | Redirige visitantes ya autenticados fuera de páginas para invitados. |
| `app/Providers/AuthServiceProvider.php` | Integra permisos con `Gate` y define las directivas Blade `@hasPermission` y `@hasRole`. |
| `app/Providers/RouteServiceProvider.php` | Registra `routes/web.php` bajo el middleware `web`. |
| `app/Exceptions/Handler.php` | Registro y reporte de excepciones de la aplicación. |
| `app/Console/Kernel.php` | Registro de comandos y planificación de tareas de consola. |

## 4. Inventario de vistas y recursos web

### 4.1. Vistas Blade (`resources/views/`)

| Archivo | Uso |
| --- | --- |
| `layouts/app.blade.php` | Estructura autenticada, navegación y contenedor común de páginas. |
| `layouts/guest.blade.php` | Marco visual para visitantes y acceso. |
| `layouts/public.blade.php` | Marco visual para páginas públicas. |
| `auth/login.blade.php` | Formulario de acceso. |
| `dashboard/index.blade.php` | Dashboard adaptado por rol. |
| `requests/index.blade.php` | Listado, estados, filtros y paginación de solicitudes. |
| `requests/create.blade.php` | Captura de datos de solicitud y participantes; enlaza la importación de Excel. |
| `requests/show.blade.php` | Detalle de solicitud y controles de revisión/aprobación. |
| `components/training-session-fields.blade.php` | Campos reutilizables de fecha/hora/duración para programar sesiones. |
| `trainings/index.blade.php` | Catálogo interno con filtros y opciones de presentación. |
| `trainings/create.blade.php` | Formulario de alta manual de capacitación. |
| `trainings/edit.blade.php` | Edición de capacitación y sesiones existentes. |
| `trainings/show.blade.php` | Detalle de capacitación, horario, participantes y certificado. |
| `public/trainings/index.blade.php` | Catálogo visible públicamente para visitantes. |
| `calendar/index.blade.php` | Vistas diaria/semanal/mensual del calendario de sesiones. |
| `participants/index.blade.php` | Directorio y búsqueda de participantes. |
| `participants/show.blade.php` | Perfil e historial de capacitaciones de un participante. |
| `reports/index.blade.php` | KPI, gráficos, filtros e informe paginado de sesiones. |
| `users/index.blade.php` | Directorio y filtros de usuarios. |
| `users/create.blade.php` | Formulario de alta de usuarios. |
| `users/edit.blade.php` | Edición de usuarios y estado de la cuenta. |
| `users/permissions.blade.php` | Matriz de permisos directos por usuario. |

Las vistas presentan datos y generan formularios. El servidor debe repetir autorización y validación, aunque una condición Blade no muestre el botón.

### 4.2. JavaScript y CSS (`resources/js/`, `resources/css/`)

| Archivo | Responsabilidad |
| --- | --- |
| `resources/js/app.js` | Inicializa Alpine.js, expone el lector XLSX para el formulario y descarta alertas temporales. |
| `resources/js/participant-spreadsheet.js` | Lee/valida estructura básica del `.xlsx`, identifica encabezados y normaliza filas de participantes. |
| `resources/js/reports.js` | Registra filtros dinámicos del periodo, exportación y gráficos Chart.js. |
| `resources/js/report-export.js` | Convierte filas JSON del informe en un archivo `.xlsx` descargable. |
| `resources/css/app.css` | Estilos fuente compartidos, componentes y utilidades corporativas procesados por Tailwind/PostCSS. |

`vite.config.js` declara las entradas de CSS, JavaScript general y reportes. Los scripts de importación y exportación se incluyen desde esas entradas; no son entradas Vite independientes.

## 5. Rutas, persistencia y configuración

### 5.1. Rutas

- `routes/web.php`: acceso, página pública, dashboard, capacitaciones, solicitudes, participantes, calendario, reportes y administración de usuarios.
- `routes/console.php`: punto de registro de comandos de consola.
- Los prefijos y nombres de ruta usados por Blade y controladores se declaran en `web.php`; utiliza `php artisan route:list` para ver el middleware efectivo.

El detalle completo de método, URL, nombre de ruta y permiso está en [DATA_DICTIONARY_AND_ROUTES.md](DATA_DICTIONARY_AND_ROUTES.md).

### 5.2. Migraciones (`database/migrations/`)

| Archivo | Cambio de esquema |
| --- | --- |
| `0001_01_01_000001_create_roles_table.php` | Crea el catálogo de roles institucionales. |
| `0001_01_01_000002_create_permissions_table.php` | Crea el catálogo de permisos granulares. |
| `0001_01_01_000003_create_role_has_permissions_table.php` | Crea la relación muchos-a-muchos entre roles y permisos. |
| `0001_01_01_000004_create_users_table.php` | Crea usuarios con rol y estado de activación. |
| `0001_01_01_000005_create_user_has_permissions_table.php` | Crea permisos directos asignables a usuarios. |
| `0001_01_01_000006_create_training_categories_table.php` | Crea categorías formativas. |
| `0001_01_01_000007_create_trainings_table.php` | Crea capacitaciones y sus datos de instructor, duración y certificado. |
| `0001_01_01_000008_create_training_requests_table.php` | Crea solicitudes y sus estados de flujo. |
| `2026_10_05_161327_create_participants_and_training_pivots.php` | Crea participantes y relaciones con solicitudes/capacitaciones. |
| `2026_10_05_161328_add_participants_view_permission.php` | Registra `participants.view`, lo asigna al rol administrador y limpia las cachés afectadas. |
| `2026_10_05_161329_create_training_sessions_table.php` | Crea sesiones con fecha, hora de inicio y finalización. |
| `2026_10_05_161330_add_calendar_view_permission.php` | Registra `calendar.view`, lo asigna al rol administrador y limpia las cachés afectadas. |
| `2026_10_06_000000_add_client_and_participant_details.php` | Añade cliente a solicitudes y correo personal, celular y ciudad a participantes. |
| `2026_10_06_000001_add_modality_to_trainings_table.php` | Añade modalidad virtual/presencial a capacitaciones. |

Las migraciones incrementales mantienen compatibilidad con bases ya creadas. Cada cambio nuevo de esquema compartido debe ser otra migración con `up()` y `down()` coherentes; no edites una migración ya aplicada para corregir datos en ambientes existentes.

### 5.3. Seeders (`database/seeders/`)

| Archivo | Datos que prepara |
| --- | --- |
| `DatabaseSeeder.php` | Orquesta los seeders del sistema en orden de dependencias. |
| `RolePermissionSeeder.php` | Roles, catálogo de permisos y asignación base de permisos a roles. |
| `TrainingCategorySeeder.php` | Categorías de capacitación. |
| `UserSeeder.php` | Cuentas locales de demostración por rol; no son cuentas de producción. |
| `TrainingSeeder.php` | Capacitaciones de demostración. |
| `TrainingRequestSeeder.php` | Solicitudes de demostración ligadas a usuarios y categorías existentes. |

Los seeders usan `firstOrCreate` en los datos principales para ser repetibles, aunque los datos vinculados deben revisarse al cambiar el esquema o las relaciones. La carga de cuentas demo y contraseñas del seeder no debe usarse como estrategia de aprovisionamiento de usuarios reales.

### 5.4. Configuración y archivos de arranque

| Archivo | Responsabilidad |
| --- | --- |
| `.env.example` | Plantilla de variables locales: URL, entorno, zona horaria, base de datos, sesión, cache y branding. |
| `.env` | Configuración local/secreta; no versionar. |
| `.gitignore` | Excluye del control de versiones configuración local, dependencias y artefactos generados. |
| `artisan` | Entrada de comandos CLI de Laravel. |
| `bootstrap/app.php` | Crea la aplicación y conecta el kernel. |
| `public/index.php` | Front controller web servido por Apache/Nginx. |
| `config/app.php` | Nombre, zona horaria, locale y parámetros principales de Laravel. |
| `config/auth.php` | Guard y proveedor de autenticación. |
| `config/branding.php` | Parámetros de identidad visual. |
| `config/cache.php` | Drivers y parámetros de caché. |
| `config/database.php` | Conexiones de base de datos. |
| `config/filesystems.php` | Discos y almacenamiento de archivos. |
| `config/logging.php` | Canales de log. |
| `config/session.php` | Duración y almacenamiento de sesiones. |
| `config/view.php` | Directorios y caché de vistas. |
| `public/.htaccess` | Reglas de reescritura Apache para Laravel. |
| `public/images/CertificadoIzyAcademy.png` | Imagen de muestra/plantilla de certificado. |
| `public/images/miniaturaIzy.png` | Miniatura/branding estático de la aplicación. |
| `tailwind.config.js`, `postcss.config.js` | Configuración de estilos y transformaciones CSS. |
| `vite.config.js` | Integración Laravel-Vite y entradas de compilación. |
| `composer.json` / `composer.lock` | Dependencias y autoload PHP; el lock fija versiones instaladas. |
| `package.json` / `package-lock.json` | Dependencias y comandos frontend; el lock fija versiones instaladas. |

## 6. Convenciones para mantener el proyecto

1. **Antes de editar:** sigue la ruta desde `routes/web.php` hasta la vista y servicio; busca si ya hay una regla o patrón equivalente.
2. **Validación:** toda entrada se valida en servidor. Las validaciones JavaScript son una mejora de UX, no una frontera de seguridad.
3. **Autorización:** protege la ruta y revisa el permiso/rol que necesita el flujo. No confíes en menús ni controles visuales.
4. **Datos relacionados:** usa transacciones al escribir una solicitud, capacitación, sesiones y relaciones que deban quedar consistentes.
5. **Consultas:** usa relaciones Eloquent, scopes, `with()`/`withCount()` y paginación; evita N+1 y consultas desde Blade.
6. **Esquema:** añade migraciones reversibles. Mantén el diccionario de datos, modelo, reglas y formularios en sincronía.
7. **Frontend:** modifica fuentes en `resources/`, no assets compilados en `public/build/`. Después ejecuta `npm run build`.
8. **Caché de frontend local:** elimina `public/hot` únicamente si el servidor Vite al que apunta ya no existe; no elimines ni alteres archivos que pertenezcan a otro proceso activo.
9. **Documentación:** actualiza esta referencia cuando aparezcan módulos/archivos nuevos y las guías funcionales cuando cambien reglas visibles.
10. **Configuración sensible:** no guardes secretos, `.env`, datos reales ni credenciales en commits o documentación pública.

## 7. Validación disponible

En este repositorio no hay un directorio `tests/` versionado. Para un cambio, ejecuta las comprobaciones aplicables:

```powershell
php -l app/Http/Controllers/NombreController.php
php artisan route:list
php artisan view:cache
npm run build
git diff --check
```

`php artisan migrate:status` permite comprobar migraciones sin volver a aplicarlas. `php artisan migrate:fresh` es destructivo y no es una comprobación para una base compartida.

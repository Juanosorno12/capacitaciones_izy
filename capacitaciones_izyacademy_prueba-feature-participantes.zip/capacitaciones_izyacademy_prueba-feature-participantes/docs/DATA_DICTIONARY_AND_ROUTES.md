# Diccionario de Datos y Matriz de Endpoints / Rutas

Este documento presenta el **Diccionario de Datos** exhaustivo de los atributos del sistema y la **Matriz de Rutas HTTP**, especificando los middlewares de autorización y permisos dinámicos asignados a cada endpoint.

---

## 1. Diccionario de Datos

### Tabla `roles`
| Campo | Tipo SQL | Nulo | Por Defecto | Descripción y Reglas de Negocio |
| :--- | :--- | :---: | :---: | :--- |
| `id` | BIGINT UNSIGNED | No | AUTO_INCREMENT | Identificador único de la llave primaria. |
| `name` | VARCHAR(255) | No | - | Nombre visible del rol (*Administrador*, *Directores y Lideres*, *Externos*). |
| `slug` | VARCHAR(255) | No | - | Identificador único alfanumérico para validación por código. |
| `description`| VARCHAR(255) | Sí | NULL | Alcance y responsabilidades asociadas al rol. |
| `created_at` | TIMESTAMP | Sí | NULL | Fecha de creación del registro. |
| `updated_at` | TIMESTAMP | Sí | NULL | Fecha de última actualización. |

### Tabla `permissions`
| Campo | Tipo SQL | Nulo | Por Defecto | Descripción y Reglas de Negocio |
| :--- | :--- | :---: | :---: | :--- |
| `id` | BIGINT UNSIGNED | No | AUTO_INCREMENT | Identificador único de la llave primaria. |
| `name` | VARCHAR(255) | No | - | Código único del permiso en notación de punto (ej. `trainings.manage`). |
| `module_group`| VARCHAR(255) | No | - | Agrupador funcional (*Capacitaciones*, *Solicitudes*, *Reportes*, *Usuarios*). |
| `description`| VARCHAR(255) | Sí | NULL | Descripción detallada de la operación permitida. |
| `created_at` | TIMESTAMP | Sí | NULL | Fecha de creación del permiso. |
| `updated_at` | TIMESTAMP | Sí | NULL | Fecha de última modificación. |

### Tabla `role_has_permissions` (Pivote)
| Campo | Tipo SQL | Nulo | Por Defecto | Descripción y Reglas de Negocio |
| :--- | :--- | :---: | :---: | :--- |
| `role_id` | BIGINT UNSIGNED | No | - | Clave foránea a `roles.id` con eliminación en cascada. |
| `permission_id`| BIGINT UNSIGNED | No | - | Clave foránea a `permissions.id` con eliminación en cascada. |

### Tabla `users`
| Campo | Tipo SQL | Nulo | Por Defecto | Descripción y Reglas de Negocio |
| :--- | :--- | :---: | :---: | :--- |
| `id` | BIGINT UNSIGNED | No | AUTO_INCREMENT | Identificador único del usuario. |
| `role_id` | BIGINT UNSIGNED | No | - | Clave foránea a `roles.id`. Rol base del colaborador. |
| `name` | VARCHAR(255) | No | - | Nombre completo del colaborador. |
| `email` | VARCHAR(255) | No | - | Correo corporativo único para autenticación (Indexado). |
| `password` | VARCHAR(255) | No | - | Hash criptográfico de la contraseña (Bcrypt/Argon2). |
| `profile_photo_path` | VARCHAR(255) | Sí | NULL | Ruta de la foto de perfil WebP en el disco público; el archivo se conserva fuera de la base de datos. |
| `is_active` | BOOLEAN | No | TRUE | Bandera de estado. Si es FALSE, el middleware rechaza la sesión. |
| `remember_token`| VARCHAR(100) | Sí | NULL | Token para persistencia de sesión ("Recordar sesión"). |
| `created_at` | TIMESTAMP | Sí | NULL | Fecha de alta en el sistema. |
| `updated_at` | TIMESTAMP | Sí | NULL | Fecha de última modificación de datos. |

### Tabla `user_has_permissions` (Pivote de Sobrescritura Dinámica)
| Campo | Tipo SQL | Nulo | Por Defecto | Descripción y Reglas de Negocio |
| :--- | :--- | :---: | :---: | :--- |
| `user_id` | BIGINT UNSIGNED | No | - | Clave foránea a `users.id` con eliminación en cascada. |
| `permission_id`| BIGINT UNSIGNED | No | - | Clave foránea a `permissions.id` con eliminación en cascada. |

### Tabla `training_categories`
| Campo | Tipo SQL | Nulo | Por Defecto | Descripción y Reglas de Negocio |
| :--- | :--- | :---: | :---: | :--- |
| `id` | BIGINT UNSIGNED | No | AUTO_INCREMENT | Identificador de categoría temática. |
| `name` | VARCHAR(255) | No | - | Nombre legible (ej. *Calidad del Software*, *IA generativa*). |
| `slug` | VARCHAR(255) | No | - | Slug único indexado para URL amigables y caché. |
| `description`| TEXT | Sí | NULL | Descripción de temas y competencias comprendidas. |
| `created_at` | TIMESTAMP | Sí | NULL | Fecha de creación. |
| `updated_at` | TIMESTAMP | Sí | NULL | Fecha de actualización. |

### Tabla `participants`
| Campo | Tipo SQL | Nulo | Por Defecto | Descripción y Reglas de Negocio |
| :--- | :--- | :---: | :---: | :--- |
| `first_name` | VARCHAR(100) | No | - | Nombre del participante. |
| `last_name` | VARCHAR(150) | No | - | Apellido del participante. |
| `email` | VARCHAR(255) | No | - | Correo corporativo único usado para identificar al participante. |
| `personal_email` | VARCHAR(255) | Sí | NULL | Correo personal opcional. |
| `phone` | VARCHAR(30) | Sí | NULL | Número celular; obligatorio en solicitudes nuevas. |
| `city` | VARCHAR(100) | Sí | NULL | Ciudad del participante; obligatoria en solicitudes nuevas. |

En el formulario de solicitud, estos datos también se pueden cargar desde un archivo Excel `.xlsx`. La primera hoja debe tener encabezados `Nombre`, `Apellido`, `Correo corporativo`, `Correo personal (opcional)`, `Celular` y `Ciudad`; solo el correo personal es opcional.

### Tabla `trainings`
| Campo | Tipo SQL | Nulo | Por Defecto | Descripción y Reglas de Negocio |
| :--- | :--- | :---: | :---: | :--- |
| `id` | BIGINT UNSIGNED | No | AUTO_INCREMENT | Identificador de la capacitación programada. |
| `category_id`| BIGINT UNSIGNED | No | - | Clave foránea a `training_categories.id`. |
| `created_by_user_id`| BIGINT UNSIGNED | No | - | Clave foránea a `users.id`. Usuario que programó el curso. |
| `title` | VARCHAR(255) | No | - | Título oficial de la capacitación (Indexado). |
| `description`| TEXT | No | - | Descripción detallada y objetivos de aprendizaje. |
| `expert_name`| VARCHAR(255) | No | - | Nombre del facilitador, instructor o experto técnico. |
| `expert_avatar_url`| VARCHAR(500) | Sí | NULL | URL opcional a la fotografía o avatar del facilitador. |
| `duration_hours`| INT UNSIGNED | No | - | Total de horas académicas de duración. |
| `schedule_details`| TEXT | No | - | Resumen legible del horario o cronograma. |
| `modality` | VARCHAR(20) | Sí | NULL | Modalidad virtual o presencial, cuando se haya especificado. |
| `is_public_for_externals`| BOOLEAN | No | TRUE | Indica si clientes/externos pueden visualizar el programa. |
| `has_certificate`| BOOLEAN | No | FALSE | Indica si otorga certificado de asistencia/aprobación. |
| `certificate_template_url`| VARCHAR(500) | Sí | NULL | URL a la imagen o muestra del certificado oficial. |
| `created_at` | TIMESTAMP | Sí | NULL | Fecha de creación. |
| `updated_at` | TIMESTAMP | Sí | NULL | Fecha de actualización. |

### Tabla `training_requests`
| Campo | Tipo SQL | Nulo | Por Defecto | Descripción y Reglas de Negocio |
| :--- | :--- | :---: | :---: | :--- |
| `id` | BIGINT UNSIGNED | No | AUTO_INCREMENT | Identificador de la solicitud. |
| `requested_by_user_id`| BIGINT UNSIGNED | No | - | Clave foránea a `users.id` (Líder o Director solicitante). |
| `category_id`| BIGINT UNSIGNED | No | - | Clave foránea a `training_categories.id`. |
| `approved_training_id`| BIGINT UNSIGNED | Sí | NULL | Clave foránea a `trainings.id` cuando la solicitud es aprobada. |
| `title` | VARCHAR(255) | No | - | Título de la capacitación elegida del catálogo; debe corresponder a `category_id`. |
| `client_name` | VARCHAR(255) | Sí | NULL | Nombre del cliente asociado con la solicitud. Obligatorio al crear solicitudes nuevas. |
| `justification`| TEXT | No | - | Sustento técnico y valor corporativo de la capacitación. |
| `estimated_participants`| INT UNSIGNED | No | 1 | Número estimado de colaboradores que tomarán el curso. |
| `status` | ENUM | No | 'pending' | Estado: `pending`, `reviewing`, `approved`, `rejected`. |
| `rejection_reason`| TEXT | Sí | NULL | Explicación técnica obligatoria en caso de rechazo. |
| `created_at` | TIMESTAMP | Sí | NULL | Fecha de envío de la solicitud. |
| `updated_at` | TIMESTAMP | Sí | NULL | Fecha de cambio de estado. |

Al crear una solicitud, primero se selecciona una categoría y luego una capacitación existente de esa categoría. El servidor valida la correspondencia antes de guardar el título seleccionado.

### Tabla pivote `participant_training_request`
Relaciona a los participantes incluidos en cada solicitud.

| Campo | Tipo SQL | Nulo | Descripción y Reglas de Negocio |
| :--- | :--- | :---: | :--- |
| `participant_id` | BIGINT UNSIGNED | No | Clave foránea a `participants.id`; eliminación en cascada. |
| `training_request_id` | BIGINT UNSIGNED | No | Clave foránea a `training_requests.id`; eliminación en cascada. |
| `created_at`, `updated_at` | TIMESTAMP | Sí | Marcas de tiempo de la relación. |

La clave primaria compuesta es (`participant_id`, `training_request_id`).

### Tabla pivote `participant_training`
Relaciona a los participantes asociados a una capacitación programada.

| Campo | Tipo SQL | Nulo | Descripción y Reglas de Negocio |
| :--- | :--- | :---: | :--- |
| `participant_id` | BIGINT UNSIGNED | No | Clave foránea a `participants.id`; eliminación en cascada. |
| `training_id` | BIGINT UNSIGNED | No | Clave foránea a `trainings.id`; eliminación en cascada. |
| `created_at`, `updated_at` | TIMESTAMP | Sí | Marcas de tiempo de la relación. |

La clave primaria compuesta es (`participant_id`, `training_id`).

### Tabla `training_sessions`
Almacena las fechas y horas específicas de cada sesión de una capacitación. Las horas se guardan como hora local de la aplicación; no se almacena una zona horaria por sesión.

| Campo | Tipo SQL | Nulo | Descripción y Reglas de Negocio |
| :--- | :--- | :---: | :--- |
| `id` | BIGINT UNSIGNED | No | Identificador de la sesión. |
| `training_id` | BIGINT UNSIGNED | No | Clave foránea a `trainings.id`; eliminación en cascada. |
| `session_date` | DATE | No | Fecha local programada para la sesión. |
| `start_time` | TIME | No | Hora de inicio. |
| `end_time` | TIME | No | Hora de finalización; debe ser posterior al inicio. |
| `created_at`, `updated_at` | TIMESTAMP | Sí | Marcas de tiempo del registro. |

---

## 2. Matriz de Endpoints y Control de Permisos

| Método | URI | Nombre de Ruta | Controlador & Acción | Middlewares Aplicados | Permiso Requerido |
| :---: | :--- | :--- | :--- | :--- | :--- |
| `GET` | `/login` | `login` | `AuthController@showLoginForm` | `web`, `guest` | Acceso público sin sesión |
| `POST`| `/login` | - | `AuthController@login` | `web`, `guest` | Autenticación con verificación de cuenta activa |
| `POST`| `/logout` | `logout` | `AuthController@logout` | `web`, `auth` | Sesión activa |
| `GET` | `/` | `home` | `TrainingController@publicIndex` | `web` | Catálogo público de capacitaciones |
| `GET` | `/dashboard` | `dashboard` | `DashboardController@index` | `web`, `auth` | Acceso a dashboard según rol |
| **Capacitaciones** | | | | | |
| `GET` | `/trainings` | `trainings.index` | `TrainingController@index` | `web`, `auth`, `permission:trainings.view` | `trainings.view` |
| `GET` | `/trainings/create`| `trainings.create` | `TrainingController@create` | `web`, `auth`, `permission:trainings.manage` | `trainings.manage` |
| `POST`| `/trainings` | `trainings.store` | `TrainingController@store` | `web`, `auth`, `permission:trainings.manage` | `trainings.manage` |
| `GET` | `/trainings/{training}`| `trainings.show` | `TrainingController@show` | `web`, `auth`, `permission:trainings.view` | `trainings.view` |
| `GET` | `/trainings/{training}/edit`| `trainings.edit`| `TrainingController@edit` | `web`, `auth`, `permission:trainings.manage` | `trainings.manage` |
| `PUT` | `/trainings/{training}`| `trainings.update`| `TrainingController@update` | `web`, `auth`, `permission:trainings.manage` | `trainings.manage` |
| `DELETE`| `/trainings/{training}`| `trainings.destroy`| `TrainingController@destroy`| `web`, `auth`, `permission:trainings.manage` | `trainings.manage` |
| **Calendario** | | | | | |
| `GET` | `/calendar` | `calendar.index` | `CalendarController@index` | `web`, `auth`, `permission:calendar.view` | `calendar.view` y rol administrador |
| **Solicitudes de Capacitación** | | | | | |
| `GET` | `/requests` | `requests.index` | `TrainingRequestController@index` | `web`, `auth`, `permission:requests.view` | `requests.view` |
| `GET` | `/requests/create` | `requests.create` | `TrainingRequestController@create` | `web`, `auth`, `permission:requests.create` | `requests.create` |
| `POST`| `/requests` | `requests.store` | `TrainingRequestController@store` | `web`, `auth`, `permission:requests.create` | `requests.create` |
| `GET` | `/requests/{training_request}`| `requests.show`| `TrainingRequestController@show` | `web`, `auth`, `permission:requests.view` | `requests.view` |
| `POST`| `/requests/{training_request}/review`| `requests.review`| `TrainingRequestController@review` | `web`, `auth`, `permission:requests.approve` | `requests.approve` |
| **Participantes** | | | | | |
| `GET` | `/participants` | `participants.index` | `ParticipantController@index` | `web`, `auth`, `permission:participants.view` | `participants.view` y rol administrador |
| `GET` | `/participants/{participant}` | `participants.show` | `ParticipantController@show` | `web`, `auth`, `permission:participants.view` | `participants.view` y rol administrador |
| **Reportes y Analítica** | | | | | |
| `GET` | `/reports` | `reports.index` | `ReportController@index` | `web`, `auth`, `permission:reports.view` | `reports.view` |
| `GET` | `/reports/trainings/export` | `reports.trainings.export` | `ReportController@exportTrainings` | `web`, `auth`, `permission:reports.view` | `reports.view` |
| **Usuarios y Permisos (Administración)** | | | | | |
| `GET` | `/users` | `users.index` | `UserController@index` | `web`, `auth`, `permission:users.view` | `users.view` |
| `GET` | `/users/create` | `users.create` | `UserController@create` | `web`, `auth`, `permission:users.manage` | `users.manage` |
| `POST`| `/users` | `users.store` | `UserController@store` | `web`, `auth`, `permission:users.manage` | `users.manage` |
| `GET` | `/users/{user}/edit`| `users.edit` | `UserController@edit` | `web`, `auth`, `permission:users.manage` | `users.manage` |
| `PUT` | `/users/{user}` | `users.update` | `UserController@update` | `web`, `auth`, `permission:users.manage` | `users.manage` |
| `GET` | `/users/{user}/permissions`| `users.permissions`| `UserController@permissions`| `web`, `auth`, `permission:users.permissions`| `users.permissions`|
| `PUT` | `/users/{user}/permissions`| `users.permissions.sync`| `UserController@syncPermissions`| `web`, `auth`, `permission:users.permissions`| `users.permissions`|

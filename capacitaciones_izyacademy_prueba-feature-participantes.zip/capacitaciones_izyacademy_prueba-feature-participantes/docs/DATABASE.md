# Documentación Técnica de Base de Datos y Modelo Entidad-Relación (DER)

Este documento especifica la arquitectura del modelo relacional agnóstico de la plataforma de capacitaciones corporativas, diseñado para ejecutarse transparentemente en **MySQL**, **MariaDB**, **PostgreSQL** o **SQLite**. Todas las tablas incorporan índices explícitos para acelerar las consultas más frecuentes y mitigar cuellos de botella de I/O.

---

## 1. Diagrama Entidad-Relación (DER) en Mermaid.js

```mermaid
erDiagram
    ROLES ||--o{ USERS : "define el rol base"
    ROLES ||--|{ ROLE_HAS_PERMISSIONS : "asigna conjunto"
    PERMISSIONS ||--|{ ROLE_HAS_PERMISSIONS : "incluido en"
    
    USERS ||--o{ USER_HAS_PERMISSIONS : "override directo"
    PERMISSIONS ||--o{ USER_HAS_PERMISSIONS : "concedido a"
    
    TRAINING_CATEGORIES ||--o{ TRAININGS : "clasifica tematicamente"
    TRAINING_CATEGORIES ||--o{ TRAINING_REQUESTS : "requerida para"
    
    USERS ||--o{ TRAININGS : "creada y gestionada por"
    USERS ||--o{ TRAINING_REQUESTS : "postulada por lider"
    
    TRAININGS ||--o| TRAINING_REQUESTS : "asociada a aprobacion"
    PARTICIPANTS ||--o{ PARTICIPANT_TRAINING_REQUEST : "inscrito en solicitud"
    TRAINING_REQUESTS ||--o{ PARTICIPANT_TRAINING_REQUEST : "incluye participante"
    PARTICIPANTS ||--o{ PARTICIPANT_TRAINING : "vinculado a capacitacion"
    TRAININGS ||--o{ PARTICIPANT_TRAINING : "tiene participantes"
    TRAININGS ||--o{ TRAINING_SESSIONS : "se agenda en sesiones"

    ROLES {
        bigint id PK
        varchar_255 name "Nombre legible"
        varchar_255 slug UK "Slug unico"
        varchar_255 description "Alcance del rol"
        timestamp created_at
        timestamp updated_at
    }

    PERMISSIONS {
        bigint id PK
        varchar_255 name UK "Identificador (ej. trainings.manage)"
        varchar_255 module_group "Modulo funcional"
        varchar_255 description "Detalle del privilegio"
        timestamp created_at
        timestamp updated_at
    }

    ROLE_HAS_PERMISSIONS {
        bigint role_id PK, FK "Referencia a roles.id"
        bigint permission_id PK, FK "Referencia a permissions.id"
    }

    USERS {
        bigint id PK
        bigint role_id FK "Referencia a roles.id"
        varchar_255 name "Nombre completo"
        varchar_255 email UK "Correo corporativo"
        varchar_255 password "Hash Bcrypt/Argon2"
        boolean is_active "Estado de habilitacion"
        varchar_100 remember_token
        timestamp created_at
        timestamp updated_at
    }

    USER_HAS_PERMISSIONS {
        bigint user_id PK, FK "Referencia a users.id"
        bigint permission_id PK, FK "Referencia a permissions.id"
    }

    TRAINING_CATEGORIES {
        bigint id PK
        varchar_255 name "Nombre de la categoria"
        varchar_255 slug UK "Slug unico indexado"
        text description "Alcance metodologico"
        timestamp created_at
        timestamp updated_at
    }

    TRAININGS {
        bigint id PK
        bigint category_id FK "Referencia a training_categories.id"
        bigint created_by_user_id FK "Referencia a users.id"
        varchar_255 title "Titulo oficial del programa"
        text description "Objetivos y contenidos"
        varchar_255 expert_name "Nombre del facilitador"
        varchar_500 expert_avatar_url "Avatar opcional"
        integer duration_hours "Horas academicas"
        text schedule_details "Resumen del cronograma"
        varchar_20 modality "Modalidad virtual o presencial"
        boolean is_public_for_externals "Visibilidad para externos"
        boolean has_certificate "Habilita certificado"
        varchar_500 certificate_template_url "Muestra o plantilla"
        timestamp created_at
        timestamp updated_at
    }

    TRAINING_REQUESTS {
        bigint id PK
        bigint requested_by_user_id FK "Referencia a users.id"
        bigint category_id FK "Referencia a training_categories.id"
        bigint approved_training_id FK "Referencia a trainings.id (Nullable)"
        varchar_255 title "Titulo de la necesidad"
        varchar_255 client_name "Cliente de la solicitud"
        text justification "Justificacion tecnica"
        integer estimated_participants "Cupos proyectados"
        enum status "pending, reviewing, approved, rejected"
        text rejection_reason "Motivo en caso de rechazo"
        timestamp created_at
        timestamp updated_at
    }

    PARTICIPANTS {
        bigint id PK
        varchar_100 first_name "Nombre"
        varchar_150 last_name "Apellidos"
        varchar_255 email UK "Correo corporativo"
        varchar_255 personal_email "Correo personal opcional"
        varchar_30 phone "Celular"
        varchar_100 city "Ciudad"
        timestamp created_at
        timestamp updated_at
    }

    PARTICIPANT_TRAINING_REQUEST {
        bigint participant_id PK, FK
        bigint training_request_id PK, FK
        timestamp created_at
        timestamp updated_at
    }

    PARTICIPANT_TRAINING {
        bigint participant_id PK, FK
        bigint training_id PK, FK
        timestamp created_at
        timestamp updated_at
    }

    TRAINING_SESSIONS {
        bigint id PK
        bigint training_id FK "Referencia a trainings.id"
        date session_date "Fecha de la sesión"
        time start_time "Hora local de inicio"
        time end_time "Hora local de finalización"
        timestamp created_at
        timestamp updated_at
    }
```

---

## 2. Especificación Detallada de Tablas e Índices de Rendimiento

### 2.1. Tabla `roles`
Almacena los roles institucionales básicos (*Administrador*, *Directores y Lideres*, *Externos*).
- **Clave Primaria**: `id` (BIGINT UNSIGNED, AUTO_INCREMENT).
- **Restricciones de Unicidad**: `slug` (UNIQUE).
- **Índices**:
  - `roles_slug_index` en columna `slug` para resoluciones rápidas en middleware y policies.
- **Acción ante Eliminación**: `RESTRICT` desde tabla `users` para impedir que se elimine un rol que tenga usuarios asignados.

### 2.2. Tabla `permissions`
Define el catálogo de capacidades granulares del sistema.
- **Clave Primaria**: `id` (BIGINT UNSIGNED, AUTO_INCREMENT).
- **Restricciones de Unicidad**: `name` (UNIQUE).
- **Índices**:
  - `permissions_name_index` en columna `name` (búsquedas instantáneas en `$user->hasPermissionTo()`).
  - `permissions_module_group_index` en columna `module_group` (para agrupaciones masivas y renderizado rápido del checklist).

### 2.3. Tabla Pivote `role_has_permissions`
Relación muchos a muchos entre roles y permisos.
- **Clave Primaria Compuesta**: `(role_id, permission_id)`.
- **Claves Foráneas**:
  - `role_id` -> `roles(id)` con `ON DELETE CASCADE`.
  - `permission_id` -> `permissions(id)` con `ON DELETE CASCADE`.
- **Índices**:
  - `role_has_permissions_role_id_index`.
  - `role_has_permissions_permission_id_index`.

### 2.4. Tabla `users`
Cuentas corporativas del sistema.
- **Clave Primaria**: `id` (BIGINT UNSIGNED, AUTO_INCREMENT).
- **Restricciones de Unicidad**: `email` (UNIQUE).
- **Foto de perfil**: `profile_photo_path` guarda la ruta del archivo WebP en el disco público; la imagen no se almacena como binario en la base de datos.
- **Claves Foráneas**:
  - `role_id` -> `roles(id)` con `ON DELETE RESTRICT`.
- **Índices de Alto Rendimiento**:
  - `users_role_id_index` (Acelera filtros de directorio por rol).
  - `users_email_index` (Acelera autenticación).
  - `users_is_active_index` (Acelera filtros por cuentas activas/inactivas).
  - **Índice Compuesto**: `users_role_id_is_active_index` en `(role_id, is_active)` para reportes y filtrados multi-criterio sin escaneo de tabla.

### 2.5. Tabla Pivote `user_has_permissions` (Checklist de Permisos Dinámicos)
Permite al Administrador otorgar o revocar permisos individuales a colaboradores específicos, sobreescribiendo o ampliando los privilegios de su rol.
- **Clave Primaria Compuesta**: `(user_id, permission_id)`.
- **Claves Foráneas**:
  - `user_id` -> `users(id)` con `ON DELETE CASCADE`.
  - `permission_id` -> `permissions(id)` con `ON DELETE CASCADE`.
- **Índices**:
  - `user_has_permissions_user_id_index`.
  - `user_has_permissions_permission_id_index`.

### 2.6. Tabla `training_categories`
Clasificación de áreas de conocimiento y especialidades formativas.
- **Clave Primaria**: `id` (BIGINT UNSIGNED, AUTO_INCREMENT).
- **Restricciones de Unicidad**: `slug` (UNIQUE).
- **Índices**:
  - `training_categories_slug_index`.
  - `training_categories_name_index`.
- **Categorías Sembradas**: *Calidad del Software*, *Automatización de pruebas*, *Requerimientos*, *Pruebas de Performance*, *Metodologías Ágiles*, *Ciberseguridad*, *IA generativa*.

### 2.7. Tabla `trainings`
Programas oficiales de capacitación corporativa impartidos o programados.
- **Clave Primaria**: `id` (BIGINT UNSIGNED, AUTO_INCREMENT).
- **Claves Foráneas**:
  - `category_id` -> `training_categories(id)` con `ON DELETE RESTRICT`.
  - `created_by_user_id` -> `users(id)` con `ON DELETE RESTRICT`.
- **Índices de Alto Rendimiento**:
  - `trainings_category_id_index` (Filtros instantáneos por línea temática).
  - `trainings_created_by_user_id_index` (Trazabilidad del creador).
  - `trainings_is_public_for_externals_index` (Filtrado para usuarios con rol externo).
  - `trainings_has_certificate_index` (Búsqueda de cursos con certificación).
  - **Índice Compuesto**: `trainings_category_id_is_public_for_externals_index` en `(category_id, is_public_for_externals)` para catálogos públicos.
  - `trainings_title_index` (Búsquedas rápidas por coincidencia de texto).

### 2.8. Directorio e historial de participantes
La tabla `participants` almacena una ficha por correo corporativo. En el registro de participantes se admite la letra `ñ` en la parte local del correo (antes de `@`); el dominio debe conservar el formato y las extensiones aceptados por la validación. También se almacena el correo personal opcional, celular y ciudad. Cada solicitud conserva sus participantes en `participant_training_request`; al aprobarse, estos se vinculan a la capacitación oficial mediante `participant_training`. El directorio administrativo permite buscar por nombre, apellidos o correo y consultar el total y el detalle de capacitaciones vinculadas. Este historial refleja asociaciones de solicitudes aprobadas; el sistema no registra asistencia o finalización.

### 2.9. Tabla `training_requests`
Solicitudes de capacitación postuladas por Directores y Líderes de área.
- **Clave Primaria**: `id` (BIGINT UNSIGNED, AUTO_INCREMENT).
- **Claves Foráneas**:
  - `requested_by_user_id` -> `users(id)` con `ON DELETE CASCADE`.
  - `category_id` -> `training_categories(id)` con `ON DELETE RESTRICT`.
  - `approved_training_id` -> `trainings(id)` con `ON DELETE SET NULL` (Nullable).
- **Índices de Optimización**:
  - `training_requests_requested_by_user_id_index` (Filtros de "Mis Solicitudes").
  - `training_requests_category_id_index`.
  - `training_requests_approved_training_id_index`.
  - `training_requests_status_index` (Embudo de solicitudes pendientes/aprobadas).
  - **Índices Compuestos**:
    - `training_requests_requested_by_user_id_status_index` en `(requested_by_user_id, status)`.
    - `training_requests_category_id_status_index` en `(category_id, status)`.
  - `training_requests_created_at_index` (Ordenamiento cronológico paginado).

### 2.10. Sesiones y calendario de capacitaciones
La tabla `training_sessions` almacena las fechas y horas locales de cada sesión vinculada a una capacitación. Una capacitación puede tener varias sesiones. El calendario está disponible para administradores en vistas de día, semana y mes; las capacitaciones existentes deben editarse para agregar sesiones estructuradas. `modality` identifica la modalidad virtual o presencial; `schedule_details` conserva el resumen legible para el catálogo.

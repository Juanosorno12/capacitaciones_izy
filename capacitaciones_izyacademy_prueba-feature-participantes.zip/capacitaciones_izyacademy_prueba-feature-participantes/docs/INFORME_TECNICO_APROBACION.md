# Informe técnico para revisión y aprobación

**Proyecto:** IzyCapacitaciones Corporativas  
**Audiencia:** Dirección de Desarrollo, Dirección de Gestión de Tecnología y Dirección de Seguridad de la Información  
**Fecha de referencia:** 7 de octubre de 2026  
**Código revisado:** rama `feature/participantes`, commit `80ea2c4`  
**Propósito:** describir el alcance y la implementación observables en el código para apoyar la revisión técnica. Este documento no constituye una auditoría, una certificación de seguridad ni una aprobación de despliegue.

---

## 1. Resumen ejecutivo

IzyCapacitaciones es una aplicación web corporativa para gestionar solicitudes de formación, participantes, capacitaciones programadas, sesiones, calendario, usuarios, permisos y reportes.

El proyecto está construido sobre Laravel y organiza las peticiones en rutas, middleware, validación de formularios, controladores, servicios, modelos y vistas Blade. El acceso a las operaciones se controla con autenticación y permisos por rol, y las operaciones que afectan registros relacionados usan transacciones de base de datos.

El código revisado incluye, entre otros flujos, la captura de participantes en solicitudes, la aprobación y programación de capacitaciones, la selección de un curso existente por categoría y la carga opcional de fotos WebP para usuarios. El catálogo contempla una bandera que indica si una capacitación ofrece certificado, pero **la emisión de certificados personalizados en PDF, el registro de asistencia y la confirmación de finalización no están implementados**.

El proyecto está listo para una revisión técnica y una validación de alcance. La aprobación para producción debe condicionarse a la verificación de configuración del entorno, controles de privacidad de datos, almacenamiento de imágenes, pruebas funcionales/de seguridad y procedimientos operativos.

## 2. Objetivos funcionales

- Registrar y revisar solicitudes de capacitación.
- Administrar participantes y su asociación con solicitudes y cursos.
- Convertir solicitudes aprobadas en capacitaciones programadas con sesiones.
- Consultar el catálogo de capacitaciones y el calendario.
- Administrar cuentas y permisos de usuarios.
- Consultar indicadores e informes de capacitaciones y sesiones.

## 3. Arquitectura técnica

### 3.1 Componentes y tecnologías

| Área | Implementación identificada |
|---|---|
| Backend | PHP `^8.2`; Laravel `^10.0` o `^11.0`, según `composer.json`. |
| Persistencia | Eloquent ORM y migraciones Laravel. MySQL/MariaDB es la configuración local predeterminada; el código/documentación contempla motores compatibles adicionales. |
| Interfaz | Vistas Blade, Tailwind CSS, Alpine.js y Vite. |
| Visualización | Chart.js para gráficos. |
| Excel | `fflate` en el navegador para procesar participantes desde `.xlsx` y apoyar exportaciones. |
| Desarrollo local documentado | Laragon en Windows, Apache y MySQL/MariaDB. |
| Despliegue documentado | Ubuntu Server LTS, Nginx, PHP-FPM y HTTPS; el documento de despliegue sirve como guía y debe contrastarse con la infraestructura real. |

Las versiones exactas resueltas de paquetes se encuentran en `composer.lock` y `package-lock.json`; las restricciones declaradas están en `composer.json` y `package.json`.

### 3.2 Estructura de una petición

```text
Navegador
  -> routes/web.php
  -> middleware de sesión/autenticación/permisos
  -> Form Request (autorización y validación, cuando aplica)
  -> Controller
  -> Service (reglas de negocio y transacciones)
  -> Model / Eloquent
  -> base de datos
  -> respuesta Blade, redirección o JSON
```

Los controladores coordinan el flujo. Los servicios concentran las operaciones de negocio y transacciones; los modelos describen las entidades y relaciones; las vistas presentan los datos.

## 4. Módulos y estado funcional

| Módulo | Alcance observable |
|---|---|
| Solicitudes | Creación, consulta y flujo de estados `pending`, `reviewing`, `approved` y `rejected`; captura de categoría, curso del catálogo, cliente, justificación y participantes. |
| Aprobación | La aprobación crea la capacitación y sus sesiones, asocia participantes y actualiza la solicitud dentro de una transacción. |
| Participantes | Directorio, datos de contacto e historial de asociaciones a solicitudes/capacitaciones. Se permite carga de participantes desde `.xlsx` en el navegador. |
| Capacitaciones | Catálogo por categoría, detalle, sesiones, facilitador, modalidad, visibilidad y participantes. |
| Calendario | Consulta de sesiones en vistas por periodo; el acceso está sujeto a permiso y controles del módulo. |
| Reportes | Indicadores y exportación. La clasificación de sesiones como finalizadas se infiere de su fecha y hora programada; no demuestra asistencia real. |
| Usuarios y permisos | Gestión de usuarios activos/inactivos, roles y permisos efectivos por rol más permisos directos. En altas/edición se admite una foto de perfil WebP. |
| Certificados | Existe el indicador `has_certificate` y una muestra visual. No se encontró emisión individual verificable ni gestión de finalización/asistencia. |

### 4.1 Flujo principal de solicitud

1. Un usuario con `requests.create` selecciona una categoría y una capacitación de esa categoría.
2. El servidor valida que la capacitación elegida exista y pertenezca a la categoría enviada.
3. La solicitud y sus participantes se guardan; la resolución o actualización del participante usa el correo corporativo.
4. Un usuario autorizado revisa, aprueba o rechaza la solicitud.
5. Al aprobarla, el servicio genera los registros relacionados dentro de una transacción.

## 5. Modelo de datos de alto nivel

Entidades centrales:

- `users`, `roles`, `permissions` y pivotes de asignación: autenticación y autorización.
- `training_categories` y `trainings`: catálogo formativo y atributos de los cursos.
- `training_requests`: solicitudes y su estado de revisión.
- `participants`: información de participantes.
- `participant_training_request` y `participant_training`: asociaciones de participantes con solicitudes y capacitaciones.
- `training_sessions`: fechas y horas programadas.

Las relaciones y el diccionario de campos están desarrollados en [DATABASE.md](./DATABASE.md) y [DATA_DICTIONARY_AND_ROUTES.md](./DATA_DICTIONARY_AND_ROUTES.md).

## 6. Controles de seguridad visibles en el código

Los siguientes controles se identificaron en el código revisado; deben probarse en el entorno integrado y no sustituyen una evaluación de seguridad:

- **Autenticación:** acceso por correo y contraseña; la aplicación rechaza cuentas inactivas. La sesión se regenera al iniciar sesión y se invalida al cerrar sesión.
- **Autorización:** middleware de permiso en rutas y autorización en varios `FormRequest`. La interfaz puede ocultar acciones, pero la autorización efectiva se aplica en el servidor.
- **Permisos:** los permisos efectivos combinan los del rol con los permisos directos del usuario.
- **CSRF:** el grupo web de Laravel incluye middleware de verificación CSRF; los formularios inspeccionados incluyen token.
- **Contraseñas:** se usa el cast `hashed` de Laravel y hay llamadas explícitas a `Hash::make`.
- **Validación de formularios:** los datos se validan en el servidor mediante reglas de Laravel; la validación JavaScript/HTML es complementaria.
- **Consistencia:** operaciones críticas que crean o asocian múltiples registros usan transacciones.
- **Cargas WebP:** el archivo de foto se valida por firma RIFF/WEBP y límite de 2 MB. El archivo se guarda fuera de la base de datos.
- **Sesión/cookies:** la configuración marca la cookie como `http_only`; `secure` depende de la variable de entorno y `same_site` está en `lax`.

### 6.1 Aspectos que requieren decisión o verificación de Seguridad de la Información

1. **Fotos en disco público:** el disco `public` genera URLs servibles a través de `public/storage`. Definir si las fotos de perfil pueden ser accesibles sin autenticación. Si no, migrarlas a almacenamiento privado y servirlas mediante una ruta autorizada.
2. **Datos personales:** solicitudes y participantes contienen correo corporativo, correo personal opcional, teléfono y ciudad. Definir clasificación, finalidad, acceso, retención, eliminación y controles de respaldo para estos datos.
3. **Configuración de producción:** `.env.example` está orientado a desarrollo (`APP_ENV=local`, `APP_DEBUG=true`). Producción requiere configuración propia, `APP_DEBUG=false`, HTTPS, secretos administrados de forma segura y permisos mínimos.
4. **Protecciones perimetrales:** revisar la limitación de intentos del login, políticas de contraseñas, MFA/SSO, cabeceras/CSP, TLS, WAF/proxy y monitoreo según estándares corporativos.
5. **Archivos cargados:** confirmar límites del servidor/proxy, protección contra contenido malformado, escaneo antimalware si aplica, políticas de acceso, respaldo y ciclo de vida de las imágenes.
6. **Auditoría:** validar si los registros actuales satisfacen la trazabilidad requerida para cambios de permisos, usuarios, solicitudes y futuras emisiones de certificados; definir retención y acceso a logs.
7. **Dependencias y cambios:** realizar análisis de dependencias y revisión del diff mediante el proceso corporativo de GitLab antes de integrar o desplegar.

Los puntos anteriores son asuntos de revisión y verificación, no afirmaciones de vulnerabilidad confirmada.

## 7. Certificados: alcance actual y brechas

Actualmente:

- `trainings.has_certificate` indica si una capacitación ofrece certificado.
- Existe una imagen de muestra y el campo `certificate_template_url`.
- La vista de detalle permite previsualizar una imagen de referencia.

No se encontró:

- registro por participante de asistencia o finalización;
- regla de elegibilidad aprobada para emitir certificados;
- generación de un PDF personalizado por participante;
- código de verificación o registro inmutable de emisiones;
- una sección administrativa para gestionar plantilla, firmante, cargo o firma.

Se recomienda implementar estos elementos por etapas, con autorización administrativa, versiones de plantilla y firma, y copia de los datos usados al momento de cada emisión.

## 8. Validación técnica y límites de esta revisión

En cambios recientes del código de la rama revisada se ejecutaron comprobaciones puntuales de sintaxis PHP, compilación Blade, formato con Laravel Pint y validación de reglas para la selección de curso/categoría y carga WebP. La migración de foto de perfil aparece aplicada en la base local utilizada durante el trabajo.

Estas comprobaciones **no equivalen a una batería completa de pruebas**. En la raíz inspeccionada no se encontró un directorio `tests/`; por tanto, no se dispone aquí de evidencia de pruebas automatizadas de regresión, integración, carga o seguridad. Tampoco se ejecutó una auditoría formal, prueba de penetración ni análisis corporativo de dependencias como parte de este informe.

El informe describe el estado del código local en la revisión identificada al inicio. No acredita el estado de un servidor, la infraestructura, datos, políticas corporativas, configuración de producción ni disponibilidad del servicio.

## 9. Recomendaciones para revisión y aprobación

### Dirección de Desarrollo

- Confirmar reglas funcionales, estados y responsables del flujo de solicitudes.
- Solicitar pruebas automatizadas para solicitudes, autorizaciones, participantes, asociación curso/categoría y transacciones.
- Definir estrategia de ramas, revisión por merge request, calidad de código y mantenimiento de dependencias.
- Acordar alcance y criterios de aceptación para asistencia y emisión de certificados.

### Dirección de Gestión de Tecnología

- Confirmar arquitectura de despliegue, ambientes, sizing, disponibilidad y escalabilidad.
- Acordar motor/versión de base de datos, migraciones, plan de respaldo y restauración.
- Definir almacenamiento compartido/privado para archivos, permisos, monitoreo, logs y alertas.
- Validar la guía operativa de despliegue frente a la plataforma corporativa real; acordar pipeline y estrategia de reversión.

### Dirección de Seguridad de la Información

- Clasificar y aprobar el tratamiento de datos de usuarios y participantes.
- Resolver si las fotos de perfil deben ser públicas o de acceso autenticado.
- Revisar autenticación, MFA/SSO, limitación de login, sesiones y ciclo de vida de cuentas.
- Revisar manejo de secretos, HTTPS/TLS, cabeceras, configuración de producción, archivos y registros de auditoría.
- Solicitar análisis de dependencias, revisión de código y pruebas de seguridad según el proceso corporativo.

## 10. Criterios sugeridos antes de autorizar producción

- Aprobación funcional y de seguridad documentadas.
- Ambiente de producción con secretos fuera del repositorio, `APP_DEBUG=false`, HTTPS y acceso mínimo necesario.
- Política aprobada para archivos y datos personales, incluyendo retención y respaldo.
- Migraciones ensayadas en un ambiente equivalente y estrategia de restauración comprobada.
- Pruebas funcionales de flujos críticos y revisión de regresión; resultados adjuntos al proceso de cambio.
- Escaneo de dependencias y resolución o aceptación formal de hallazgos.
- Monitoreo, alertas, respuesta a incidentes y responsables operativos definidos.
- Merge request revisada y trazabilidad del artefacto desplegado al commit aprobado.

## 11. Referencias del repositorio

- [README.md](../README.md): resumen funcional, requisitos y arranque local.
- [CODEBASE_REFERENCE.md](./CODEBASE_REFERENCE.md): módulos, flujos y responsabilidades por capa.
- [DEVELOPER_GUIDE.md](./DEVELOPER_GUIDE.md): guía de mantenimiento y validación.
- [DATABASE.md](./DATABASE.md): entidades, relaciones e índices.
- [DATA_DICTIONARY_AND_ROUTES.md](./DATA_DICTIONARY_AND_ROUTES.md): campos, rutas y permisos.
- [DEPLOYMENT_AND_OPTIMIZATION.md](./DEPLOYMENT_AND_OPTIMIZATION.md): ejemplo de despliegue y operación.
- `composer.json`, `composer.lock`, `package.json` y `package-lock.json`: dependencias declaradas y resoluciones.

# Guía de Despliegue en Producción y Optimización de Alto Rendimiento

Esta guía detalla el aprovisionamiento, despliegue, securización y optimización de la plataforma en servidores Linux dedicados (**Ubuntu Server 22.04 / 24.04 LTS con Nginx y PHP-FPM 8.2+**) y en plataformas como servicio (**PaaS**).

---

## 1. Aprovisionamiento del Servidor (Ubuntu Server LTS)

### 1.1. Actualización de Repositorios e Instalación de PHP 8.2 / 8.3
```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y software-properties-common curl git unzip ufw

# Agregar repositorio oficial de PHP (Ondřej Surý)
sudo add-apt-repository ppa:ondrej/php -y
sudo apt update

# Instalar PHP y módulos de alto rendimiento requeridos
sudo apt install -y php8.2-fpm php8.2-cli php8.2-mysql php8.2-pgsql php8.2-sqlite3 \
    php8.2-mbstring php8.2-xml php8.2-curl php8.2-zip php8.2-bcmath php8.2-intl \
    php8.2-redis php8.2-opcache

# Instalar Nginx y Composer
sudo apt install -y nginx
curl -sS https://getcomposer.org/installer | sudo php -- --install-dir=/usr/local/bin --filename=composer

# Instalar Node.js LTS para compilación de assets
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
```

---

## 2. Configuración de Nginx para Laravel

Crea el archivo de configuración del host virtual en `/etc/nginx/sites-available/capacitaciones`:

```nginx
server {
    listen 80;
    listen [::]:80;
    server_name capacitaciones.tuempresa.com;
    root /var/www/capacitaciones-app/public;

    # Headers de Seguridad Corporativos
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' https: data: 'unsafe-inline' 'unsafe-eval';" always;

    index index.php index.html;
    charset utf-8;

    # Compresión Gzip para Payload < 15KB
    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css text/xml application/json application/javascript application/rss+xml application/atom+xml image/svg+xml;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location = /favicon.ico { access_log off; log_not_found off; }
    location = /robots.txt  { access_log off; log_not_found off; }

    error_page 404 /index.php;

    # Enrutamiento PHP-FPM 8.2
    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
        fastcgi_hide_header X-Powered-By;
        fastcgi_read_timeout 60;
    }

    # Caché agresiva para assets estáticos compilados (Vite)
    location ~* \.(jpg|jpeg|png|gif|ico|css|js|woff|woff2|svg)$ {
        expires 365d;
        add_header Cache-Control "public, no-transform";
        access_log off;
    }

    # Bloquear acceso a archivos ocultos y sensibles
    location ~ /\.(?!well-known).* {
        deny all;
    }
}
```

Habilitar el sitio y reiniciar Nginx:
```bash
sudo ln -s /etc/nginx/sites-available/capacitaciones /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

---

## 3. Despliegue del Código y Permisos de Almacenamiento

```bash
cd /var/www
sudo git clone https://github.com/tu-organizacion/capacitaciones-app.git
cd capacitaciones-app

# Instalar dependencias sin paquetes de desarrollo y con autoloader optimizado
sudo composer install --no-dev --optimize-autoloader

# Compilar assets para producción
npm ci
npm run build

# Configurar permisos de almacenamiento y caché
sudo chown -R www-data:www-data /var/www/capacitaciones-app
sudo chmod -R 775 /var/www/capacitaciones-app/storage
sudo chmod -R 775 /var/www/capacitaciones-app/bootstrap/cache
```

Las vistas sirven sus estilos y scripts mediante `@vite`; por eso `npm run build` debe ejecutarse en cada despliegue y el directorio `public/build` debe estar disponible en el servidor. La aplicación no depende de Tailwind, Alpine, Chart.js ni fuentes descargadas desde CDN para renderizar sus páginas.

---

## 4. Batería de Comandos de Caché y Optimización de Laravel

Ejecutar obligatoriamente en cada pipeline de despliegue continuo (CI/CD):

```bash
# 1. Limpieza preventiva
php artisan clear-compiled
php artisan optimize:clear

# 2. Caché de Configuración (Elimina la lectura recursiva de archivos .env y config/*.php)
php artisan config:cache

# 3. Caché de Rutas (Convierte el árbol de rutas en un array serializado instantáneo)
php artisan route:cache

# 4. Caché de Vistas Blade (Pre-compila todas las plantillas Blade a PHP puro)
php artisan view:cache

# 5. Caché de Eventos y Listeners
php artisan event:cache

# 6. Ejecutar migraciones en base de datos
php artisan migrate --force
```

---

## 5. Optimización del Motor PHP: OPcache y PHP-FPM

Editar `/etc/php/8.2/fpm/php.ini`:
```ini
[opcache]
opcache.enable=1
opcache.memory_consumption=256
opcache.interned_strings_buffer=16
opcache.max_accelerated_files=20000
opcache.validate_timestamps=0   ; En producción: 0 para no revalidar disco en cada request
opcache.save_comments=1
opcache.fast_shutdown=1
```

Ajustar `/etc/php/8.2/fpm/pool.d/www.conf` según la RAM del servidor:
```ini
pm = dynamic
pm.max_children = 50
pm.start_servers = 10
pm.min_spare_servers = 5
pm.max_spare_servers = 20
pm.max_requests = 1000
```
Reiniciar el demonio PHP-FPM:
```bash
sudo systemctl restart php8.2-fpm
```

---

## 6. Automatización de Tareas (Cron) y Certificado SSL Gratuito

### 6.1. Programador de Tareas de Laravel (Scheduler)
Editar el crontab del usuario del servidor:
```bash
sudo crontab -u www-data -e
```
Agregar la línea canónica:
```cron
* * * * * cd /var/www/capacitaciones-app && php artisan schedule:run >> /dev/null 2>&1
```

### 6.2. Certificado HTTPS con Certbot (Let's Encrypt)
```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d capacitaciones.tuempresa.com
```

---

## 7. Despliegue Alternativo en Servicios PaaS (Render / Railway / Fly.io)

Si se opta por un despliegue sin administración de infraestructura:
1. Configurar variables de entorno en el panel del PaaS:
   - `APP_ENV=production`
   - `APP_KEY=base64:...`
   - `APP_DEBUG=false`
   - `DB_CONNECTION=pgsql` o `mysql`
   - `CACHE_DRIVER=redis`
2. Configurar el **Build Command**:
   ```bash
   composer install --no-dev --optimize-autoloader && npm install && npm run build
   ```
3. Configurar el **Start Command**:
   ```bash
   php artisan migrate --force && php artisan config:cache && php artisan route:cache && php artisan view:cache && apache2-foreground
   ```

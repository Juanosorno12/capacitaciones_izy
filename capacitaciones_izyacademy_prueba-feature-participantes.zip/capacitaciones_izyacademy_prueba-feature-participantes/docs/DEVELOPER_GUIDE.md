# Guía práctica para desarrolladores

## Plataforma de Capacitaciones Corporativas

Este documento está dirigido a las personas que se incorporen al equipo y necesiten modificar el proyecto sin experiencia previa con esta aplicación. Explica dónde tocar el código, qué archivo controla cada parte y cómo validar los cambios.

La regla principal es sencilla:

> **La vista muestra, el controlador coordina, el servicio aplica reglas de negocio y el modelo representa los datos.**

Si se respeta esa separación, los cambios serán más fáciles de mantener y habrá menos riesgo de romper otras pantallas.

Para consultar la responsabilidad de **cada archivo y carpeta mantenidos**, los flujos completos de participantes/Excel, aprobación, calendario y exportación, empieza por la [referencia del código fuente](CODEBASE_REFERENCE.md). Este documento desarrolla las recetas de cambio más comunes.

---

## 1. Antes de comenzar

### 1.1. Requisitos locales

El proyecto está preparado para trabajar con Laragon en Windows. En el equipo nuevo instala o verifica:

- Laragon con PHP 8.2 o superior (el proyecto requiere PHP `^8.2`), Apache y MySQL o MariaDB.
- Composer y Git.
- Node.js y npm.
- La extensión `zip` de PHP, necesaria para importar y exportar archivos Excel.

Comprueba que la terminal esté usando el PHP de Laragon y que las herramientas estén disponibles:

```powershell
php -v
composer --version
node --version
npm --version
```

Composer también verifica las extensiones requeridas por las dependencias en el paso de instalación.

### 1.2. Inicializar el proyecto en otro equipo

Estos pasos preparan una instalación local nueva. Ejecuta los comandos en PowerShell o en la terminal de Laragon.

1. Inicia Laragon y arranca Apache y MySQL/MariaDB.
2. Clona el repositorio en la carpeta `www`. Reemplaza `URL_DEL_REPOSITORIO` por la URL Git proporcionada para este proyecto:

   ```powershell
   Set-Location C:\laragon\www
   git clone URL_DEL_REPOSITORIO capacitaciones_izyacademy
   Set-Location C:\laragon\www\capacitaciones_izyacademy
   ```

3. Crea una base de datos vacía llamada `capacitaciones_db` desde phpMyAdmin o el gestor de base de datos de Laragon. Se recomienda el cotejamiento `utf8mb4_unicode_ci`.
4. Instala las dependencias fijadas por los archivos de bloqueo y prepara el archivo de entorno:

   ```powershell
   composer install
   npm ci
   if (-not (Test-Path .env)) { Copy-Item .env.example .env }
   ```

5. Abre `.env` y confirma que la URL y los datos de conexión correspondan al equipo local:

   ```powershell
   notepad .env
   ```

   Para la base creada en el paso anterior, la configuración local habitual de Laragon es:

   ```dotenv
   APP_URL=http://capacitaciones_izyacademy.test
   DB_CONNECTION=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=capacitaciones_db
   DB_USERNAME=root
   DB_PASSWORD=
   ```

   La contraseña vacía es solo un valor común de Laragon local; usa las credenciales configuradas en tu servidor. No compartas ni subas el archivo `.env`.

6. Genera la llave de esta instalación, crea las tablas y carga roles, permisos, categorías y datos de demostración:

   ```powershell
   php artisan key:generate
   php artisan migrate --seed
   php artisan storage:link
   ```

7. Compila los estilos y scripts:

   ```powershell
   npm run build
   ```

8. Inicia la aplicación de una de estas maneras:

   - En Laragon, con los virtual hosts automáticos habilitados, abre:

     ```text
     http://capacitaciones_izyacademy.test
     ```

   - O utiliza el servidor de desarrollo de Laravel:

     ```powershell
     php artisan serve
     ```

     Luego abre `http://127.0.0.1:8000`.

Para desarrollo con recarga automática de recursos, ejecuta `npm run dev` en una segunda terminal y déjalo activo mientras trabajas. No dejes un archivo `public/hot` apuntando a un servidor Vite detenido; si ocurre, detén Vite y elimina ese archivo antes de volver a usar los recursos compilados.

> **Importante:** `php artisan migrate --seed` es el comando normal para una base nueva. `php artisan migrate:fresh --seed` elimina todas las tablas y los datos de la base seleccionada; úsalo únicamente en una base local descartable, nunca en producción ni en una base compartida.

### 1.3. Arranques posteriores

Cuando el proyecto ya está instalado, no vuelvas a generar la llave ni a ejecutar migraciones destructivas. Desde la carpeta del proyecto:

```powershell
Set-Location C:\laragon\www\capacitaciones_izyacademy
php artisan serve
```

Si cambian las dependencias PHP o JavaScript, ejecuta `composer install` o `npm ci`, respectivamente. Si solo cambian los estilos o JavaScript, vuelve a compilar con `npm run build`.

### 1.4. Comandos de validación

Después de modificar PHP o rutas:

```bash
php artisan optimize:clear
php artisan route:list
php artisan view:cache
```

Para revisar un archivo PHP individual:

```bash
php -l app/Http/Controllers/NombreController.php
```

Después de modificar estilos o JavaScript:

```bash
npm run build
```

Para consultar migraciones:

```bash
php artisan migrate:status
```

Para revisar errores, consultar:

```text
storage/logs/laravel.log
```

---

## 2. Mapa rápido del proyecto

| Necesidad | Carpeta o archivo principal |
| :--- | :--- |
| Página del dashboard | `resources/views/dashboard/index.blade.php` |
| Datos del dashboard | `app/Http/Controllers/DashboardController.php` |
| Métricas y consultas de reportes | `app/Services/ReportService.php` |
| Informe de sesiones impartidas y descarga XLSX | `app/Http/Controllers/ReportController.php`, `app/Services/ReportService.php`, `resources/js/report-export.js` |
| Lista de solicitudes | `resources/views/requests/index.blade.php` |
| Crear una solicitud | `resources/views/requests/create.blade.php` |
| Detalle de una solicitud | `resources/views/requests/show.blade.php` |
| Lógica de solicitudes | `app/Http/Controllers/TrainingRequestController.php` y `app/Services/TrainingRequestService.php` |
| Importación masiva de participantes | `resources/js/participant-spreadsheet.js` y `resources/views/requests/create.blade.php` |
| Colores generales y botones | `resources/css/app.css` |
| Menú lateral y estructura general | `resources/views/layouts/app.blade.php` |
| Rutas web | `routes/web.php` |
| Página pública de inicio y listado de capacitaciones | `app/Http/Controllers/TrainingController.php`, `resources/views/public/trainings/index.blade.php` |
| Calendario administrativo y consulta de sesiones | `app/Http/Controllers/CalendarController.php`, `resources/views/calendar/index.blade.php` |
| Captura de fechas y horarios de sesiones | `resources/views/components/training-session-fields.blade.php` |
| Directorio e historial de participantes | `app/Http/Controllers/ParticipantController.php`, `resources/views/participants/` |
| Permisos y roles iniciales | `database/seeders/RolePermissionSeeder.php` |
| Usuarios y permisos efectivos | `app/Models/User.php` |
| Campos de solicitudes | `database/migrations/0001_01_01_000008_create_training_requests_table.php` |
| Validación de formularios | `app/Http/Requests/` |
| JavaScript general | `resources/js/app.js` |
| Gráficos de reportes | `resources/js/reports.js` y `resources/views/reports/index.blade.php` |
| Variables de entorno | `.env` y `.env.example` |

---

## 3. Cómo funciona una pantalla

Una petición normalmente sigue este recorrido:

```text
Navegador
  -> routes/web.php
  -> Controller
  -> Form Request, si hay formulario
  -> Service, si hay reglas o consultas de negocio
  -> Model / Base de datos
  -> View Blade
  -> Navegador
```

Ejemplo: ver la lista de solicitudes:

1. `routes/web.php` recibe `GET /requests`.
2. La ruta llama a `TrainingRequestController@index`.
3. El controlador recoge filtros y llama a `TrainingRequestService::listRequests()`.
4. El servicio consulta `TrainingRequest`.
5. El controlador envía los datos a `resources/views/requests/index.blade.php`.
6. Blade genera el HTML.

### 3.1. Qué archivo tocar según el tipo de cambio

- Solo texto, colores, espacios o estructura visual: toca la vista Blade.
- Datos que deben aparecer o dejar de aparecer: toca controlador y, si hace falta, servicio.
- Regla de negocio, filtros o una consulta: toca el servicio.
- Campos aceptados de un formulario: toca el `Form Request`.
- Nueva columna en la base de datos: crea una nueva migración.
- Nueva página o URL: modifica `routes/web.php`, controlador y vista.
- Acceso de usuarios: modifica rutas, permisos y middleware con mucho cuidado.

No pongas consultas SQL grandes dentro de una vista Blade. No pongas HTML dentro de un servicio.

---

## 4. Modificar el dashboard

### 4.1. Cambiar texto o diseño

Archivo principal:

```text
resources/views/dashboard/index.blade.php
```

Este archivo contiene las tres versiones del dashboard:

- Administrador.
- Directores y líderes.
- Usuarios externos.

Busca las secciones que comienzan con:

```blade
@hasRole('administrador')
@hasRole('directores-y-lideres')
```

La vista decide qué bloque mostrar según el rol del usuario.

Ejemplos de cambios que se hacen directamente en esta vista:

- Cambiar el título de bienvenida.
- Cambiar el texto de una tarjeta.
- Cambiar el color de una tarjeta.
- Cambiar el orden visual de los bloques.
- Añadir un enlace o botón.
- Añadir una tarjeta que use datos que ya existen.

### 4.2. Añadir un banner al dashboard

Si el banner es solamente visual, añádelo en:

```text
resources/views/dashboard/index.blade.php
```

El banner de bienvenida actual está cerca del inicio del archivo, después de:

```blade
@section('content')
```

Ejemplo de banner simple:

```blade
<div class="mb-6 rounded-xl border border-[#0055AF]/20 bg-[#EBF3FC] p-5 text-[#1D3A6C]">
    <h3 class="text-base font-bold">Nueva información importante</h3>
    <p class="mt-1 text-sm text-gray-600">
        Aquí puedes escribir el mensaje que verá el equipo.
    </p>
</div>
```

Si el banner debe mostrarse solo a un rol:

```blade
@hasRole('administrador')
    <div class="mb-6 rounded-xl border border-[#FF5F00]/20 bg-[#FFF2EB] p-5 text-[#D95100]">
        <h3 class="font-bold">Aviso para administradores</h3>
        <p class="mt-1 text-sm">Mensaje exclusivo para este rol.</p>
    </div>
@endhasRole
```

Si el banner debe depender de una condición de negocio, no inventes la condición dentro de Blade. Calcula el dato en `DashboardController` o `ReportService` y pásalo a la vista.

Ejemplo:

```php
return view('dashboard.index', [
    'user' => $user,
    'showBanner' => true,
]);
```

En la vista:

```blade
@if($showBanner)
    <div class="mb-6 rounded-xl bg-[#E8F6F3] p-5 text-[#14866A]">
        Hay información nueva para revisar.
    </div>
@endif
```

### 4.3. Añadir una métrica al dashboard

Los datos del dashboard administrativo se preparan en:

```text
app/Http/Controllers/DashboardController.php
app/Services/ReportService.php
```

El controlador obtiene:

```php
$metrics = $this->reportService->getDashboardMetrics();
```

Para una nueva métrica:

1. Añade la consulta en `ReportService.php`.
2. Incluye el valor dentro del arreglo de métricas.
3. Muestra el valor en `resources/views/dashboard/index.blade.php`.
4. Comprueba que la consulta funcione con la base de datos vacía y con datos.

No hagas una consulta nueva directamente desde la vista.

### 4.4. Añadir una tarjeta con solicitudes recientes

La información administrativa ya llega como:

```php
'recentRequests' => $recentRequests,
```

La tarjeta visual se encuentra en:

```text
resources/views/dashboard/index.blade.php
```

Si necesitas un campo que no está disponible, revisa primero `TrainingRequest::withStandardRelations()` en:

```text
app/Models/TrainingRequest.php
```

Allí se define qué relaciones se cargan para evitar consultas repetidas.

---

## 5. Cambiar colores de solicitudes y estados

### 5.1. Archivos de solicitudes

| Pantalla | Archivo |
| :--- | :--- |
| Lista y filtros | `resources/views/requests/index.blade.php` |
| Crear solicitud | `resources/views/requests/create.blade.php` |
| Ver detalle | `resources/views/requests/show.blade.php` |
| Datos y acciones | `app/Http/Controllers/TrainingRequestController.php` |
| Reglas del proceso | `app/Services/TrainingRequestService.php` |
| Validación del formulario | `app/Http/Requests/StoreTrainingRequestForm.php` y `app/Http/Requests/ApproveTrainingRequest.php` |
| Estados permitidos | `app/Models/TrainingRequest.php` y migración de solicitudes |

### 5.2. Estados actuales

Los valores internos son:

| Valor en base de datos | Texto recomendado | Significado |
| :--- | :--- | :--- |
| `pending` | Pendiente | La solicitud fue creada y aún no se ha revisado. |
| `reviewing` | En revisión | Una persona encargada está evaluándola. |
| `approved` | Aprobada | Se aceptó y se convirtió en una capacitación. |
| `rejected` | Rechazada | La solicitud no fue aprobada. |

No cambies estos valores internos solamente para cambiar el texto visible. Los servicios y filtros dependen de ellos.

### 5.3. Cambiar el color de cada estado

Busca en las vistas de solicitudes expresiones parecidas a:

```blade
$trainingRequest->status === 'pending'
$trainingRequest->status === 'approved'
$trainingRequest->status === 'reviewing'
$trainingRequest->status === 'rejected'
```

También existen condiciones similares en el dashboard.

Una forma segura de cambiar colores es mantener el estado y sustituir solamente las clases Tailwind:

```blade
{{ $trainingRequest->status === 'pending' ? 'bg-yellow-100 text-yellow-800' : '' }}
{{ $trainingRequest->status === 'approved' ? 'bg-green-100 text-green-800' : '' }}
{{ $trainingRequest->status === 'reviewing' ? 'bg-blue-100 text-blue-800' : '' }}
{{ $trainingRequest->status === 'rejected' ? 'bg-red-100 text-red-800' : '' }}
```

Para cambiar el texto visible, no uses `ucfirst()` si se necesita un texto amigable. Es preferible un arreglo explícito en la vista o un accesor del modelo:

```blade
@php
    $statusLabels = [
        'pending' => 'Pendiente',
        'reviewing' => 'En revisión',
        'approved' => 'Aprobada',
        'rejected' => 'Rechazada',
    ];
@endphp

{{ $statusLabels[$trainingRequest->status] ?? $trainingRequest->status }}
```

Si el mismo texto aparece en varias pantallas, conviene centralizarlo en el modelo `TrainingRequest` o en un archivo de traducciones, en vez de copiar el arreglo en muchas vistas.

### 5.4. Cambiar los colores generales

Los colores compartidos están definidos en:

```text
resources/css/app.css
resources/views/layouts/app.blade.php
```

`app.css` contiene clases reutilizables como:

```text
btn-primary
btn-navy
btn-orange
badge-teal
badge-navy
badge-orange
badge-red
card
form-input-brand
```

Sin embargo, algunas pantallas usan colores directamente en las clases, por ejemplo:

```blade
bg-[#FFF2EB] text-[#FF5F00]
```

Por eso, al cambiar la identidad visual hay que revisar también las vistas que contienen colores escritos directamente.

El layout define colores Tailwind personalizados dentro de `tailwind.config` del script de:

```text
resources/views/layouts/app.blade.php
```

Si se cambia un color de marca, revisa ambos lugares y luego ejecuta:

```bash
npm run build
```

---

## 6. Añadir o modificar una solicitud

### 6.1. Cambiar campos del formulario

El formulario de creación está en:

```text
resources/views/requests/create.blade.php
```

La validación está en:

```text
app/Http/Requests/StoreTrainingRequestForm.php
```

El guardado pasa por:

```text
app/Http/Controllers/TrainingRequestController.php
app/Services/TrainingRequestService.php
```

Si añades un campo, normalmente debes modificar todos estos puntos:

1. Nueva columna mediante migración.
2. `$fillable` en `app/Models/TrainingRequest.php`.
3. Reglas en el Form Request.
4. Campo HTML en la vista.
5. Datos enviados desde el controlador o servicio.
6. Vista de detalle, lista o dashboard si debe mostrarse allí.

### 6.2. Crear una nueva migración

Nunca edites una migración que ya se haya ejecutado en un entorno compartido. Crea una nueva:

```bash
php artisan make:migration add_example_to_training_requests_table --table=training_requests
```

El archivo nuevo se crea en:

```text
database/migrations/
```

Ejemplo:

```php
Schema::table('training_requests', function (Blueprint $table) {
    $table->string('priority')->default('normal')->after('status');
});
```

Luego:

```bash
php artisan migrate
```

En desarrollo local, si no necesitas conservar los datos:

```bash
php artisan migrate:fresh --seed
```

### 6.3. Regla importante sobre la aprobación

La aprobación de una solicitud no es solo un cambio de texto. `TrainingRequestService` convierte la solicitud en una capacitación programada y actualiza relaciones. Antes de tocar esa parte, lee el método de aprobación completo y prueba los cuatro estados.

---

## 7. Permisos, roles y menú

### 7.1. Permisos internos

Los permisos se definen en:

```text
database/seeders/RolePermissionSeeder.php
```

Ejemplos de identificadores internos:

```text
trainings.view
trainings.manage
requests.view
requests.create
requests.review
requests.approve
reports.view
users.view
users.manage
users.permissions
```

Estos identificadores son técnicos y se usan en rutas, middleware y vistas. No los traduzcas ni los renombres solo para cambiar el texto visible.

Los nombres legibles de la matriz de permisos se encuentran en:

```text
app/Models/Permission.php
```

### 7.2. Proteger una ruta

En `routes/web.php`:

```php
Route::get('/example', [ExampleController::class, 'index'])
    ->middleware('permission:reports.view')
    ->name('example');
```

Esto significa que el usuario necesita el permiso `reports.view`.

### 7.3. Ocultar un botón según permiso

En Blade:

```blade
@hasPermission('users.manage')
    <a href="{{ route('users.create') }}">Nuevo usuario</a>
@endhasPermission
```

Esto solo oculta el botón. La ruta también debe tener middleware, porque una persona puede escribir la URL manualmente.

### 7.4. Cambiar el menú lateral

Archivo:

```text
resources/views/layouts/app.blade.php
```

Cada entrada del menú suele tener:

```blade
@hasPermission('requests.view')
    ... enlace a solicitudes ...
@endhasPermission
```

Si añades una entrada de menú:

1. Comprueba que exista la ruta.
2. Protege la ruta con middleware.
3. Protege el enlace con `@hasPermission`.
4. Asigna el permiso al rol correspondiente en el seeder.
5. Prueba con administrador, líder y usuario externo.

### 7.5. Cambiar roles

Los roles base están en `RolePermissionSeeder.php`. Sus identificadores se usan en el código:

```text
administrador
directores-y-lideres
externos
```

No cambies un slug sin buscar antes todas sus referencias:

```bash
Select-String -Path app,routes,resources,database -Pattern "administrador|directores-y-lideres|externos"
```

---

## 8. Usuarios y matriz de permisos

La pantalla de usuarios está repartida así:

```text
resources/views/users/index.blade.php
resources/views/users/create.blade.php
resources/views/users/edit.blade.php
resources/views/users/permissions.blade.php
app/Http/Controllers/UserController.php
app/Services/UserService.php
app/Models/User.php
```

La matriz de permisos carga los permisos en `UserController::permissions()` y los agrupa por módulo mediante `Permission::getCachedGrouped()`.

Para cambiar el texto visible de un permiso, modifica los nombres legibles del modelo `Permission`, no las comprobaciones como:

```php
$user->hasPermissionTo('users.manage')
```

La aplicación protege al administrador para que no se quite a sí mismo el permiso de administración de usuarios. No elimines esa protección sin una revisión de seguridad.

---

## 9. Añadir una nueva página

### Paso 1: crear el controlador

```bash
php artisan make:controller ExampleController
```

El archivo se crea en:

```text
app/Http/Controllers/ExampleController.php
```

### Paso 2: crear la vista

Crea, por ejemplo:

```text
resources/views/example/index.blade.php
```

Usa el layout existente:

```blade
@extends('layouts.app')

@section('title', 'Ejemplo')
@section('header_title', 'Página de ejemplo')

@section('content')
    <h2 class="text-xl font-bold text-[#1D3A6C]">Contenido</h2>
@endsection
```

### Paso 3: registrar la ruta

En `routes/web.php`:

```php
Route::get('/example', [ExampleController::class, 'index'])
    ->middleware(['auth', 'permission:reports.view'])
    ->name('example.index');
```

### Paso 4: añadir el enlace al menú

Modifica:

```text
resources/views/layouts/app.blade.php
```

### Paso 5: probar

```bash
php artisan route:list --path=example
```

---

## 10. Formularios y validación

Los formularios no deben validar solamente en HTML. Laravel debe validar siempre en el servidor.

| Formulario | Form Request |
| :--- | :--- |
| Crear usuario | `app/Http/Requests/StoreUserRequest.php` |
| Actualizar usuario | `app/Http/Requests/UpdateUserRequest.php` |
| Asignar permisos | `app/Http/Requests/SyncUserPermissionsRequest.php` |
| Crear solicitud | `app/Http/Requests/StoreTrainingRequestForm.php` |
| Revisar o aprobar solicitud | `app/Http/Requests/ApproveTrainingRequest.php` |
| Crear capacitación | `app/Http/Requests/StoreTrainingRequest.php` |
| Actualizar capacitación | `app/Http/Requests/UpdateTrainingRequest.php` |

Cuando un campo nuevo no pasa la validación, revisa primero el Form Request y el nombre exacto del atributo en el formulario.

Los errores llegan a la vista mediante `$errors`. El layout ya contiene un bloque general para mostrarlos.

---

## 11. Capacitaciones

Archivos principales:

```text
resources/views/trainings/index.blade.php
resources/views/trainings/create.blade.php
resources/views/trainings/edit.blade.php
resources/views/trainings/show.blade.php
app/Http/Controllers/TrainingController.php
app/Services/TrainingService.php
app/Models/Training.php
```

El catálogo de categorías se obtiene mediante `TrainingCategory::getCachedAll()`. Si se cambia una categoría, revisa el modelo `TrainingCategory` y su seeder antes de añadir consultas nuevas.

Los usuarios externos solo pueden ver capacitaciones con `is_public_for_externals = true`. Esa regla se valida en `TrainingController::show()` y también en las consultas del servicio. No la reemplaces por una condición visual en Blade.

---

## 12. Reportes y gráficos

Archivos principales:

```text
app/Http/Controllers/ReportController.php
app/Services/ReportService.php
resources/views/reports/index.blade.php
resources/js/reports.js
```

El controlador prepara los datos y la vista incluye los contenedores de los gráficos. El JavaScript transforma esos datos en gráficos de Chart.js.

Si un gráfico no aparece:

1. Revisa que el controlador envíe el arreglo esperado.
2. Revisa el identificador del canvas en la vista.
3. Revisa que `reports.js` use exactamente ese identificador.
4. Ejecuta `npm run build`.
5. Revisa la consola del navegador.

---

## 13. Texto, traducciones y nombres visibles

Para un cambio de texto sencillo, modifica la vista donde aparece. Antes busca todas las apariciones para no dejar textos inconsistentes.

Ejemplos de búsqueda en PowerShell:

```powershell
Select-String -Path resources\views\**\*.blade.php -Pattern "Solicitud"
Select-String -Path resources\views\**\*.blade.php -Pattern "Pendiente|Aprobada|Rechazada"
```

No traduzcas identificadores de código:

```text
requests.approve
users.manage
Route::get
hasPermissionTo
```

Sí puedes traducir sus etiquetas visibles:

```text
Aprobar o rechazar solicitudes
Administrar usuarios
```

---

## 14. Colores y diseño visual

### 14.1. Colores principales actuales

| Uso | Color |
| :--- | :--- |
| Azul institucional | `#1D3A6C` |
| Azul oscuro de interacción | `#13274A` |
| Verde de acciones exitosas | `#19A885` |
| Naranja de avisos y pendientes | `#FF5F00` |
| Azul de enlaces e información | `#0055AF` |
| Fondo general | `#F8FAFC` |
| Texto principal | `#111111` |

### 14.2. Recomendación para colores nuevos

Antes de escribir un color nuevo, revisa si existe una clase reutilizable en `resources/css/app.css`. Evita crear muchos tonos casi iguales.

Ejemplo recomendado:

```blade
<button class="btn-primary">Guardar</button>
```

En vez de repetir en muchas vistas:

```blade
<button class="bg-[#19A885] hover:bg-[#14866A] ...">Guardar</button>
```

Cuando el color sea específico de un estado y no un botón general, puede estar directamente en la vista, pero debe mantenerse igual en lista, detalle y dashboard.

---

## 15. Base de datos y seeders

Las tablas se crean con migraciones en:

```text
database/migrations/
```

Los datos iniciales están en:

```text
database/seeders/
```

Seeders principales:

```text
DatabaseSeeder.php
RolePermissionSeeder.php
UserSeeder.php
TrainingCategorySeeder.php
TrainingSeeder.php
TrainingRequestSeeder.php
```

Los seeders sirven para preparar una instalación de demostración. No deben utilizarse para actualizar datos reales de producción.

Después de añadir una migración, verifica:

```bash
php artisan migrate:status
php artisan migrate
```

Después de cambiar un seeder, prueba en una base local:

```bash
php artisan migrate:fresh --seed
```

---

## 16. Errores frecuentes

### Error 404 en todas las páginas

Ejecuta:

```bash
php artisan route:list
php artisan optimize:clear
```

Comprueba que Apache esté apuntando a `public/` o usa la URL con `/public`.

### Error 403 Acceso restringido

El usuario no tiene el permiso requerido. Revisa:

```text
routes/web.php
app/Http/Middleware/CheckPermission.php
database/seeders/RolePermissionSeeder.php
app/Models/User.php
```

### El cambio visual no aparece

1. Limpia caché:

```bash
php artisan view:clear
php artisan optimize:clear
```

2. Compila assets:

```bash
npm run build
```

3. Recarga el navegador con `Ctrl + F5`.

### El cambio de base de datos no aparece

Comprueba que:

- La migración se ejecutó.
- El nombre de la columna coincide en migración, modelo, Form Request y vista.
- No hay una caché de configuración antigua.

```bash
php artisan optimize:clear
php artisan migrate:status
```

### Error de clase no encontrada

Ejecuta:

```bash
composer dump-autoload
php artisan optimize:clear
```

### Error de conexión con MySQL

Revisa `.env`:

```text
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=capacitaciones_db
DB_USERNAME=root
DB_PASSWORD=
```

No confundas phpMyAdmin con el motor de base de datos. phpMyAdmin es solamente la interfaz para administrar MySQL o MariaDB.

---

## 17. Flujo de trabajo recomendado

Antes de editar:

1. Reproduce el comportamiento actual.
2. Busca el texto, ruta o nombre de variable.
3. Identifica si el cambio es visual, de datos o de negocio.
4. Revisa el controlador, servicio y vista relacionados.

Durante la edición:

1. Haz el cambio más pequeño posible.
2. Conserva nombres internos y permisos existentes.
3. Evita modificar `vendor/`.
4. Evita editar migraciones ya ejecutadas.
5. No mezcles refactorizaciones grandes con un cambio pequeño.

Después de editar:

```bash
php artisan optimize:clear
php artisan route:list
php artisan view:cache
npm run build
```

Después prueba manualmente:

- Inicio de sesión.
- Dashboard del administrador.
- Dashboard de un líder.
- Dashboard de un usuario externo.
- Lista y detalle de solicitudes.
- Crear solicitud.
- Revisar, aprobar y rechazar solicitud.
- Menú según permisos.
- Pantallas de usuarios y permisos.

---

## 18. Qué no modificar sin revisión

No modifiques sin entender primero el impacto:

- `vendor/`.
- `composer.lock` manualmente.
- Los nombres técnicos de permisos.
- Los slugs de roles.
- El middleware `CheckPermission`.
- La conversión de solicitudes aprobadas a capacitaciones.
- La protección para que un administrador no se quite sus propios permisos.
- Las claves foráneas de las migraciones.
- `.env` en producción.

Si el cambio afecta autenticación, permisos, datos de usuarios o eliminación de registros, debe revisarlo otra persona antes de publicarlo.

---

## 19. Lista de comprobación para entregar un cambio

- [ ] Identifiqué la vista, controlador, servicio o modelo correcto.
- [ ] No cambié identificadores técnicos sin buscar sus referencias.
- [ ] Añadí o actualicé validación si el cambio incluye un formulario.
- [ ] Añadí migración si el cambio incluye una columna.
- [ ] Probé los permisos con más de un rol.
- [ ] Ejecuté `php artisan optimize:clear`.
- [ ] Ejecuté `php artisan route:list` si cambié rutas.
- [ ] Ejecuté `php artisan view:cache` si cambié Blade.
- [ ] Ejecuté `npm run build` si cambié CSS o JavaScript.
- [ ] Revisé `storage/logs/laravel.log`.
- [ ] Probé el flujo completo en el navegador.
- [ ] Documenté cualquier cambio importante.

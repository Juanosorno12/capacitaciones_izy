# IzyCapacitaciones Corporativas

Aplicación web Laravel para gestionar solicitudes, participantes, capacitaciones, sesiones, calendario, usuarios, permisos e informes corporativos.

Este README es el punto de entrada al proyecto. Para una referencia por archivo y explicación de los flujos de negocio, consulta la [referencia completa del código](docs/CODEBASE_REFERENCE.md).

## Documentación

| Documento | Contenido |
| --- | --- |
| [Referencia del código](docs/CODEBASE_REFERENCE.md) | Responsabilidad de carpetas y archivos, módulos, flujos y convenciones de mantenimiento. |
| [Guía para desarrolladores](docs/DEVELOPER_GUIDE.md) | Cómo modificar pantallas, solicitudes, permisos, capacitaciones, reportes y estilos. |
| [Base de datos](docs/DATABASE.md) | Modelo entidad-relación, tablas, relaciones e índices. |
| [Diccionario de datos y rutas](docs/DATA_DICTIONARY_AND_ROUTES.md) | Campos de datos, endpoints, middleware y permisos. |
| [Despliegue y optimización](docs/DEPLOYMENT_AND_OPTIMIZATION.md) | Instrucciones de despliegue y recomendaciones operativas. |
| [Informe técnico para revisión y aprobación](docs/INFORME_TECNICO_APROBACION.md) | Resumen técnico, alcance, controles observables y lista de revisión para las direcciones. |

## Tecnologías y requisitos

- PHP 8.2 o superior y Composer.
- Laravel 10 u 11, según las dependencias fijadas en `composer.json`.
- MySQL/MariaDB (configuración local predeterminada); también se puede configurar otro motor compatible con Laravel.
- Node.js y npm para compilar los recursos del navegador.
- Apache/Nginx, Laragon o el servidor de desarrollo de Laravel.
- Tailwind CSS, Alpine.js, Chart.js y Vite en el frontend.
- `fflate` para leer las hojas de Excel de participantes y generar el libro Excel de reportes.

## Inicio rápido en Laragon (Windows)

1. Inicia Apache y MySQL/MariaDB en Laragon.
2. Crea una base de datos local, por ejemplo `capacitaciones_db`, con cotejamiento `utf8mb4_unicode_ci`.
3. Abre una terminal en la carpeta del proyecto.
4. Instala dependencias y prepara la configuración:

   ```powershell
   cd C:\laragon\www\capacitaciones_izyacademy
   composer install
   npm ci
   if (-not (Test-Path .env)) { Copy-Item .env.example .env }
   ```

5. Edita `.env` para que coincidan la URL y credenciales de tu entorno. La plantilla predeterminada usa MySQL local en `127.0.0.1:3306`, base `capacitaciones_db`, usuario `root` y contraseña vacía.
6. Genera la llave, prepara la base de datos y compila los recursos:

   ```powershell
   php artisan key:generate
   php artisan migrate --seed
   npm run build
   ```

7. Abre la aplicación en el host virtual que tengas configurado en Laragon o ejecuta:

   ```powershell
   php artisan serve
   ```

   El servidor de desarrollo de Laravel queda normalmente en `http://127.0.0.1:8000`.

Para desarrollo con recarga de recursos del navegador, ejecuta `npm run dev` en otra terminal mientras Laragon o `php artisan serve` atiende las peticiones. No mantengas un archivo `public/hot` apuntando a un servidor Vite detenido; puede impedir que se carguen los recursos compilados.

La importación y exportación de capacitaciones requiere la extensión `zip` de PHP. En Laragon, habilita `extension=zip` en el `php.ini` de la versión PHP activa y reinicia el servidor web.

### Base de datos y datos de demostración

`php artisan migrate --seed` aplica las migraciones pendientes y ejecuta `DatabaseSeeder`, que carga roles, permisos, categorías y datos de demostración. Las cuentas de demostración se definen en `database/seeders/UserSeeder.php`; sus credenciales son exclusivamente para desarrollo local.

> **Advertencia:** `php artisan migrate:fresh --seed` elimina todas las tablas y los datos de la base seleccionada antes de reconstruirlos. Úsalo únicamente en una base local descartable. No lo ejecutes en producción.

No copies `.env` al repositorio ni uses las cuentas/contraseñas de los seeders en producción. Configura las credenciales reales mediante el mecanismo seguro del entorno de despliegue.

## Qué hace la aplicación

- **Solicitudes:** líderes autorizados crean solicitudes con categoría, título, cliente, justificación y participantes. El ciclo de revisión admite pendiente, en revisión, aprobada o rechazada.
- **Participantes:** nombre, apellido, correo corporativo, correo personal opcional, celular y ciudad. En la creación de solicitudes se pueden añadir manualmente o cargar desde la primera hoja de un `.xlsx`.
- **Aprobación y programación:** aprobar una solicitud crea la capacitación y sus sesiones, asocia los participantes y actualiza la solicitud dentro de una transacción.
- **Capacitaciones:** catálogo con categorías, instructor, modalidad, sesiones, participantes, certificado y control de visibilidad externa.
- **Inventario de capacitaciones:** usuarios con permisos independientes pueden validar y cargar el Excel de 15 columnas, actualizar por `ID Sistema`, crear categorías nuevas y exportar el catálogo completo en el mismo formato.
- **Calendario:** calendario de sesiones en vistas diaria, semanal y mensual; la vista diaria muestra el horario de 06:00 a 23:00.
- **Reportes:** indicadores y gráficos generales, además de un informe de sesiones programadas ya finalizadas filtrable por mes, rango de días o rango de meses y exportable a `.xlsx`.
- **Usuarios y acceso:** roles, permisos RBAC, permisos directos por usuario, activación de cuentas y restricciones por permiso.

El informe de “capacitaciones impartidas” se basa en que la fecha y hora programadas de finalización ya hayan pasado. El sistema no registra asistencia real; por tanto, este criterio no confirma que la sesión se haya llevado a cabo.

## Arquitectura en una petición

```text
Navegador
  -> routes/web.php
  -> middleware de autenticación y permiso
  -> Form Request (autorización y validación, cuando aplica)
  -> Controller (coordina la petición)
  -> Service (reglas de negocio y transacciones)
  -> Model / Eloquent (datos y relaciones)
  -> Blade / JSON
  -> navegador
```

Las vistas no deben contener consultas de negocio. Para una operación que cambie varios registros relacionados, usa una transacción en el servicio correspondiente. Las rutas protegidas deben validar el permiso en servidor, aunque la interfaz oculte la acción.

## Estructura de primer nivel

```text
app/                 Controladores, middleware, validación, modelos y servicios
bootstrap/           Inicialización de Laravel
config/              Configuración de la aplicación y servicios
database/            Migraciones y seeders
docs/                Documentación funcional, técnica y operativa
public/              Front controller y archivos públicos
resources/css/       Estilos fuente
resources/js/        JavaScript fuente
resources/views/     Vistas Blade y componentes
routes/              Rutas web y de consola
storage/              Logs, caché, sesiones y archivos generados
```

Para entender la responsabilidad de cada archivo de estas carpetas, empieza por [docs/CODEBASE_REFERENCE.md](docs/CODEBASE_REFERENCE.md). Para ampliar un cambio concreto, sigue la [guía práctica de desarrollo](docs/DEVELOPER_GUIDE.md).

## Comandos útiles

```powershell
# Ver rutas y permisos/middleware asignados
php artisan route:list

# Consultar el estado de las migraciones
php artisan migrate:status

# Limpiar cachés de Laravel durante el desarrollo
php artisan optimize:clear

# Validar que Blade compila
php artisan view:cache

# Compilar CSS y JavaScript para producción
npm run build

# Revisar sintaxis de un archivo PHP
php -l app/Http/Controllers/TrainingController.php
```

La salida de `php artisan view:cache` es una caché de compilación; si después se requiere limpiar las vistas compiladas, ejecuta `php artisan view:clear`.

## Recomendaciones para contribuir

1. Lee primero el flujo y las reglas existentes en la guía del módulo correspondiente.
2. Añade columnas mediante una migración nueva; no reescribas migraciones ya aplicadas en ambientes compartidos.
3. Valida toda entrada del usuario con un `FormRequest` o `$request->validate()`.
4. Mantén el acceso a datos y las reglas de negocio en servicios/modelos; conserva los controladores como orquestadores.
5. Actualiza las pruebas disponibles y la documentación del módulo cuando cambie el comportamiento.
6. Ejecuta la validación apropiada: `php -l`, `php artisan route:list`, `php artisan view:cache` y/o `npm run build`.
7. Revisa `git diff` antes de confirmar el cambio y nunca incluyas `.env`, contraseñas ni datos locales.

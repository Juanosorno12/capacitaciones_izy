{{-- Listado del flujo de solicitudes de capacitación. --}}
{{-- Permite filtrar por texto, estado, categoría y valor agregado; admite vista de tarjetas o tabla. --}}
@extends('layouts.app')

@section('title', 'Solicitudes de Capacitación')
@section('header_title', 'Flujo de Solicitudes de Formación')

@section('content')
<div class="space-y-6" x-data="{ viewMode: '{{ $filters['view'] ?? 'grid' }}' }">

    <!-- Cabecera y Botón Nueva Solicitud -->
    <div class="sm:flex sm:items-center sm:justify-between">
        <div>
            <h2 class="text-xl font-bold text-[#1D3A6C]">Solicitudes de Capacitación</h2>
            <p class="text-xs text-gray-500 mt-1">Revisa y tramita las necesidades de formación postuladas por las distintas áreas de la empresa.</p>
        </div>
        @hasPermission('requests.create')
        <div class="mt-4 flex flex-wrap items-center gap-3 sm:mt-0">
            <div class="inline-flex rounded-lg border border-gray-200 bg-white p-1 shadow-sm">
                <button type="button" @click="viewMode = 'grid'"
                    :class="viewMode === 'grid' ? 'bg-[#1D3A6C] text-white' : 'text-gray-500 hover:text-gray-700'"
                    class="rounded-md px-2.5 py-1.5 text-xs font-semibold transition-colors">
                    Cuadrícula
                </button>
                <button type="button" @click="viewMode = 'table'"
                    :class="viewMode === 'table' ? 'bg-[#1D3A6C] text-white' : 'text-gray-500 hover:text-gray-700'"
                    class="rounded-md px-2.5 py-1.5 text-xs font-semibold transition-colors">
                    Lista
                </button>
            </div>
            <a href="{{ route('requests.create') }}" class="inline-flex items-center gap-2 px-4 py-2.5 bg-[#19A885] hover:bg-[#14866A] text-white text-xs font-bold rounded-lg shadow-sm transition-colors">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                </svg>
                Nueva Solicitud
            </a>
        </div>
        @endhasPermission
    </div>

    <!-- Filtros de Búsqueda -->
    <div class="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
        <form method="GET" action="{{ route('requests.index') }}" class="grid grid-cols-1 sm:grid-cols-12 gap-3">
            <input type="hidden" name="view" :value="viewMode">

            <!-- Buscador -->
            <div class="sm:col-span-5">
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                        </svg>
                    </div>
                    <label for="request-search" class="sr-only">Buscar solicitudes por título, cliente o justificación</label>
                    <input id="request-search" type="text" name="search" value="{{ request('search') }}"
                        class="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-gray-300 focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20"
                        placeholder="Buscar por título, cliente o justificación...">
                </div>
            </div>

            <!-- Filtro por Estado -->
            <div class="sm:col-span-3">
                <label for="request-status" class="sr-only">Filtrar por estado</label>
                <select id="request-status" name="status" class="w-full py-2 px-3 text-xs rounded-lg border border-gray-300 focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20">
                    <option value="">Todos los Estados</option>
                    <option value="pending" {{ request('status') === 'pending' ? 'selected' : '' }}>Pendiente</option>
                    <option value="reviewing" {{ request('status') === 'reviewing' ? 'selected' : '' }}>En Revisión</option>
                    <option value="approved" {{ request('status') === 'approved' ? 'selected' : '' }}>Aprobada</option>
                    <option value="rejected" {{ request('status') === 'rejected' ? 'selected' : '' }}>Rechazada</option>
                </select>
            </div>

            <!-- Filtro por Categoría -->
            <div class="sm:col-span-2">
                <label for="request-category" class="sr-only">Filtrar por categoría</label>
                <select id="request-category" name="category_id" class="w-full py-2 px-3 text-xs rounded-lg border border-gray-300 focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20">
                    <option value="">Categoría</option>
                    @foreach($categories as $cat)
                        <option value="{{ $cat->id }}" {{ request('category_id') == $cat->id ? 'selected' : '' }}>
                            {{ $cat->name }}
                        </option>
                    @endforeach
                </select>
            </div>

            <!-- Filtro por valor agregado -->
            <div class="sm:col-span-2">
                <label for="request-value-added" class="sr-only">Filtrar por valor agregado</label>
                <select id="request-value-added" name="value_added" class="w-full py-2 px-3 text-xs rounded-lg border border-gray-300 focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20">
                    <option value="all" {{ request('value_added', 'all') === 'all' ? 'selected' : '' }}>Valor agregado</option>
                    <option value="yes" {{ request('value_added') === 'yes' ? 'selected' : '' }}>Solo valor agregado</option>
                    <option value="no" {{ request('value_added') === 'no' ? 'selected' : '' }}>Sin valor agregado</option>
                </select>
            </div>

            <!-- Acciones -->
            <div class="sm:col-span-2 flex gap-2">
                <button type="submit" class="flex-1 py-2 px-3 bg-[#1D3A6C] hover:bg-[#13274A] text-white text-xs font-semibold rounded-lg transition-colors">
                    Filtrar
                </button>
                @if(request()->anyFilled(['search', 'status', 'category_id', 'value_added']))
                    <a href="{{ route('requests.index', ['view' => $filters['view'] ?? 'grid']) }}" class="py-2 px-3 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-semibold rounded-lg transition-colors">
                        Limpiar
                    </a>
                @endif
            </div>
        </form>
    </div>

    <!-- Solicitudes en cuadrícula -->
    <div x-show="viewMode === 'grid'" class="grid grid-cols-1 gap-4 lg:grid-cols-2 2xl:grid-cols-3">
        @forelse($requests as $req)
            <article class="flex min-w-0 flex-col rounded-xl border border-gray-200 bg-white p-4 shadow-sm transition-shadow hover:shadow-md sm:p-5">
                <div class="flex min-w-0 items-start justify-between gap-3">
                    <div class="min-w-0">
                        <a href="{{ route('requests.show', $req) }}" class="block break-words text-sm font-bold leading-snug text-[#1D3A6C] hover:underline">
                            {{ $req->title }}
                        </a>
                        <p class="mt-1 line-clamp-2 break-words text-xs leading-relaxed text-gray-500">{{ $req->justification }}</p>
                    </div>
                    @if($req->status === 'pending')
                        <span class="inline-flex shrink-0 items-center gap-1 rounded-full bg-[#FFF2EB] px-2.5 py-1 text-[11px] font-semibold text-[#FF5F00]">
                            <span class="h-1.5 w-1.5 rounded-full bg-[#FF5F00]"></span> Pendiente
                        </span>
                    @elseif($req->status === 'reviewing')
                        <span class="inline-flex shrink-0 items-center gap-1 rounded-full bg-[#EBF3FC] px-2.5 py-1 text-[11px] font-semibold text-[#0055AF]">
                            <span class="h-1.5 w-1.5 rounded-full bg-[#0055AF]"></span> En Revisión
                        </span>
                    @elseif($req->status === 'approved')
                        <span class="inline-flex shrink-0 items-center gap-1 rounded-full bg-[#E8F6F3] px-2.5 py-1 text-[11px] font-semibold text-[#19A885]">
                            <span class="h-1.5 w-1.5 rounded-full bg-[#19A885]"></span> Aprobada
                        </span>
                    @else
                        <span class="inline-flex shrink-0 items-center gap-1 rounded-full bg-red-50 px-2.5 py-1 text-[11px] font-semibold text-red-600">
                            <span class="h-1.5 w-1.5 rounded-full bg-red-600"></span> Rechazada
                        </span>
                    @endif
                </div>

                <div class="mt-4 grid grid-cols-1 gap-3 border-t border-gray-100 pt-4 text-xs sm:grid-cols-2">
                    <div class="min-w-0">
                        <p class="text-[10px] font-semibold uppercase tracking-wide text-gray-400">Categoría</p>
                        <p class="mt-1 break-words font-medium text-gray-800">{{ $req->category->name }}</p>
                    </div>
                    <div class="min-w-0">
                        <p class="text-[10px] font-semibold uppercase tracking-wide text-gray-400">Cliente</p>
                        <p class="mt-1 break-words font-medium text-gray-800">{{ $req->client_name ?: 'No registrado' }}</p>
                    </div>
                    <div class="min-w-0">
                        <p class="text-[10px] font-semibold uppercase tracking-wide text-gray-400">Valor agregado</p>
                        <p class="mt-1 font-medium text-gray-800">{{ $req->value_added ? 'Sí' : 'No' }}</p>
                    </div>
                    <div class="min-w-0">
                        <p class="text-[10px] font-semibold uppercase tracking-wide text-gray-400">Solicitante</p>
                        <p class="mt-1 break-words font-medium text-gray-800">{{ $req->requester->name }}</p>
                        <p class="break-words text-[11px] text-gray-500">{{ $req->requester->role?->name }}</p>
                    </div>
                    <div>
                        <p class="text-[10px] font-semibold uppercase tracking-wide text-gray-400">Participantes estimados</p>
                        <p class="mt-1 font-medium text-gray-800">{{ $req->estimated_participants }} pers.</p>
                    </div>
                    <div>
                        <p class="text-[10px] font-semibold uppercase tracking-wide text-gray-400">Fecha de solicitud</p>
                        <p class="mt-1 font-medium text-gray-800">{{ $req->created_at->format('d/m/Y') }}</p>
                    </div>
                </div>

                <a href="{{ route('requests.show', $req) }}" class="mt-4 inline-flex w-full items-center justify-center rounded-lg bg-[#EBF3FC] px-4 py-2.5 text-xs font-bold text-[#0055AF] transition-colors hover:bg-[#0055AF] hover:text-white">
                    Ver solicitud
                </a>
            </article>
        @empty
            <div class="col-span-full rounded-xl border border-gray-200 bg-white px-6 py-8 text-center text-xs text-gray-500">
                No se encontraron solicitudes registradas con los filtros indicados.
            </div>
        @endforelse
    </div>

    <!-- Solicitudes en lista -->
    <div x-show="viewMode === 'table'" class="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm" style="display: none;">
        <div class="overflow-x-auto">
            <table class="responsive-table min-w-full divide-y divide-gray-200 text-left text-xs">
                <thead class="bg-[#F8FAFC] text-gray-600">
                    <tr>
                        <th class="px-5 py-3 font-semibold">Solicitud</th>
                        <th class="px-5 py-3 font-semibold">Cliente</th>
                        <th class="px-5 py-3 font-semibold">Categoría</th>
                        <th class="px-5 py-3 font-semibold">Valor agregado</th>
                        <th class="px-5 py-3 font-semibold">Estado</th>
                        <th class="px-5 py-3 font-semibold">Fecha</th>
                        <th class="px-5 py-3 text-right font-semibold">Acción</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    @forelse($requests as $req)
                        <tr class="hover:bg-gray-50">
                            <td class="max-w-xs px-5 py-3">
                                <a href="{{ route('requests.show', $req) }}" class="font-semibold text-[#1D3A6C] hover:underline">{{ $req->title }}</a>
                                <p class="mt-1 line-clamp-1 text-gray-500">{{ $req->requester->name }}</p>
                            </td>
                            <td class="px-5 py-3 text-gray-600">{{ $req->client_name ?: 'No registrado' }}</td>
                            <td class="px-5 py-3 text-gray-600">{{ $req->category->name }}</td>
                            <td class="px-5 py-3 text-gray-600">{{ $req->value_added ? 'Sí' : 'No' }}</td>
                            <td class="px-5 py-3">
                                <span class="font-semibold {{ $req->status === 'approved' ? 'text-[#19A885]' : ($req->status === 'rejected' ? 'text-red-600' : 'text-[#0055AF]') }}">
                                    {{ match($req->status) {
                                        'pending' => 'Pendiente',
                                        'reviewing' => 'En Revisión',
                                        'approved' => 'Aprobada',
                                        default => 'Rechazada',
                                    } }}
                                </span>
                            </td>
                            <td class="whitespace-nowrap px-5 py-3 text-gray-600">{{ $req->created_at->format('d/m/Y') }}</td>
                            <td class="px-5 py-3 text-right">
                                <a href="{{ route('requests.show', $req) }}" class="font-semibold text-[#0055AF] hover:underline">Ver solicitud</a>
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="7" class="px-6 py-8 text-center text-gray-500">No se encontraron solicitudes registradas con los filtros indicados.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    @if($requests->hasPages())
        <div class="rounded-xl border border-gray-200 bg-white px-4 py-4 shadow-sm sm:px-6">
            {{ $requests->links() }}
        </div>
    @endif

</div>
@endsection

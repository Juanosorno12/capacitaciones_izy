{{-- Formulario para registrar una solicitud de capacitación. --}}
{{-- Incluye categoría, necesidad, participantes y validaciones dinámicas en el navegador. --}}
@extends('layouts.app')

@section('title', 'Nueva Solicitud de Capacitación')
@section('header_title', 'Postulación de Necesidad Formativa')

@section('content')
<div class="max-w-3xl mx-auto space-y-6">
    <div class="flex items-center justify-between">
        <div>
            <h2 class="text-xl font-bold text-[#1D3A6C]">Solicitar Capacitación para tu Área</h2>
            <p class="text-xs text-gray-500">Postula requerimientos técnicos para tu equipo de trabajo para análisis y programación.</p>
        </div>
        <a href="{{ route('requests.index') }}" class="text-xs font-semibold text-gray-600 hover:text-[#1D3A6C]">
            &larr; Volver a solicitudes
        </a>
    </div>

    <div class="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
        <form action="{{ route('requests.store') }}" method="POST" class="space-y-6">
            @csrf

            <!-- Categoría y capacitación -->
            <div class="grid grid-cols-1 gap-4">
                <div>
                    <label for="category_id" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Línea Técnica / Categoría *</label>
                    <select name="category_id" id="category_id" required
                        class="mt-1 w-full rounded-lg border-gray-300 shadow-sm focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 text-xs px-3 py-2 border">
                        <option value="">Selecciona la categoría correspondiente...</option>
                        @foreach($categories as $category)
                            <option value="{{ $category->id }}" {{ old('category_id', $selectedTraining?->category_id) == $category->id ? 'selected' : '' }}>
                                {{ $category->name }}
                            </option>
                        @endforeach
                    </select>
                    @error('category_id')
                        <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label for="training_id" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Título de la Formación Solicitada *</label>
                    <select name="training_id" id="training_id" required disabled
                        class="mt-1 w-full rounded-lg border-gray-300 shadow-sm focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 text-xs px-3 py-2 border disabled:bg-gray-50 disabled:text-gray-500">
                        <option value="">Primero selecciona una categoría...</option>
                    </select>
                    @error('training_id')
                        <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                    @enderror
                </div>
            </div>

            <div class="rounded-lg border border-[#D7E5F5] bg-[#F5F9FE] p-4">
                <label class="flex cursor-pointer items-start gap-3" for="value_added">
                    <input type="hidden" name="value_added" value="0">
                    <input type="checkbox" name="value_added" id="value_added" value="1"
                        @checked(old('value_added', false))
                        class="mt-0.5 rounded border-gray-300 text-[#0055AF] shadow-sm focus:ring-[#0055AF]/20">
                    <span>
                        <span class="block text-xs font-semibold text-gray-700">Valor agregado</span>
                        <span class="mt-1 block text-[11px] text-gray-500">Marca esta opción si la capacitación se entrega como beneficio adicional al cliente.</span>
                    </span>
                </label>
                @error('value_added')
                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="client_name" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Nombre del cliente *</label>
                <input type="text" name="client_name" id="client_name" required maxlength="255" value="{{ old('client_name') }}"
                    class="mt-1 w-full rounded-lg border-gray-300 shadow-sm focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 text-xs px-3 py-2.5 border">
                @error('client_name')
                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <!-- Cupos estimados -->
            <div>
                <label for="estimated_participants" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Participantes Estimados *</label>
                <input type="number" name="estimated_participants" id="estimated_participants" min="1" max="1000" required value="{{ old('estimated_participants', 10) }}"
                    class="mt-1 w-full rounded-lg border-gray-300 shadow-sm focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 text-xs px-3 py-2 border">
                @error('estimated_participants')
                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <!-- Justificación Técnica Corporativa -->
            <div>
                <label for="justification" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Justificación del Requerimiento *</label>
                <p class="text-[11px] text-gray-500 mb-1">Explica el impacto en el negocio, proyectos beneficiados o brecha técnica que se busca cerrar.</p>
                <textarea name="justification" id="justification" rows="4" required
                    class="mt-1 w-full rounded-lg border-gray-300 shadow-sm focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 text-xs p-3 border"
                    placeholder="El equipo de testing automatizado comenzará la fase de pruebas de estrés para el proyecto de banca digital, por lo que se requiere nivelar conocimientos en generación de métricas...">{{ old('justification') }}</textarea>
                @error('justification')
                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <section class="space-y-4 border-t border-gray-100 pt-5">
                <div>
                    <h3 class="text-sm font-bold text-[#1D3A6C]">Participantes</h3>
                    <p class="text-[11px] text-gray-500">Completa los datos de una persona y agrégala a la lista, o impórtalos desde Excel.</p>
                </div>
                @error('participants')
                    <p class="text-xs text-red-600">{{ $message }}</p>
                @enderror

                <div class="rounded-lg border border-dashed border-gray-300 bg-gray-50 p-4">
                    <label for="participants-excel" class="block text-xs font-semibold text-gray-700">Importar participantes desde Excel</label>
                    <p class="mt-1 text-[11px] text-gray-500">Selecciona un archivo .xlsx. La primera fila debe contener los encabezados: Nombre, Apellido, Correo corporativo, Correo personal (opcional), Celular y Ciudad.</p>
                    <div class="mt-3 flex flex-wrap items-center gap-3">
                        <button type="button" id="download-participants-template"
                            class="rounded-lg border border-[#0055AF] px-4 py-2 text-xs font-semibold text-[#0055AF] hover:bg-[#EBF3FC]">
                            Descargar plantilla base
                        </button>
                        <input type="file" id="participants-excel" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            class="block max-w-full text-xs text-gray-600 file:mr-3 file:rounded-lg file:border-0 file:bg-[#0055AF] file:px-4 file:py-2 file:text-xs file:font-semibold file:text-white hover:file:bg-[#003E80]">
                        <span id="participants-import-status" class="text-xs text-gray-600" role="status" aria-live="polite"></span>
                    </div>
                </div>

                <div class="rounded-lg border border-gray-200 bg-gray-50 p-4">
                    <div class="grid grid-cols-1 gap-3 sm:grid-cols-2">
                        <div>
                            <label for="participant-first-name" class="block text-xs font-medium text-gray-700">Nombre *</label>
                            <input type="text" id="participant-first-name" maxlength="100"
                                class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-xs focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20">
                        </div>
                        <div>
                            <label for="participant-last-name" class="block text-xs font-medium text-gray-700">Apellido *</label>
                            <input type="text" id="participant-last-name" maxlength="150"
                                class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-xs focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20">
                        </div>
                        <div>
                            <label for="participant-email" class="block text-xs font-medium text-gray-700">Correo corporativo *</label>
                            <input type="text" id="participant-email" inputmode="email" maxlength="255"
                                class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-xs focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20">
                        </div>
                        <div>
                            <label for="participant-personal-email" class="block text-xs font-medium text-gray-700">Correo personal <span class="font-normal text-gray-500">(opcional)</span></label>
                            <input type="text" id="participant-personal-email" inputmode="email" maxlength="255"
                                class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-xs focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20">
                        </div>
                        <div>
                            <label for="participant-phone" class="block text-xs font-medium text-gray-700">Celular *</label>
                            <input type="tel" id="participant-phone" maxlength="30"
                                class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-xs focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20">
                        </div>
                        <div>
                            <label for="participant-city" class="block text-xs font-medium text-gray-700">Ciudad *</label>
                            <input type="text" id="participant-city" maxlength="100"
                                class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-xs focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20">
                        </div>
                    </div>
                    <div class="mt-4 flex justify-end gap-2">
                        <button type="button" id="cancel-participant-edit" class="hidden rounded-lg px-3 py-2 text-xs font-semibold text-gray-600 hover:bg-gray-200">
                            Cancelar edición
                        </button>
                        <button type="button" id="save-participant" class="rounded-lg bg-[#0055AF] px-4 py-2 text-xs font-semibold text-white hover:bg-[#003E80]">
                            Agregar participante
                        </button>
                    </div>
                </div>

                <div>
                    <h4 class="mb-2 text-xs font-semibold text-gray-700">Participantes agregados</h4>
                    <div id="participants-list" class="overflow-x-auto rounded-lg border border-gray-200">
                        <table class="responsive-table min-w-full divide-y divide-gray-200 text-left text-xs">
                            <thead class="bg-gray-50 text-gray-600">
                                <tr>
                                    <th class="px-4 py-3 font-semibold">Nombre</th>
                                    <th class="px-4 py-3 font-semibold">Correo corporativo</th>
                                    <th class="px-4 py-3 font-semibold">Correo personal</th>
                                    <th class="px-4 py-3 font-semibold">Celular</th>
                                    <th class="px-4 py-3 font-semibold">Ciudad</th>
                                    <th class="px-4 py-3 text-right font-semibold">Acciones</th>
                                </tr>
                            </thead>
                            <tbody id="participants-list-body" class="divide-y divide-gray-100">
                                <tr id="participants-empty-row">
                                    <td colspan="6" class="px-4 py-5 text-center text-gray-500">Aún no has agregado participantes.</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <p id="participants-client-error" class="mt-2 hidden text-xs text-red-600" role="alert"></p>
                </div>
            </section>

            <!-- Botones -->
            <div class="flex items-center justify-end gap-3 pt-4 border-t border-gray-100">
                <a href="{{ route('requests.index') }}" class="px-4 py-2 text-xs font-semibold text-gray-600 hover:text-gray-800">
                    Cancelar
                </a>
                <button type="submit" class="px-6 py-2.5 bg-[#19A885] hover:bg-[#14866A] text-white text-xs font-bold rounded-lg shadow-sm transition-colors">
                    Enviar Solicitud a Revisión
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const body = document.getElementById('participants-list-body');
        const form = document.querySelector('#participants-list').closest('form');
        const categorySelect = document.getElementById('category_id');
        const trainingSelect = document.getElementById('training_id');
        const trainingsByCategory = @json($trainingsByCategory);
        const oldTrainingId = @json(old('training_id', $selectedTraining?->id));
        const firstNameInput = document.getElementById('participant-first-name');
        const lastNameInput = document.getElementById('participant-last-name');
        const emailInput = document.getElementById('participant-email');
        const personalEmailInput = document.getElementById('participant-personal-email');
        const validEmailFormat = /^(?:[A-Z0-9!#$%&'*+\/=?^_`{|}~-]|ñ|Ñ)+(?:\.(?:[A-Z0-9!#$%&'*+\/=?^_`{|}~-]|ñ|Ñ)+)*@(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,}(?:\.[A-Z]{2,})*$/iu;
        const phoneInput = document.getElementById('participant-phone');
        const cityInput = document.getElementById('participant-city');
        const saveButton = document.getElementById('save-participant');
        const cancelButton = document.getElementById('cancel-participant-edit');
        const errorMessage = document.getElementById('participants-client-error');
        const excelInput = document.getElementById('participants-excel');
        const templateButton = document.getElementById('download-participants-template');
        const importStatus = document.getElementById('participants-import-status');
        const oldParticipants = @json(array_values(old('participants', [])));

        templateButton.addEventListener('click', () => {
            if (typeof window.createParticipantTemplate !== 'function') {
                importStatus.textContent = 'No está disponible la plantilla. Recarga la página e intenta nuevamente.';
                return;
            }

            const file = new Blob([window.createParticipantTemplate()], {
                type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            });
            const url = URL.createObjectURL(file);
            const link = document.createElement('a');
            link.href = url;
            link.download = 'plantilla_participantes_capacitacion.xlsx';
            document.body.append(link);
            link.click();
            link.remove();
            window.setTimeout(() => URL.revokeObjectURL(url), 1000);
        });
        const participants = oldParticipants
            .filter((participant) => participant && typeof participant === 'object' && !Array.isArray(participant))
            .map((participant) => ({
                first_name: String(participant.first_name || ''),
                last_name: String(participant.last_name || ''),
                email: String(participant.email || ''),
                personal_email: String(participant.personal_email || ''),
                phone: String(participant.phone || ''),
                city: String(participant.city || ''),
            }));
        let editingIndex = null;

        // Filtra las capacitaciones disponibles según la categoría seleccionada.
        const updateTrainingOptions = (selectedTrainingId = '') => {
            trainingSelect.replaceChildren();
            const placeholder = document.createElement('option');
            const trainings = trainingsByCategory[categorySelect.value] || [];

            if (!categorySelect.value) {
                placeholder.value = '';
                placeholder.textContent = 'Primero selecciona una categoría...';
                trainingSelect.disabled = true;
            } else if (trainings.length === 0) {
                placeholder.value = '';
                placeholder.textContent = 'No hay capacitaciones disponibles en esta categoría.';
                trainingSelect.disabled = true;
            } else {
                placeholder.value = '';
                placeholder.textContent = 'Selecciona una capacitación...';
                trainingSelect.disabled = false;
            }

            trainingSelect.appendChild(placeholder);

            trainings.forEach((training) => {
                const option = document.createElement('option');
                option.value = String(training.id);
                option.textContent = training.title;
                option.selected = String(training.id) === String(selectedTrainingId);
                trainingSelect.appendChild(option);
            });
        };

        categorySelect.addEventListener('change', () => updateTrainingOptions());
        updateTrainingOptions(oldTrainingId);

        const fields = {
            first_name: firstNameInput,
            last_name: lastNameInput,
            email: emailInput,
            personal_email: personalEmailInput,
            phone: phoneInput,
            city: cityInput,
        };

        // Oculta el mensaje de error de validación del editor de participantes.
        const clearError = () => {
            errorMessage.textContent = '';
            errorMessage.classList.add('hidden');
        };

        // Muestra un error de validación generado en el navegador.
        const showError = (message) => {
            errorMessage.textContent = message;
            errorMessage.classList.remove('hidden');
        };

        // Redibuja la tabla y sincroniza los participantes con campos ocultos.
        const renderParticipants = () => {
            body.replaceChildren();

            if (participants.length === 0) {
                const emptyRow = document.createElement('tr');
                const emptyCell = document.createElement('td');
                emptyCell.colSpan = 6;
                emptyCell.className = 'px-4 py-5 text-center text-gray-500';
                emptyCell.textContent = 'Aún no has agregado participantes.';
                emptyRow.appendChild(emptyCell);
                body.appendChild(emptyRow);
                return;
            }

            participants.forEach((participant, index) => {
                const row = document.createElement('tr');
                const fullName = document.createElement('td');
                fullName.className = 'px-4 py-3 font-medium text-gray-900';
                fullName.textContent = `${participant.first_name} ${participant.last_name}`;

                const values = ['email', 'personal_email', 'phone', 'city'].map((field) => {
                    const cell = document.createElement('td');
                    cell.className = 'px-4 py-3 text-gray-600';
                    cell.textContent = participant[field] || '—';
                    return cell;
                });

                const actions = document.createElement('td');
                actions.className = 'px-4 py-3 text-right whitespace-nowrap';
                const editButton = document.createElement('button');
                editButton.type = 'button';
                editButton.className = 'mr-3 font-semibold text-[#0055AF] hover:underline';
                editButton.textContent = 'Modificar';
                editButton.addEventListener('click', () => editParticipant(index));

                const removeButton = document.createElement('button');
                removeButton.type = 'button';
                removeButton.className = 'font-semibold text-red-600 hover:underline';
                removeButton.textContent = 'Eliminar';
                removeButton.addEventListener('click', () => removeParticipant(index));
                actions.append(editButton, removeButton);

                row.append(fullName, ...values, actions);
                Object.keys(fields).forEach((field) => {
                    const hiddenInput = document.createElement('input');
                    hiddenInput.type = 'hidden';
                    hiddenInput.name = `participants[${index}][${field}]`;
                    hiddenInput.value = participant[field] || '';
                    actions.appendChild(hiddenInput);
                });
                body.appendChild(row);
            });
        };

        // Limpia el formulario de participante y vuelve al modo de creación.
        const resetEditor = () => {
            Object.values(fields).forEach((input) => {
                input.value = '';
                input.setCustomValidity('');
            });
            editingIndex = null;
            saveButton.textContent = 'Agregar participante';
            cancelButton.classList.add('hidden');
            clearError();
        };

        // Carga un participante existente en el formulario para modificarlo.
        const editParticipant = (index) => {
            const participant = participants[index];
            Object.keys(fields).forEach((field) => {
                fields[field].value = participant[field] || '';
            });
            editingIndex = index;
            saveButton.textContent = 'Guardar cambios';
            cancelButton.classList.remove('hidden');
            firstNameInput.focus();
            clearError();
        };

        // Elimina un participante y corrige el índice que se está editando.
        const removeParticipant = (index) => {
            participants.splice(index, 1);
            if (editingIndex === index) {
                resetEditor();
            } else if (editingIndex !== null && editingIndex > index) {
                editingIndex -= 1;
            }
            renderParticipants();
            clearError();
        };

        // Normaliza los valores de texto antes de guardarlos o validarlos.
        const normalizeParticipant = (participant) => Object.fromEntries(
            Object.keys(fields).map((field) => [field, String(participant[field] || '').trim()])
        );

        // Valida campos obligatorios, longitudes y formatos de correo.
        const validateParticipant = (participant) => {
            if (!participant.first_name || !participant.last_name || !participant.email || !participant.phone || !participant.city) {
                return 'Nombre, apellido, correo corporativo, celular y ciudad son obligatorios.';
            }
            if (participant.first_name.length > 100 || participant.last_name.length > 150
                || participant.email.length > 255 || participant.personal_email.length > 255
                || participant.phone.length > 30 || participant.city.length > 100) {
                return 'Uno o más datos del participante superan la longitud máxima permitida.';
            }
            if (!validEmailFormat.test(participant.email)) {
                return 'Ingresa un correo corporativo válido.';
            }
            if (participant.personal_email && !validEmailFormat.test(participant.personal_email)) {
                return 'Ingresa un correo personal válido o déjalo vacío.';
            }
            return '';
        };

        saveButton.addEventListener('click', () => {
            const participant = normalizeParticipant(Object.fromEntries(
                Object.entries(fields).map(([field, input]) => [field, input.value])
            ));
            const validationError = validateParticipant(participant);
            if (validationError) {
                showError(validationError);
                const missingField = Object.keys(fields).find((field) =>
                    field !== 'personal_email' && !participant[field]
                );
                if (missingField) {
                    fields[missingField].focus();
                } else {
                    (participant.email && !validEmailFormat.test(participant.email) ? emailInput : personalEmailInput).focus();
                }
                return;
            }

            const duplicateIndex = participants.findIndex((item) =>
                item.email.toLowerCase() === participant.email.toLowerCase()
            );
            if (duplicateIndex !== -1 && duplicateIndex !== editingIndex) {
                showError('Ya agregaste un participante con ese correo corporativo.');
                emailInput.focus();
                return;
            }
            if (editingIndex === null && participants.length >= 1000) {
                showError('No puedes agregar más de 1000 participantes a una solicitud.');
                return;
            }

            if (editingIndex === null) {
                participants.push(participant);
            } else {
                participants[editingIndex] = participant;
            }
            resetEditor();
            renderParticipants();
        });

        cancelButton.addEventListener('click', resetEditor);

        excelInput.addEventListener('change', async () => {
            const file = excelInput.files[0];
            if (!file) {
                return;
            }
            if (editingIndex !== null) {
                showError('Guarda o cancela la edición del participante antes de importar desde Excel.');
                excelInput.value = '';
                return;
            }

            clearError();
            importStatus.textContent = 'Validando archivo…';

            try {
                if (typeof window.readParticipantSpreadsheet !== 'function') {
                    throw new Error('No está disponible el lector de archivos Excel. Recarga la página e intenta nuevamente.');
                }

                const imported = (await window.readParticipantSpreadsheet(file)).map(normalizeParticipant);
                const emailSet = new Set(participants.map((participant) => participant.email.toLowerCase()));
                for (const participant of imported) {
                    const validationError = validateParticipant(participant);
                    if (validationError) {
                        throw new Error(validationError);
                    }
                    const normalizedEmail = participant.email.toLowerCase();
                    if (emailSet.has(normalizedEmail)) {
                        throw new Error(`El correo corporativo ${participant.email} está repetido en la lista o en el archivo.`);
                    }
                    emailSet.add(normalizedEmail);
                }
                if (participants.length + imported.length > 1000) {
                    throw new Error('No puedes agregar más de 1000 participantes a una solicitud.');
                }

                participants.push(...imported);
                renderParticipants();
                clearError();
                importStatus.textContent = `Se importaron ${imported.length} participantes.`;
            } catch (error) {
                importStatus.textContent = '';
                showError(error instanceof Error ? error.message : 'No fue posible leer el archivo de Excel.');
            } finally {
                excelInput.value = '';
            }
        });

        form.addEventListener('submit', (event) => {
            if (participants.length === 0) {
                event.preventDefault();
                showError('Agrega al menos un participante antes de enviar la solicitud.');
                firstNameInput.focus();
            }
        });

        Object.values(fields).forEach((input) => {
            input.addEventListener('input', () => {
                input.setCustomValidity('');
                clearError();
            });
        });
        renderParticipants();
    });
</script>
@endsection

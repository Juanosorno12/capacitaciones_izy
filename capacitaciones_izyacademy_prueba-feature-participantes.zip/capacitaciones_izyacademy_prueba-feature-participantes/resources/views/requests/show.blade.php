{{-- Detalle y seguimiento de una solicitud de capacitación. --}}
{{-- Muestra el estado, datos de la solicitud y acciones de revisión, aprobación o rechazo. --}}
@extends('layouts.app')

@section('title', 'Detalle de Solicitud')
@section('header_title', 'Seguimiento de Solicitud de Capacitación')

@section('content')
<div class="max-w-4xl mx-auto space-y-6" x-data="{
    approveModalOpen: @json(old('action') === 'approve' && $errors->any()),
    rejectModalOpen: @json(old('action') === 'reject' && $errors->any())
}">

    <!-- Cabecera de Navegación -->
    <div class="flex flex-col items-start gap-3 sm:flex-row sm:items-center sm:justify-between">
        <a href="{{ route('requests.index') }}" class="text-xs font-semibold text-[#0055AF] hover:underline flex items-center gap-1">
            &larr; Volver a la lista de solicitudes
        </a>

        <!-- Estado Badge -->
        <div>
            @if($trainingRequest->status === 'pending')
                <span class="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-[#FFF2EB] text-[#FF5F00] border border-[#FF5F00]/20">
                    Pendiente de Evaluación
                </span>
            @elseif($trainingRequest->status === 'reviewing')
                <span class="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-[#EBF3FC] text-[#0055AF] border border-[#0055AF]/20">
                    En Revisión Técnica
                </span>
            @elseif($trainingRequest->status === 'approved')
                <span class="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-[#E8F6F3] text-[#19A885] border border-[#19A885]/20">
                    Aprobada y Programada
                </span>
            @else
                <span class="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-red-50 text-red-600 border border-red-200">
                    Rechazada
                </span>
            @endif
        </div>
    </div>

    <!-- Contenido de la Solicitud -->
    <div class="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
        <div class="p-6 sm:p-8 border-b border-gray-100 bg-[#F8FAFC]">
            <span class="inline-block px-3 py-1 rounded-full text-xs font-semibold bg-[#EBF3FC] text-[#0055AF] mb-2">
                {{ $trainingRequest->category->name }}
            </span>
            <h1 class="text-xl sm:text-2xl font-bold text-[#1D3A6C]">
                {{ $trainingRequest->title }}
            </h1>
            <div class="mt-2 flex flex-wrap items-center gap-4 text-xs text-gray-500">
                <span>Cliente: <strong class="text-gray-900">{{ $trainingRequest->client_name ?: 'No registrado' }}</strong></span>
                <span>&bull;</span>
                <span>Valor agregado: <strong class="text-gray-900">{{ $trainingRequest->value_added ? 'Sí' : 'No' }}</strong></span>
                <span>&bull;</span>
                <span>Postulada por: <strong class="text-gray-900">{{ $trainingRequest->requester->name }}</strong> ({{ $trainingRequest->requester->role?->name }})</span>
                <span>&bull;</span>
                <span>Participantes estimados: <strong class="text-gray-900">{{ $trainingRequest->estimated_participants }} personas</strong></span>
                <span>&bull;</span>
                <span>Fecha: {{ $trainingRequest->created_at->format('d/m/Y H:i') }}</span>
            </div>
        </div>

        <div class="p-6 sm:p-8 space-y-6">
            <!-- Justificación -->
            <div>
                <h3 class="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">Justificación Corporativa</h3>
                <div class="bg-gray-50 p-4 rounded-xl border border-gray-200 text-xs sm:text-sm text-gray-800 leading-relaxed whitespace-pre-line">
                    {{ $trainingRequest->justification }}
                </div>
            </div>

            <div>
                <h3 class="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2">
                    Participantes registrados ({{ $trainingRequest->participants->count() }})
                </h3>
                <div class="overflow-x-auto rounded-xl border border-gray-200">
                    <table class="responsive-table min-w-full divide-y divide-gray-200 text-left text-xs">
                        <thead class="bg-gray-50 text-gray-600">
                            <tr>
                                <th class="px-4 py-3">Nombre</th>
                                <th class="px-4 py-3">Correo corporativo</th>
                                <th class="px-4 py-3">Correo personal</th>
                                <th class="px-4 py-3">Celular</th>
                                <th class="px-4 py-3">Ciudad</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            @forelse($trainingRequest->participants as $participant)
                                <tr>
                                    <td class="px-4 py-3 font-medium text-gray-900">{{ $participant->first_name }} {{ $participant->last_name }}</td>
                                    <td class="px-4 py-3 text-gray-600">{{ $participant->email }}</td>
                                    <td class="px-4 py-3 text-gray-600">{{ $participant->personal_email ?: '—' }}</td>
                                    <td class="px-4 py-3 text-gray-600">{{ $participant->phone ?: '—' }}</td>
                                    <td class="px-4 py-3 text-gray-600">{{ $participant->city ?: '—' }}</td>
                                </tr>
                            @empty
                                <tr><td colspan="5" class="px-4 py-4 text-center text-gray-500">No hay participantes registrados.</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Estado de Aprobación o Rechazo -->
            @if($trainingRequest->status === 'approved' && $trainingRequest->approvedTraining)
                <div class="p-4 rounded-xl bg-[#E8F6F3] border border-[#19A885]/30 flex items-center justify-between">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-full bg-[#19A885] text-white flex items-center justify-center font-bold">
                            ✓
                        </div>
                        <div>
                            <p class="text-xs font-bold text-[#14866A]">Capacitación Oficial Programada</p>
                            <p class="text-xs text-gray-600">Esta solicitud dio origen a la capacitación: <strong>{{ $trainingRequest->approvedTraining->title }}</strong></p>
                        </div>
                    </div>
                    <a href="{{ route('trainings.show', $trainingRequest->approvedTraining) }}" class="px-3 py-1.5 bg-[#19A885] hover:bg-[#14866A] text-white text-xs font-bold rounded-lg transition-colors">
                        Ver Capacitación
                    </a>
                </div>
            @endif

            @if($trainingRequest->status === 'rejected')
                <div class="p-4 rounded-xl bg-red-50 border border-red-200">
                    <p class="text-xs font-bold text-red-800">Motivo del Rechazo:</p>
                    <p class="text-xs text-red-700 mt-1 leading-relaxed">{{ $trainingRequest->rejection_reason ?? 'No especificado.' }}</p>
                </div>
            @endif
        </div>

        <!-- PANEL DE ACCIONES DE GESTIÓN PARA ADMINISTRADORES -->
        @hasPermission('requests.approve')
        @if($trainingRequest->status === 'pending' || $trainingRequest->status === 'reviewing')
            <div class="p-6 bg-gray-50 border-t border-gray-200 flex flex-wrap items-center justify-between gap-3">
                <span class="text-xs font-medium text-gray-600">Acciones de aprobación y conversión para Administradores:</span>

                <div class="flex items-center gap-2">
                    @if($trainingRequest->status === 'pending')
                        <form action="{{ route('requests.review', $trainingRequest) }}" method="POST">
                            @csrf
                            <input type="hidden" name="action" value="review">
                            <button type="submit" class="px-3.5 py-2 bg-white border border-gray-300 hover:bg-gray-100 text-gray-700 text-xs font-bold rounded-lg transition-colors">
                                Poner en Revisión
                            </button>
                        </form>
                    @endif

                    <button type="button" @click="rejectModalOpen = true" class="px-3.5 py-2 bg-red-50 hover:bg-red-100 text-red-600 text-xs font-bold rounded-lg transition-colors border border-red-200">
                        Rechazar Solicitud
                    </button>

                    <button type="button" @click="approveModalOpen = true" class="px-4 py-2 bg-[#19A885] hover:bg-[#14866A] text-white text-xs font-bold rounded-lg transition-colors shadow-sm flex items-center gap-1.5">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                        </svg>
                        Aprobar y Programar
                    </button>
                </div>
            </div>
        @endif
        @endhasPermission
    </div>

    <!-- MODAL DE APROBACIÓN Y CONVERSIÓN INSTANTÁNEA -->
    <div x-show="approveModalOpen" class="fixed inset-0 z-50 overflow-y-auto" style="display: none;"
        x-transition:enter="transition ease-out duration-200"
        x-transition:enter-start="opacity-0"
        x-transition:enter-end="opacity-100"
        x-transition:leave="transition ease-in duration-150"
        x-transition:leave-start="opacity-100"
        x-transition:leave-end="opacity-0">
        
        <div class="fixed inset-0 bg-black/60 backdrop-blur-sm" @click="approveModalOpen = false"></div>

        <div class="flex min-h-full items-center justify-center p-4">
            <div class="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto bg-white rounded-2xl shadow-2xl p-6">
                <div class="flex items-center justify-between pb-4 border-b border-gray-100">
                    <h3 class="font-bold text-[#1D3A6C] text-base">Aprobar y Convertir a Capacitación Oficial</h3>
                    <button @click="approveModalOpen = false" class="text-gray-400 hover:text-gray-600 p-1">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                        </svg>
                    </button>
                </div>

                <form action="{{ route('requests.review', $trainingRequest) }}" method="POST" class="mt-4 space-y-4">
                    @csrf
                    <input type="hidden" name="action" value="approve">

                    <div>
                        <label for="review-title" class="block text-xs font-semibold text-gray-700 uppercase">Título de la Capacitación</label>
                        <input id="review-title" type="text" name="title" value="{{ old('title', $trainingRequest->title) }}" required
                            class="mt-1 w-full rounded-lg border-gray-300 text-xs px-3 py-2 border focus:border-[#0055AF]">
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label for="review-expert-user" class="block text-xs font-semibold text-gray-700 uppercase">Facilitador / Experto *</label>
                            <select id="review-expert-user" name="expert_user_id" required
                                class="mt-1 w-full rounded-lg border-gray-300 text-xs px-3 py-2 border focus:border-[#0055AF]">
                                <option value="">Selecciona un usuario experto</option>
                                @foreach($experts as $expert)
                                    <option value="{{ $expert->id }}" {{ old('expert_user_id') == $expert->id ? 'selected' : '' }}>
                                        {{ $expert->name }}
                                    </option>
                                @endforeach
                            </select>
                            @if($experts->isEmpty())
                                <p class="mt-1 text-xs text-amber-700">Primero crea o activa el usuario experto y carga su foto de perfil.</p>
                            @endif
                            @error('expert_user_id')<p class="mt-1 text-xs text-red-600">{{ $message }}</p>@enderror
                        </div>
                        <div>
                            <label for="review-duration-hours" class="block text-xs font-semibold text-gray-700 uppercase">Duración total (Horas académicas) *</label>
                            <input id="review-duration-hours" type="number" name="duration_hours" min="1" max="500" value="20" required
                                class="mt-1 w-full rounded-lg border-gray-300 text-xs px-3 py-2 border focus:border-[#0055AF]">
                        </div>
                    </div>

                    <x-training-session-fields />

                    <div>
                        <label for="modal_modality" class="block text-xs font-semibold text-gray-700 uppercase">Modalidad *</label>
                        <select name="modality" id="modal_modality" required
                            class="mt-1 w-full rounded-lg border-gray-300 text-xs px-3 py-2 border focus:border-[#0055AF]">
                            <option value="">Selecciona la modalidad</option>
                            <option value="virtual" {{ old('modality') === 'virtual' ? 'selected' : '' }}>Virtual</option>
                            <option value="presencial" {{ old('modality') === 'presencial' ? 'selected' : '' }}>Presencial</option>
                        </select>
                        @error('modality')<p class="mt-1 text-xs text-red-600">{{ $message }}</p>@enderror
                    </div>

                    <div class="mt-6 flex items-center justify-end gap-3 pt-4 border-t border-gray-100">
                        <button type="button" @click="approveModalOpen = false" class="px-4 py-2 text-xs font-semibold text-gray-600">
                            Cancelar
                        </button>
                        <button type="submit" class="px-5 py-2.5 bg-[#19A885] hover:bg-[#14866A] text-white text-xs font-bold rounded-lg shadow-sm">
                            Confirmar Aprobación y Publicar
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- MODAL DE RECHAZO CON MOTIVO OBLIGATORIO -->
    <div x-show="rejectModalOpen" class="fixed inset-0 z-50 overflow-y-auto" style="display: none;">
        <div class="fixed inset-0 bg-black/60 backdrop-blur-sm" @click="rejectModalOpen = false"></div>
        <div class="flex min-h-full items-center justify-center p-4">
            <div class="relative w-full max-w-md bg-white rounded-2xl shadow-2xl p-6 overflow-hidden">
                <h3 class="font-bold text-red-600 text-base">Rechazar Solicitud de Capacitación</h3>
                <p class="text-xs text-gray-500 mt-1">Ingresa el motivo corporativo del rechazo para notificar al líder solicitante.</p>

                <form action="{{ route('requests.review', $trainingRequest) }}" method="POST" class="mt-4 space-y-4">
                    @csrf
                    <input type="hidden" name="action" value="reject">

                    <div>
                        <label for="review-rejection-reason" class="block text-xs font-semibold text-gray-700 uppercase">Motivo del Rechazo *</label>
                        <textarea id="review-rejection-reason" name="rejection_reason" rows="3" required placeholder="Detalla la razón del rechazo o sugerencias..."
                            class="mt-1 w-full rounded-lg border-gray-300 text-xs p-2.5 border focus:border-red-500"></textarea>
                    </div>

                    <div class="flex items-center justify-end gap-3 pt-4 border-t border-gray-100">
                        <button type="button" @click="rejectModalOpen = false" class="px-4 py-2 text-xs font-semibold text-gray-600">
                            Cancelar
                        </button>
                        <button type="submit" class="px-5 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-lg shadow-sm">
                            Confirmar Rechazo
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

</div>
@endsection

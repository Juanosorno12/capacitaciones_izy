{{-- Calendario de sesiones de capacitación. --}}
{{-- Permite consultar las sesiones en vista diaria, semanal o mensual. --}}
@extends('layouts.app')

@section('title', 'Calendario')
@section('header_title', 'Calendario de Capacitaciones')

@section('content')
@php
    $monthNames = [
        1 => 'Enero', 2 => 'Febrero', 3 => 'Marzo', 4 => 'Abril',
        5 => 'Mayo', 6 => 'Junio', 7 => 'Julio', 8 => 'Agosto',
        9 => 'Septiembre', 10 => 'Octubre', 11 => 'Noviembre', 12 => 'Diciembre',
    ];
    $weekDays = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
    $heading = match ($view) {
        'day' => $weekDays[$selectedDate->dayOfWeekIso - 1].' '.$selectedDate->format('d').' de '.$monthNames[(int) $selectedDate->format('n')].' de '.$selectedDate->format('Y'),
        'week' => 'Semana del '.$days->first()->format('d/m/Y').' al '.$days->last()->format('d/m/Y'),
        default => $monthNames[(int) $selectedDate->format('n')].' '.$selectedDate->format('Y'),
    };
@endphp

<div class="space-y-6">
    <div class="flex flex-wrap items-start justify-between gap-4">
        <div>
            <h2 class="text-xl font-bold text-[#1D3A6C]">Calendario de Capacitaciones</h2>
            <p class="mt-1 text-xs text-gray-500">Consulta las sesiones programadas por día, semana o mes.</p>
        </div>
        <a href="{{ route('trainings.create') }}" class="rounded-lg bg-[#19A885] px-4 py-2.5 text-xs font-bold text-white shadow-sm hover:bg-[#14866A]">
            Programar capacitación
        </a>
    </div>

    <section @class([
        'rounded-xl border border-gray-200 bg-white shadow-sm',
        'overflow-hidden' => $view !== 'day',
    ])>
        <div @class([
            'flex flex-wrap items-center justify-between gap-4 border-b border-gray-100 p-4',
            'sticky top-16 z-10 bg-white shadow-sm' => $view === 'day',
        ])>
            <div class="flex items-center gap-2">
                <a href="{{ route('calendar.index', ['view' => $view, 'date' => $previousDate->toDateString()]) }}"
                    aria-label="Periodo anterior" class="rounded-lg border border-gray-200 px-3 py-2 text-sm text-gray-700 hover:bg-gray-50">&larr;</a>
                <a href="{{ route('calendar.index', ['view' => $view, 'date' => now(config('app.timezone'))->toDateString()]) }}"
                    class="rounded-lg border border-gray-200 px-3 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50">Hoy</a>
                <a href="{{ route('calendar.index', ['view' => $view, 'date' => $nextDate->toDateString()]) }}"
                    aria-label="Periodo siguiente" class="rounded-lg border border-gray-200 px-3 py-2 text-sm text-gray-700 hover:bg-gray-50">&rarr;</a>
            </div>

            <h3 class="text-base font-bold text-[#1D3A6C]">{{ $heading }}</h3>

            <nav aria-label="Vista del calendario" class="flex rounded-lg bg-gray-100 p-1">
                @foreach(['day' => 'Día', 'week' => 'Semana', 'month' => 'Mes'] as $key => $label)
                    <a href="{{ route('calendar.index', ['view' => $key, 'date' => $selectedDate->toDateString()]) }}"
                        @class([
                            'rounded-md px-3 py-1.5 text-xs font-semibold',
                            'bg-white text-[#1D3A6C] shadow-sm' => $view === $key,
                            'text-gray-600 hover:text-[#1D3A6C]' => $view !== $key,
                        ])
                        @if($view === $key) aria-current="page" @endif>
                        {{ $label }}
                    </a>
                @endforeach
            </nav>
        </div>

        @if($view === 'day')
            @php($daySessions = $sessions->get($selectedDate->toDateString(), collect()))
            <div class="divide-y divide-gray-100">
                @foreach($hours as $hour)
                    @php($hourSessions = $daySessions->filter(fn ($session) => (int) substr($session->start_time, 0, 2) === $hour))
                    <div class="grid min-h-16 grid-cols-[76px_1fr] sm:grid-cols-[100px_1fr]">
                        <div class="border-r border-gray-100 px-3 py-3 text-right text-xs font-medium text-gray-400">
                            {{ sprintf('%02d:00', $hour) }}
                        </div>
                        <div class="space-y-2 p-2">
                            @foreach($hourSessions as $session)
                                @php($catalogTraining = $session->training->training ?? $session->training)
                                <a href="{{ route('trainings.show', $catalogTraining) }}"
                                    class="block rounded-lg border-l-4 border-[#19A885] bg-[#E8F6F3] px-3 py-2 hover:bg-[#d9f1eb]">
                                    <span class="text-xs font-bold text-[#1D3A6C]">{{ $session->training->title }}</span>
                                    <span class="mt-1 block text-[11px] font-semibold text-[#14866A]">
                                        {{ substr($session->start_time, 0, 5) }}–{{ substr($session->end_time, 0, 5) }}
                                        <span class="font-normal text-gray-600">· {{ $session->training->expert_name ?: 'izyacademy' }}</span>
                                    </span>
                                </a>
                            @endforeach
                        </div>
                    </div>
                @endforeach
                @if($daySessions->isEmpty())
                    <p class="p-8 text-center text-sm text-gray-500">No hay capacitaciones agendadas para este día.</p>
                @endif
            </div>
        @elseif($view === 'week')
            <div class="overflow-x-auto">
                <div class="grid min-w-[980px] grid-cols-7 divide-x divide-gray-100">
                    @foreach($days as $date)
                        @php($dateSessions = $sessions->get($date->toDateString(), collect()))
                        <section class="min-h-64 p-2">
                            <a href="{{ route('calendar.index', ['view' => 'day', 'date' => $date->toDateString()]) }}"
                                class="mb-3 block rounded-lg p-2 text-center hover:bg-gray-50">
                                <span class="block text-[11px] font-semibold uppercase text-gray-500">{{ $weekDays[$date->dayOfWeekIso - 1] }}</span>
                                <span @class([
                                    'mx-auto mt-1 flex h-8 w-8 items-center justify-center rounded-full text-sm font-bold',
                                    'bg-[#1D3A6C] text-white' => $date->isToday(),
                                    'text-gray-800' => !$date->isToday(),
                                ])>{{ $date->format('d') }}</span>
                            </a>
                            <div class="space-y-2">
                                @forelse($dateSessions as $session)
                                    @php($catalogTraining = $session->training->training ?? $session->training)
                                    <a href="{{ route('trainings.show', $catalogTraining) }}" class="block rounded-md border-l-2 border-[#19A885] bg-[#E8F6F3] p-2 text-[11px] hover:bg-[#d9f1eb]">
                                        <span class="font-bold text-[#14866A]">{{ substr($session->start_time, 0, 5) }}–{{ substr($session->end_time, 0, 5) }}</span>
                                        <span class="mt-1 block font-semibold text-[#1D3A6C]">{{ $session->training->title }}</span>
                                    </a>
                                @empty
                                    <p class="px-2 text-center text-[11px] text-gray-400">Sin sesiones</p>
                                @endforelse
                            </div>
                        </section>
                    @endforeach
                </div>
            </div>
        @else
            <div class="overflow-x-auto">
                <div class="grid min-w-[42rem] grid-cols-7">
                    @foreach($weekDays as $weekDay)
                        <div class="border-b border-r border-gray-100 bg-gray-50 px-2 py-3 text-center text-[10px] font-bold uppercase text-gray-500 sm:text-xs">
                            <span class="sm:hidden">{{ mb_substr($weekDay, 0, 1) }}</span>
                            <span class="hidden sm:inline">{{ $weekDay }}</span>
                        </div>
                    @endforeach
                    @foreach($days as $date)
                        @php($dateSessions = $sessions->get($date->toDateString(), collect()))
                        <section @class([
                            'min-h-24 border-b border-r border-gray-100 p-1 sm:min-h-32 sm:p-2',
                            'bg-gray-50/70' => $date->month !== $selectedDate->month,
                        ])>
                            <a href="{{ route('calendar.index', ['view' => 'day', 'date' => $date->toDateString()]) }}"
                            @class([
                                'mb-1 inline-flex h-7 w-7 items-center justify-center rounded-full text-xs',
                                'bg-[#1D3A6C] font-bold text-white' => $date->isToday(),
                                'text-gray-700' => !$date->isToday() && $date->month === $selectedDate->month,
                                'text-gray-300' => $date->month !== $selectedDate->month,
                            ])>{{ $date->format('j') }}</a>
                            <div class="space-y-1">
                            @foreach($dateSessions->take(3) as $session)
                                @php($catalogTraining = $session->training->training ?? $session->training)
                                <a href="{{ route('trainings.show', $catalogTraining) }}" title="{{ $session->training->title }} ({{ substr($session->start_time, 0, 5) }}–{{ substr($session->end_time, 0, 5) }})"
                                    class="block truncate rounded bg-[#E8F6F3] px-1 py-1 text-[9px] font-semibold text-[#14866A] sm:text-[10px]">
                                    {{ substr($session->start_time, 0, 5) }} {{ $session->training->title }}
                                </a>
                            @endforeach
                            @if($dateSessions->count() > 3)
                                <a href="{{ route('calendar.index', ['view' => 'day', 'date' => $date->toDateString()]) }}" class="block px-1 text-[9px] font-semibold text-[#0055AF]">
                                    +{{ $dateSessions->count() - 3 }} más
                                </a>
                            @endif
                            </div>
                        </section>
                    @endforeach
                        </div>
            </div>
        @endif
    </section>
</div>
@endsection

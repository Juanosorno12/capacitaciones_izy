{{-- Catálogo público de capacitaciones disponibles para usuarios externos. --}}
{{-- Muestra resultados paginados y la información resumida de cada capacitación. --}}
@extends('layouts.public')

@section('title', 'Capacitaciones disponibles')

@section('content')
<section class="mb-8 rounded-2xl bg-[#1D3A6C] px-6 py-8 text-white shadow-sm sm:px-10 sm:py-10">
    <p class="text-xs font-semibold uppercase tracking-[0.18em] text-white/70">Oferta formativa</p>
    <div class="mt-3 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
        <div>
            <h1 class="text-2xl font-bold sm:text-3xl">Capacitaciones disponibles</h1>
            <p class="mt-2 max-w-2xl text-sm leading-relaxed text-white/80">
                Explora los programas de formación disponibles. Para consultar los detalles de una capacitación, inicia sesión en la plataforma.
            </p>
        </div>
        <span class="inline-flex w-fit rounded-full bg-white/10 px-3 py-1.5 text-xs font-semibold text-white">
            {{ $trainings->total() }} {{ $trainings->total() === 1 ? 'programa' : 'programas' }}
        </span>
    </div>
</section>

<section aria-labelledby="training-list-heading">
    <div class="mb-4 flex items-end justify-between gap-3">
        <div>
            <h2 id="training-list-heading" class="text-lg font-bold text-[#1D3A6C]">Programas de formación</h2>
            <p class="mt-1 text-xs text-gray-500">Selecciona un programa para ver sus detalles e iniciar sesión.</p>
        </div>
    </div>

    <div class="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-3">
        @forelse($trainings as $training)
            <article class="flex flex-col overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm transition-shadow hover:shadow-md">
                <div class="flex-1 p-5">
                    <div class="flex flex-wrap items-center justify-between gap-2">
                        <span class="inline-flex rounded-full bg-[#EBF3FC] px-2.5 py-1 text-[11px] font-semibold text-[#0055AF]">
                            {{ $training->category->name }}
                        </span>
                        @if($training->has_certificate)
                            <span class="inline-flex rounded-full bg-[#E8F6F3] px-2.5 py-1 text-[11px] font-semibold text-[#14866A]">
                                Certificado
                            </span>
                        @endif
                    </div>

                    <h3 class="mt-4 text-base font-bold leading-snug text-[#1D3A6C]">
                        <a href="{{ route('trainings.show', $training) }}" class="hover:text-[#0055AF] hover:underline">
                            {{ $training->title }}
                        </a>
                    </h3>
                    <p class="mt-2 text-xs leading-relaxed text-gray-600">
                        {{ \Illuminate\Support\Str::limit($training->description, 180) }}
                    </p>

                    <dl class="mt-4 space-y-2 border-t border-gray-100 pt-4 text-xs text-gray-600">
                        <div class="flex items-center justify-between gap-3">
                            <dt>Intensidad</dt>
                            <dd class="font-semibold text-gray-900">{{ $training->duration_hours ?: 'No especificada' }}{{ $training->duration_hours ? ' horas' : '' }}</dd>
                        </div>
                        <div class="flex items-center justify-between gap-3">
                            <dt>Tipo</dt>
                            <dd class="truncate font-semibold text-gray-900">{{ $training->course_type ?: 'No especificado' }}</dd>
                        </div>
                        <div>
                            <dt>Proveedor</dt>
                            <dd class="truncate font-semibold text-gray-900">{{ $training->training_provider ?: 'No especificado' }}</dd>
                        </div>
                    </dl>
                </div>

                <div class="border-t border-gray-100 bg-gray-50 px-5 py-3">
                    <a href="{{ route('trainings.show', $training) }}" class="inline-flex w-full items-center justify-center rounded-lg bg-[#0055AF] px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-[#003E80]">
                        Ver capacitación
                    </a>
                </div>
            </article>
        @empty
            <div class="col-span-full rounded-xl border border-gray-200 bg-white px-6 py-12 text-center">
                <h3 class="text-base font-semibold text-[#1D3A6C]">No hay capacitaciones disponibles por el momento</h3>
                <p class="mt-2 text-sm text-gray-500">Vuelve a consultar más adelante para conocer nuevos programas.</p>
            </div>
        @endforelse
    </div>

    @if($trainings->hasPages())
        <nav class="mt-6 rounded-xl border border-gray-200 bg-white px-4 py-3" aria-label="Paginación de capacitaciones">
            {{ $trainings->links() }}
        </nav>
    @endif
</section>
@endsection

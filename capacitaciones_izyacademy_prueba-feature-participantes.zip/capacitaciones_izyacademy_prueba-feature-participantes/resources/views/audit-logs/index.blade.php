{{-- Registro de auditoría de solo lectura para administradores. --}}
@extends('layouts.app')

@section('title', 'Registro de auditoría')
@section('header_title', 'Registro de auditoría')

@section('content')
<div class="space-y-6">
    <div>
        <h2 class="text-xl font-bold text-[#1D3A6C]">Registro de auditoría</h2>
        <p class="mt-1 text-xs text-gray-500">Consulta acciones relevantes de usuarios y del sistema. Los registros no se editan desde esta pantalla.</p>
    </div>

    <form method="GET" action="{{ route('audit-logs.index') }}" class="grid grid-cols-1 gap-3 rounded-xl border border-gray-200 bg-white p-4 shadow-sm sm:grid-cols-12">
        <label for="audit-log-search" class="sr-only">Buscar descripción o entidad</label>
        <input id="audit-log-search" name="search" value="{{ $filters['search'] ?? '' }}" placeholder="Buscar descripción o entidad..." class="rounded-lg border-gray-300 text-xs sm:col-span-6">

        <label for="audit-log-action" class="sr-only">Filtrar por acción</label>
        <select id="audit-log-action" name="action" class="rounded-lg border-gray-300 text-xs sm:col-span-4">
            <option value="">Todas las acciones</option>
            @foreach($actions as $action)
                <option value="{{ $action }}" @selected(($filters['action'] ?? '') === $action)>{{ \App\Models\AuditLog::actionLabel($action) }}</option>
            @endforeach
        </select>

        <button class="rounded-lg bg-[#1D3A6C] px-4 py-2 text-xs font-bold text-white sm:col-span-2">Filtrar</button>
    </form>

    <div class="overflow-x-auto rounded-xl border border-gray-200 bg-white shadow-sm">
        <table class="min-w-full text-left text-xs">
            <thead class="bg-gray-50 text-gray-600">
                <tr>
                    <th class="px-4 py-3">Fecha</th>
                    <th class="px-4 py-3">Usuario</th>
                    <th class="px-4 py-3">Acción</th>
                    <th class="px-4 py-3">Descripción</th>
                    <th class="px-4 py-3">IP</th>
                </tr>
            </thead>
            <tbody>
                @forelse($logs as $log)
                    <tr class="border-t border-gray-100 align-top">
                        <td class="whitespace-nowrap px-4 py-3">{{ $log->created_at?->format('d/m/Y H:i:s') }}</td>
                        <td class="px-4 py-3">{{ $log->user?->name ?? 'Sistema' }}</td>
                        <td class="px-4 py-3 font-semibold text-[#1D3A6C]">{{ $log->action_label }}</td>
                        <td class="px-4 py-3">{{ $log->description }}</td>
                        <td class="px-4 py-3">{{ $log->ip_address ?? 'N/D' }}</td>
                    </tr>
                @empty
                    <tr><td colspan="5" class="px-4 py-8 text-center text-gray-500">No hay registros para los filtros seleccionados.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    {{ $logs->links() }}
</div>
@endsection

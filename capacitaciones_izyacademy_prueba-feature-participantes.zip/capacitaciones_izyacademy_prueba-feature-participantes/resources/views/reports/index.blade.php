{{-- Dashboard de reportes y analítica. --}}
{{-- Muestra indicadores, filtros de periodo, tablas y gráficos de capacitaciones. --}}
@extends('layouts.app')

@section('title', 'Reportes y Analítica')
@section('header_title', 'Dashboard de Analítica y Reportes Ejecutivos')

@section('content')
<div class="space-y-8">

    <!-- Header del Módulo -->
    <div class="sm:flex sm:items-center sm:justify-between">
        <div>
            <h2 class="text-xl font-bold text-[#1D3A6C]">Métricas y Analítica de Formación</h2>
            <p class="text-xs text-gray-500 mt-1">Indicadores de solicitudes, capacitaciones, sesiones impartidas y participantes.</p>
        </div>
        <button type="button" onclick="window.print()" class="mt-4 inline-flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-4 py-2 text-xs font-bold text-gray-700 shadow-sm transition-colors hover:bg-gray-50 sm:mt-0">
            <svg class="h-4 w-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/>
            </svg>
            Imprimir Reporte Ejecutivo
        </button>
    </div>

    <section class="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
        <div class="mb-4">
            <h3 class="text-sm font-bold text-[#1D3A6C]">Filtrar capacitaciones programadas</h3>
            <p class="mt-1 text-xs text-gray-500">Se muestran las sesiones programadas dentro del periodo seleccionado, incluyendo las próximas y las ya realizadas.</p>
        </div>
        <form id="report-period-filter" method="GET" action="{{ route('reports.index') }}" class="grid grid-cols-1 items-end gap-3 md:grid-cols-2 md:gap-3 lg:grid-cols-4 lg:gap-4">
            <div>
                <label for="period" class="block text-xs font-semibold text-gray-700">Periodo</label>
                <select name="period" id="period" class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-xs focus:border-[#0055AF] focus:ring-[#0055AF]/20">
                    <option value="month" {{ $filters['period'] === 'month' ? 'selected' : '' }}>Un mes</option>
                    <option value="date_range" {{ $filters['period'] === 'date_range' ? 'selected' : '' }}>Rango de días</option>
                    <option value="month_range" {{ $filters['period'] === 'month_range' ? 'selected' : '' }}>Rango de meses</option>
                </select>
            </div>
            <div data-period-field="month">
                <label for="month" class="block text-xs font-semibold text-gray-700">Mes</label>
                <input type="month" name="month" id="month" value="{{ $filters['month'] ?? now(config('app.timezone'))->format('Y-m') }}"
                    class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-xs focus:border-[#0055AF] focus:ring-[#0055AF]/20">
            </div>
            <div data-period-field="date_range">
                <label for="date_from" class="block text-xs font-semibold text-gray-700">Desde el día</label>
                <input type="date" name="date_from" id="date_from" value="{{ $filters['date_from'] ?? '' }}"
                    class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-xs focus:border-[#0055AF] focus:ring-[#0055AF]/20">
            </div>
            <div data-period-field="date_range">
                <label for="date_to" class="block text-xs font-semibold text-gray-700">Hasta el día</label>
                <input type="date" name="date_to" id="date_to" value="{{ $filters['date_to'] ?? '' }}"
                    class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-xs focus:border-[#0055AF] focus:ring-[#0055AF]/20">
            </div>
            <div data-period-field="month_range">
                <label for="month_from" class="block text-xs font-semibold text-gray-700">Mes inicial</label>
                <input type="month" name="month_from" id="month_from" value="{{ $filters['month_from'] ?? '' }}"
                    class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-xs focus:border-[#0055AF] focus:ring-[#0055AF]/20">
            </div>
            <div data-period-field="month_range">
                <label for="month_to" class="block text-xs font-semibold text-gray-700">Mes final</label>
                <input type="month" name="month_to" id="month_to" value="{{ $filters['month_to'] ?? '' }}"
                    class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-xs focus:border-[#0055AF] focus:ring-[#0055AF]/20">
            </div>
            <div>
                <label for="value_added" class="block text-xs font-semibold text-gray-700">Tipo de capacitación</label>
                <select name="value_added" id="value_added" class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-xs focus:border-[#0055AF] focus:ring-[#0055AF]/20">
                    <option value="all" {{ ($filters['value_added'] ?? 'all') === 'all' ? 'selected' : '' }}>Todas</option>
                    <option value="yes" {{ ($filters['value_added'] ?? '') === 'yes' ? 'selected' : '' }}>Solo valor agregado</option>
                    <option value="no" {{ ($filters['value_added'] ?? '') === 'no' ? 'selected' : '' }}>Sin valor agregado</option>
                </select>
            </div>
            <div class="report-filter-actions flex items-stretch gap-2">
                <button type="submit" class="report-filter-submit inline-flex items-center justify-center whitespace-nowrap rounded-lg bg-[#1D3A6C] px-3 py-2 text-xs font-semibold text-white hover:bg-[#13274A] lg:px-4">Aplicar filtros</button>
                <a href="{{ route('reports.index') }}" class="report-filter-clear inline-flex items-center justify-center whitespace-nowrap rounded-lg bg-gray-100 px-3 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-200 lg:px-4">Limpiar</a>
            </div>
        </form>
    </section>

    <section class="space-y-4">
        <div class="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
            <div class="min-w-0 flex-1">
                <h3 class="text-lg font-bold text-[#1D3A6C]">Capacitaciones programadas</h3>
                <p class="mt-1 max-w-2xl text-xs text-gray-500">Periodo: {{ $periodLabel }} · El detalle muestra una fila por cada sesión programada.</p>
            </div>
            <div class="flex shrink-0 flex-col items-stretch gap-1 sm:items-end">
                <button type="button" id="export-delivered-trainings"
                    data-export-url="{{ route('reports.trainings.export', request()->query()) }}"
                    class="inline-flex items-center justify-center gap-2 rounded-lg bg-[#19A885] px-4 py-2.5 text-xs font-bold text-white shadow-sm hover:bg-[#14866A] disabled:cursor-wait disabled:opacity-60">
                    Exportar a Excel (.xlsx)
                </button>
                <p id="report-export-status" class="w-full text-right text-xs text-red-600" role="status" aria-live="polite"></p>
            </div>
        </div>

        <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <div class="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                <p class="text-xs font-semibold uppercase tracking-wide text-gray-500">Capacitaciones</p>
                <p class="mt-2 text-2xl font-extrabold text-[#1D3A6C]">{{ number_format($deliveredMetrics['trainings']) }}</p>
                <p class="mt-1 text-xs text-gray-500">Programas con sesiones programadas en el periodo</p>
            </div>
            <div class="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                <p class="text-xs font-semibold uppercase tracking-wide text-gray-500">Sesiones impartidas</p>
                <p class="mt-2 text-2xl font-extrabold text-[#0055AF]">{{ number_format($deliveredMetrics['sessions']) }}</p>
                <p class="mt-1 text-xs text-gray-500">Fechas de capacitación programadas</p>
            </div>
            <div class="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                <p class="text-xs font-semibold uppercase tracking-wide text-gray-500">Horas impartidas</p>
                <p class="mt-2 text-2xl font-extrabold text-[#14866A]">{{ number_format($deliveredMetrics['hours'], 1) }} h</p>
                <p class="mt-1 text-xs text-gray-500">Suma de la duración de las sesiones registradas</p>
            </div>
            <div class="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                <p class="text-xs font-semibold uppercase tracking-wide text-gray-500">Participantes</p>
                <p class="mt-2 text-2xl font-extrabold text-emerald-600">{{ number_format($deliveredMetrics['participants']) }}</p>
                <p class="mt-1 text-xs text-gray-500">Personas únicas asociadas a las capacitaciones</p>
            </div>
        </div>

        <div class="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
            <div class="overflow-x-auto">
                <table class="responsive-table min-w-full divide-y divide-gray-200 text-left text-xs">
                    <thead class="bg-gray-50 text-gray-600">
                        <tr>
                            <th class="px-4 py-3 font-semibold">Fecha</th>
                            <th class="px-4 py-3 font-semibold">Capacitación</th>
                            <th class="px-4 py-3 font-semibold">Cliente</th>
                            <th class="px-4 py-3 font-semibold">Valor agregado</th>
                            <th class="px-4 py-3 font-semibold">Categoría</th>
                            <th class="px-4 py-3 font-semibold">Facilitador</th>
                            <th class="px-4 py-3 font-semibold">Modalidad</th>
                            <th class="px-4 py-3 font-semibold">Horario</th>
                            <th class="px-4 py-3 text-right font-semibold">Participantes</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        @forelse($deliveredSessions as $session)
                            @php($training = $session->training)
                            <tr>
                                <td class="whitespace-nowrap px-4 py-3 text-gray-600">{{ $session->session_date->format('d/m/Y') }}</td>
                                <td class="min-w-48 px-4 py-3 font-semibold text-[#1D3A6C]">
                                    <a href="{{ route('trainings.show', $training->training) }}" class="hover:underline">{{ $training->title }}</a>
                                </td>
                                <td class="px-4 py-3 text-gray-600">{{ $training->request?->client_name ?: '—' }}</td>
                                <td class="px-4 py-3 text-gray-600">{{ $training->value_added ? 'Sí' : 'No' }}</td>
                                <td class="px-4 py-3 text-gray-600">{{ $training->category->name }}</td>
                                <td class="px-4 py-3 text-gray-600">{{ $training->expert_name ?: 'izyacademy' }}</td>
                                <td class="px-4 py-3 text-gray-600">{{ $training->modality === 'virtual' ? 'Virtual' : ($training->modality === 'presencial' ? 'Presencial' : '—') }}</td>
                                <td class="whitespace-nowrap px-4 py-3 text-gray-600">{{ substr((string) $session->start_time, 0, 5) }}–{{ substr((string) $session->end_time, 0, 5) }}</td>
                                <td class="px-4 py-3 text-right text-gray-600">{{ $training->participants->count() }}</td>
                            </tr>
                        @empty
                            <tr><td colspan="9" class="px-4 py-10 text-center text-gray-500">No hay sesiones programadas en el periodo seleccionado.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            @if($deliveredSessions->hasPages())
                <div class="border-t border-gray-100 p-4">{{ $deliveredSessions->links() }}</div>
            @endif
        </div>
    </section>

    <!-- TARJETAS DE MÉTRICAS KPI -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <!-- KPI 1 -->
        <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
            <div class="flex items-center justify-between">
                <p class="text-xs font-semibold text-gray-500 uppercase tracking-wider">Capacitaciones</p>
                <div class="w-9 h-9 rounded-lg bg-[#EBF3FC] flex items-center justify-center text-[#0055AF]">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
                    </svg>
                </div>
            </div>
            <p class="text-3xl font-extrabold text-[#1D3A6C] mt-3">{{ $kpis['total_trainings'] }}</p>
            <p class="text-xs text-gray-500 mt-1">Cursos programados</p>
        </div>

        <!-- KPI 2 -->
        <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
            <div class="flex items-center justify-between">
                <p class="text-xs font-semibold text-gray-500 uppercase tracking-wider">Horas Académicas Programadas</p>
                <div class="w-9 h-9 rounded-lg bg-[#E8F6F3] flex items-center justify-center text-[#19A885]">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                </div>
            </div>
            <p class="text-3xl font-extrabold text-[#19A885] mt-3">{{ $kpis['total_hours'] }}h</p>
            <p class="text-xs text-gray-500 mt-1">Duración académica registrada</p>
        </div>

        <!-- KPI 3 -->
        <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
            <div class="flex items-center justify-between">
                <p class="text-xs font-semibold text-gray-500 uppercase tracking-wider">Solicitudes Totales</p>
                <div class="w-9 h-9 rounded-lg bg-[#FFF2EB] flex items-center justify-center text-[#FF5F00]">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                    </svg>
                </div>
            </div>
            <p class="text-3xl font-extrabold text-[#FF5F00] mt-3">{{ $kpis['total_requests'] }}</p>
            <p class="text-xs text-gray-500 mt-1">{{ $kpis['pending_requests'] }} pendientes de revisión</p>
        </div>

        <!-- KPI 4 -->
        <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
            <div class="flex items-center justify-between">
                <p class="text-xs font-semibold text-gray-500 uppercase tracking-wider">Beneficiarios</p>
                <div class="w-9 h-9 rounded-lg bg-emerald-50 flex items-center justify-center text-emerald-600">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                    </svg>
                </div>
            </div>
            <p class="text-3xl font-extrabold text-emerald-600 mt-3">{{ $kpis['estimated_beneficiaries'] }}</p>
            <p class="text-xs text-gray-500 mt-1">Colaboradores capacitados</p>
        </div>
    </div>

    <!-- PANELES DE GRÁFICOS CHART.JS -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Gráfico 1: Capacitaciones por Categoría -->
        <div class="bg-white rounded-xl border border-gray-200 p-6 shadow-sm flex flex-col justify-between">
            <div class="mb-4">
                <h3 class="font-bold text-sm text-[#1D3A6C]">Distribución por Categoría Temática</h3>
                <p class="text-xs text-gray-500">Capacitaciones activas agrupadas por especialidad técnica</p>
            </div>
            <div class="relative h-72 w-full flex items-center justify-center">
                <canvas id="trainingsByCategoryChart"></canvas>
            </div>
        </div>

        <!-- Gráfico 2: Solicitudes por Estado -->
        <div class="bg-white rounded-xl border border-gray-200 p-6 shadow-sm flex flex-col justify-between">
            <div class="mb-4">
                <h3 class="font-bold text-sm text-[#1D3A6C]">Estado de Solicitudes de Formación</h3>
                <p class="text-xs text-gray-500">Embudo de gestión de solicitudes de las áreas</p>
            </div>
            <div class="relative h-72 w-full flex items-center justify-center">
                <canvas id="requestsByStatusChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Gráfico 3: Horas por Especialidad Top -->
    <div class="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
        <div class="mb-4">
            <h3 class="font-bold text-sm text-[#1D3A6C]">Horas de Capacitación por Línea Técnica</h3>
            <p class="text-xs text-gray-500">Concentración de horas impartidas en los ejes formativos principales</p>
        </div>
        <div class="relative h-72 w-full">
            <canvas id="hoursTrendChart"></canvas>
        </div>
    </div>

</div>
@endsection

@push('scripts')
@vite('resources/js/reports.js')

<script>
document.addEventListener('DOMContentLoaded', () => {
    renderCorporateCharts();

    // Construye los gráficos de categorías, estados y horas usando datos del controlador.
    function renderCorporateCharts() {
        const brand = {
            navy: '#1D3A6C',
            teal: '#19A885',
            orange: '#FF5F00',
            blue: '#0055AF',
            palette: ['#1D3A6C', '#19A885', '#FF5F00', '#0055AF', '#4F46E5', '#06B6D4', '#84CC16', '#F59E0B']
        };

        // 1. Doughnut: Categorías
        const categoryData = @json($chartCategories);
        const catCanvas = document.getElementById('trainingsByCategoryChart');
        if (catCanvas && categoryData.labels.length > 0) {
            new Chart(catCanvas, {
                type: 'doughnut',
                data: {
                    labels: categoryData.labels,
                    datasets: [{
                        data: categoryData.values,
                        backgroundColor: brand.palette.slice(0, categoryData.labels.length),
                        borderWidth: 2,
                        borderColor: '#ffffff'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: { boxWidth: 10, font: { family: 'Inter', size: 11 }, padding: 12 }
                        }
                    },
                    cutout: '65%'
                }
            });
        }

        // 2. Bar: Solicitudes por Estado
        const statusData = @json($chartStatuses);
        const statusCanvas = document.getElementById('requestsByStatusChart');
        if (statusCanvas) {
            new Chart(statusCanvas, {
                type: 'bar',
                data: {
                    labels: statusData.labels,
                    datasets: [{
                        label: 'Total Solicitudes',
                        data: statusData.values,
                        backgroundColor: [brand.orange, brand.blue, brand.teal, '#EF4444'],
                        borderRadius: 6
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: { stepSize: 1, font: { family: 'Inter', size: 11 } },
                            grid: { color: '#F1F5F9' }
                        },
                        x: {
                            grid: { display: false },
                            ticks: { font: { family: 'Inter', size: 11 } }
                        }
                    }
                }
            });
        }

        // 3. Bar: Horas por Especialidad
        const trendData = @json($chartTrends);
        const trendCanvas = document.getElementById('hoursTrendChart');
        if (trendCanvas) {
            new Chart(trendCanvas, {
                type: 'bar',
                data: {
                    labels: trendData.labels,
                    datasets: [{
                        label: 'Horas Académicas',
                        data: trendData.values,
                        backgroundColor: brand.navy,
                        borderRadius: 6
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: { color: '#F1F5F9' },
                            ticks: { font: { family: 'Inter', size: 11 } }
                        },
                        x: {
                            grid: { display: false },
                            ticks: { font: { family: 'Inter', size: 11 } }
                        }
                    }
                }
            });
        }
    }
});
</script>
@endpush

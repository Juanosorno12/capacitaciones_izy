{{-- Formulario para editar una capacitación existente. --}}
{{-- Precarga los datos actuales y permite actualizar información, experto y sesiones. --}}
@extends('layouts.app')

@section('title', 'Editar Capacitación')
@section('header_title', 'Modificar Programa Formativo')

@section('content')
<div class="max-w-4xl mx-auto space-y-6">
    <div class="flex items-center justify-between">
        <div>
            <h2 class="text-xl font-bold text-[#1D3A6C]">Editar Capacitación: {{ $training->title }}</h2>
            <p class="text-xs text-gray-500">Actualiza la información académica del catálogo y la definición del certificado.</p>
        </div>
        <a href="{{ route('trainings.show', $training) }}" class="text-xs font-semibold text-gray-600 hover:text-[#1D3A6C]">
            &larr; Ver programa
        </a>
    </div>

    <div class="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
        <form action="{{ route('trainings.update', $training) }}" method="POST" class="space-y-6">
            @csrf
            @method('PUT')

            <!-- Título -->
            <div>
                <label for="title" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Título del Programa *</label>
                <input type="text" name="title" id="title" required value="{{ old('title', $training->title) }}"
                    class="mt-1 w-full rounded-lg border-gray-300 shadow-sm focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 text-xs px-3 py-2.5 border">
                @error('title')
                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                @foreach([
                    'course_type' => 'Curso o Certificación *',
                    'training_provider' => 'Proveedor de Formación',
                    'shopping_cart_project' => 'Proyecto Carrito de Compras',
                ] as $field => $label)
                    <div>
                        <label for="{{ $field }}" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">{{ $label }}</label>
                        @if($field === 'course_type')
                            <select name="{{ $field }}" id="{{ $field }}" required class="mt-1 w-full rounded-lg border-gray-300 text-xs px-3 py-2 border">
                                <option value="">Selecciona el tipo...</option>
                                <option value="Curso" @selected(old($field, $training->{$field}) === 'Curso')>Curso</option>
                                <option value="Certificación" @selected(old($field, $training->{$field}) === 'Certificación')>Certificación</option>
                            </select>
                        @else
                            <input type="text" name="{{ $field }}" id="{{ $field }}" value="{{ old($field, $training->{$field}) }}"
                                class="mt-1 w-full rounded-lg border-gray-300 text-xs px-3 py-2 border">
                        @endif
                        @error($field) <p class="mt-1 text-xs text-red-600">{{ $message }}</p> @enderror
                    </div>
                @endforeach
            </div>

            <!-- Categoría y Duración -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label for="category_id" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Categoría Temática *</label>
                    <select name="category_id" id="category_id" required
                        class="mt-1 w-full rounded-lg border-gray-300 shadow-sm focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 text-xs px-3 py-2 border">
                        @foreach($categories as $category)
                            <option value="{{ $category->id }}" {{ old('category_id', $training->category_id) == $category->id ? 'selected' : '' }}>
                                {{ $category->name }}
                            </option>
                        @endforeach
                    </select>
                    @error('category_id')
                        <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label for="duration_hours" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Duración Total (Horas) *</label>
                    <input type="number" name="duration_hours" id="duration_hours" min="1" max="500" required value="{{ old('duration_hours', $training->duration_hours) }}"
                        class="mt-1 w-full rounded-lg border-gray-300 shadow-sm focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 text-xs px-3 py-2 border">
                    @error('duration_hours')
                        <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                    @enderror
                </div>
            </div>

            <!-- Descripción -->
            <div>
                <label for="description" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Descripción y Objetivos *</label>
                <textarea name="description" id="description" rows="4" required
                    class="mt-1 w-full rounded-lg border-gray-300 shadow-sm focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 text-xs p-3 border">{{ old('description', $training->description) }}</textarea>
                @error('description')
                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="syllabus" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Temario del Curso *</label>
                <textarea name="syllabus" id="syllabus" rows="4" required class="mt-1 w-full rounded-lg border-gray-300 text-xs p-3 border">{{ old('syllabus', $training->syllabus) }}</textarea>
                @error('syllabus') <p class="mt-1 text-xs text-red-600">{{ $message }}</p> @enderror
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div><label for="subtitles" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Subtítulos</label><textarea name="subtitles" id="subtitles" rows="3" class="mt-1 w-full rounded-lg border-gray-300 text-xs p-3 border">{{ old('subtitles', $training->subtitles) }}</textarea></div>
                <div><label for="prerequisites" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Prerrequisitos</label><textarea name="prerequisites" id="prerequisites" rows="3" class="mt-1 w-full rounded-lg border-gray-300 text-xs p-3 border">{{ old('prerequisites', $training->prerequisites) }}</textarea></div>
                <div><label for="level" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Nivel</label><input type="text" name="level" id="level" value="{{ old('level', $training->level) }}" class="mt-1 w-full rounded-lg border-gray-300 text-xs px-3 py-2 border"></div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                @foreach([
                    'digital_badge' => 'Insignia Digital *',
                    'for_internal_staff' => 'Para Personal Interno *',
                    'for_external_staff' => 'Para Personal Externo *',
                ] as $field => $label)
                    <div>
                        <label for="{{ $field }}" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">{{ $label }}</label>
                        <select name="{{ $field }}" id="{{ $field }}" required class="mt-1 w-full rounded-lg border-gray-300 text-xs px-3 py-2 border">
                            <option value="1" {{ (string) old($field, $training->{$field}) === '1' ? 'selected' : '' }}>Sí</option>
                            <option value="0" {{ (string) old($field, $training->{$field}) === '0' ? 'selected' : '' }}>No</option>
                        </select>
                        @error($field) <p class="mt-1 text-xs text-red-600">{{ $message }}</p> @enderror
                    </div>
                @endforeach
            </div>

            <!-- Parámetros -->
            <div class="pt-4 border-t border-gray-100 space-y-4" x-data="{ hasCert: {{ old('has_certificate', $training->has_certificate) ? 'true' : 'false' }} }">
                <div class="flex items-center">
                    <input type="hidden" name="has_certificate" value="0">
                    <input type="checkbox" name="has_certificate" id="has_certificate" value="1" x-model="hasCert"
                        {{ old('has_certificate', $training->has_certificate) ? 'checked' : '' }}
                        class="h-4 w-4 rounded border-gray-300 text-[#19A885] focus:ring-[#19A885]">
                    <label for="has_certificate" class="ml-2 block text-xs font-semibold text-gray-900">
                        Genera certificado oficial de aprobación
                    </label>
                </div>

                <div x-show="hasCert" class="pt-2">
                    <label for="certificate_template_url" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">URL de Plantilla del Certificado</label>
                    <input type="url" name="certificate_template_url" id="certificate_template_url" value="{{ old('certificate_template_url', $training->certificate_template_url) }}"
                        class="mt-1 w-full rounded-lg border-gray-300 shadow-sm focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 text-xs px-3 py-2 border">
                </div>
            </div>

            <!-- Botones -->
            <div class="flex items-center justify-end gap-3 pt-4 border-t border-gray-100">
                <a href="{{ route('trainings.show', $training) }}" class="px-4 py-2 text-xs font-semibold text-gray-600 hover:text-gray-800">
                    Cancelar
                </a>
                <button type="submit" class="px-6 py-2.5 bg-[#19A885] hover:bg-[#14866A] text-white text-xs font-bold rounded-lg shadow-sm transition-colors">
                    Actualizar Capacitación
                </button>
            </div>
        </form>
    </div>
</div>
@endsection

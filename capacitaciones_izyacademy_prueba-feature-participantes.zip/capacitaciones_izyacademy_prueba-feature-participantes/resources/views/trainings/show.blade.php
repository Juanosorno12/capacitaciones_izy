{{-- Detalle del curso o certificación del catálogo. --}}
@extends('layouts.app')

@section('title', $training->title)
@section('header_title', 'Detalle de Capacitación')

@section('content')
<div class="max-w-5xl mx-auto space-y-6">

    <!-- Navegación y Botones de Gestión -->
    <div class="flex flex-col items-start gap-3 sm:flex-row sm:items-center sm:justify-between">
        <a href="{{ route('trainings.index') }}" class="text-xs font-semibold text-[#0055AF] hover:underline flex items-center gap-1">
            &larr; Volver al catálogo de capacitaciones
        </a>

        <div class="flex items-center gap-2">
            @hasPermission('requests.create')
            <a href="{{ route('requests.create', ['training_id' => $training->id]) }}" class="px-3.5 py-1.5 bg-[#19A885] text-white hover:bg-[#14866A] text-xs font-bold rounded-lg transition-colors">
                Solicitar capacitación
            </a>
            @endhasPermission

            @hasPermission('trainings.manage')
            <a href="{{ route('trainings.edit', $training) }}" class="px-3.5 py-1.5 bg-white border border-gray-300 text-gray-700 hover:bg-gray-50 text-xs font-bold rounded-lg transition-colors">
                Editar
            </a>
            <form action="{{ route('trainings.destroy', $training) }}" method="POST" onsubmit="return confirm('¿Estás seguro de eliminar este programa formativo?');">
                @csrf
                @method('DELETE')
                <button type="submit" class="px-3.5 py-1.5 bg-red-50 text-red-600 hover:bg-red-100 text-xs font-bold rounded-lg transition-colors border border-red-200">
                    Eliminar
                </button>
            </form>
            @endhasPermission
        </div>
    </div>

    <!-- Información académica del curso -->
    <div class="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
        <div class="p-6 sm:p-8 border-b border-gray-100 bg-[#F8FAFC]">
            <h1 class="text-2xl sm:text-3xl font-bold text-[#1D3A6C] tracking-tight">
                {{ $training->title }}
            </h1>
            <p class="text-xs text-gray-500 mt-2">
                Nombre del Curso o Certificación *
            </p>
        </div>

        <div class="p-6 sm:p-8 space-y-8">
            <dl class="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
                <div class="rounded-xl border border-gray-200 bg-gray-50 p-4">
                    <dt class="text-xs font-semibold uppercase tracking-wider text-gray-500">Curso o Certificación *</dt>
                    <dd class="mt-2 text-sm font-semibold text-gray-900">{{ $training->course_type }}</dd>
                </div>
                <div class="rounded-xl border border-gray-200 bg-gray-50 p-4">
                    <dt class="text-xs font-semibold uppercase tracking-wider text-gray-500">Categoría *</dt>
                    <dd class="mt-2 text-sm font-semibold text-gray-900">{{ $training->category->name }}</dd>
                </div>
                <div class="rounded-xl border border-gray-200 bg-gray-50 p-4">
                    <dt class="text-xs font-semibold uppercase tracking-wider text-gray-500">Intensidad Horaria *</dt>
                    <dd class="mt-2 text-sm font-semibold text-gray-900">{{ $training->duration_hours }} horas</dd>
                </div>
                <div class="rounded-xl border border-gray-200 bg-gray-50 p-4">
                    <dt class="text-xs font-semibold uppercase tracking-wider text-gray-500">Insignia Digital *</dt>
                    <dd class="mt-2 text-sm font-semibold text-gray-900">
                        {{ is_null($training->digital_badge) ? 'No especificado' : ($training->digital_badge ? 'Sí' : 'No') }}
                    </dd>
                </div>
                <div class="rounded-xl border border-gray-200 bg-gray-50 p-4">
                    <dt class="text-xs font-semibold uppercase tracking-wider text-gray-500">Para Personal Interno *</dt>
                    <dd class="mt-2 text-sm font-semibold text-gray-900">
                        {{ is_null($training->for_internal_staff) ? 'No especificado' : ($training->for_internal_staff ? 'Sí' : 'No') }}
                    </dd>
                </div>
                <div class="rounded-xl border border-gray-200 bg-gray-50 p-4">
                    <dt class="text-xs font-semibold uppercase tracking-wider text-gray-500">Para Personal Externo *</dt>
                    <dd class="mt-2 text-sm font-semibold text-gray-900">
                        {{ is_null($training->for_external_staff) ? 'No especificado' : ($training->for_external_staff ? 'Sí' : 'No') }}
                    </dd>
                </div>
            </dl>

            <section>
                <h2 class="text-xs font-semibold uppercase tracking-wider text-gray-500">Descripción *</h2>
                <p class="mt-2 whitespace-pre-line text-sm leading-relaxed text-gray-700">{{ $training->description }}</p>
            </section>

            <section class="border-t border-gray-100 pt-6">
                <h2 class="text-xs font-semibold uppercase tracking-wider text-gray-500">Temario del Curso *</h2>
                <p class="mt-2 whitespace-pre-line text-sm leading-relaxed text-gray-700">{{ $training->syllabus }}</p>
            </section>
        </div>
    </div>
</div>
@endsection

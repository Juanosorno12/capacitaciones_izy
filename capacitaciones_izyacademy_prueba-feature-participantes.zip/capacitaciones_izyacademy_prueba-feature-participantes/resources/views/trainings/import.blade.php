{{-- Importación y exportación administrativa del inventario de capacitaciones. --}}
@extends('layouts.app')

@section('title', 'Importar capacitaciones')
@section('header_title', 'Importar capacitaciones')

@section('content')
<div class="max-w-6xl mx-auto space-y-6">
    <div class="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
        <div class="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
            <div>
                <h2 class="text-xl font-bold text-[#1D3A6C]">Carga masiva de cursos y certificaciones</h2>
                <p class="mt-1 text-sm text-gray-600">
                    Usa la hoja <strong>Cursos</strong>. Las filas sin identificación interna crean registros nuevos;
                    las filas de un inventario exportado actualizan los registros existentes. Si agregas
                    <strong>Genera Certificado</strong>, deja una celda vacía para indicar No.
                </p>
                <p class="mt-2 text-xs text-gray-500">
                    En filas existentes, los campos académicos obligatorios que estén vacíos conservan su valor actual; complétalos en el archivo si deseas corregir datos históricos.
                </p>
            </div>
            @hasPermission('trainings.export')
                <a href="{{ route('trainings.export') }}" class="inline-flex items-center justify-center rounded-lg bg-[#1D3A6C] px-4 py-2 text-xs font-bold text-white hover:bg-[#13274A]">
                    Descargar inventario
                </a>
            @endhasPermission
        </div>

        <form method="POST" action="{{ route('trainings.import.preview') }}" enctype="multipart/form-data" class="mt-6 flex flex-col gap-3 sm:flex-row sm:items-end">
            @csrf
            <div class="flex-1">
                <label for="inventory_file" class="mb-1 block text-xs font-semibold text-gray-700">Archivo Excel (.xlsx o .xls)</label>
                <input id="inventory_file" name="inventory_file" type="file" accept=".xlsx,.xls" required
                    class="block w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-[#0055AF] focus:ring-[#0055AF]">
                @error('inventory_file')
                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                @enderror
            </div>
            <button type="submit" class="rounded-lg bg-[#19A885] px-5 py-2.5 text-xs font-bold text-white hover:bg-[#14866A]">
                Validar archivo
            </button>
        </form>
    </div>

    @if(session('training_import_result'))
        @php($result = session('training_import_result'))
        <div class="rounded-xl border border-emerald-200 bg-emerald-50 p-5 text-sm text-emerald-800">
            <p class="font-bold">Importación procesada</p>
            <p class="mt-1">
                Creados: {{ $result['created_count'] }} · Actualizados: {{ $result['updated_count'] }} ·
                Filas con error: {{ $result['invalid_count'] }}
            </p>
        </div>
    @endif

    @isset($preview)
        <div class="rounded-xl border border-blue-200 bg-blue-50 p-5">
            <h3 class="font-bold text-[#1D3A6C]">Vista previa</h3>
            <p class="mt-1 text-sm text-gray-700">
                Total: {{ $preview['total'] }} · Válidas: {{ $preview['valid_count'] }} ·
                Con errores: {{ $preview['invalid_count'] }}
            </p>

            @if($preview['errors'] !== [])
                <div class="mt-4 overflow-x-auto rounded-lg border border-red-200 bg-white">
                    <table class="min-w-full text-left text-xs">
                        <thead class="bg-red-50 text-red-800">
                            <tr><th class="px-3 py-2">Fila</th><th class="px-3 py-2">Errores</th></tr>
                        </thead>
                        <tbody>
                            @foreach($preview['errors'] as $error)
                                <tr class="border-t border-gray-100 align-top">
                                    <td class="px-3 py-2 font-semibold">{{ $error['row'] }}</td>
                                    <td class="px-3 py-2">{{ implode(' ', $error['messages']) }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @endif

            @if($preview['valid_count'] > 0)
                <form method="POST" action="{{ route('trainings.import.confirm') }}" class="mt-5">
                    @csrf
                    <input type="hidden" name="token" value="{{ $token }}">
                    <button type="submit" class="rounded-lg bg-[#1D3A6C] px-5 py-2.5 text-xs font-bold text-white hover:bg-[#13274A]">
                        Confirmar importación de {{ $preview['valid_count'] }} fila(s)
                    </button>
                </form>
            @else
                <p class="mt-4 text-sm font-semibold text-red-700">No hay filas válidas para importar.</p>
            @endif
        </div>
    @endisset
</div>
@endsection

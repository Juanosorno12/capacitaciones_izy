{{-- Formulario para crear un curso o certificación del catálogo. --}}
@extends('layouts.app')

@section('title', 'Crear curso o certificación')
@section('header_title', 'Crear curso o certificación')

@section('content')
<div class="max-w-4xl mx-auto space-y-6">
    <div class="flex items-center justify-between">
        <div>
            <h2 class="text-xl font-bold text-[#1D3A6C]">Nuevo curso o certificación</h2>
            <p class="text-xs text-gray-500">Registra la información académica del catálogo. La programación de sesiones se gestiona posteriormente.</p>
        </div>
        <a href="{{ route('trainings.index') }}" class="text-xs font-semibold text-gray-600 hover:text-[#1D3A6C]">
            &larr; Volver al catálogo
        </a>
    </div>

    <div class="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
        <form action="{{ route('trainings.store') }}" method="POST" class="space-y-6">
            @csrf

            <!-- Identificación del curso -->
            <div>
                <label for="title" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Nombre del Curso o Certificación *</label>
                <input type="text" name="title" id="title" required value="{{ old('title') }}"
                    class="mt-1 w-full rounded-lg border-gray-300 shadow-sm focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 text-xs px-3 py-2.5 border"
                    placeholder="Ej. Taller avanzado de arquitectura Cloud con AWS y Kubernetes">
                @error('title')
                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                    <label for="course_type" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Curso o Certificación *</label>
                    <select name="course_type" id="course_type" required
                        class="mt-1 w-full rounded-lg border-gray-300 text-xs px-3 py-2 border">
                        <option value="">Selecciona el tipo...</option>
                        <option value="Curso" @selected(old('course_type') === 'Curso')>Curso</option>
                        <option value="Certificación" @selected(old('course_type') === 'Certificación')>Certificación</option>
                    </select>
                    @error('course_type') <p class="mt-1 text-xs text-red-600">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label for="training_provider" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Proveedor de Formación</label>
                    <input type="text" name="training_provider" id="training_provider" value="{{ old('training_provider') }}"
                        class="mt-1 w-full rounded-lg border-gray-300 text-xs px-3 py-2 border">
                </div>
                <div>
                    <label for="shopping_cart_project" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Proyecto Carrito de Compras</label>
                    <input type="text" name="shopping_cart_project" id="shopping_cart_project" value="{{ old('shopping_cart_project') }}"
                        class="mt-1 w-full rounded-lg border-gray-300 text-xs px-3 py-2 border">
                </div>
            </div>

            <!-- Categoría e intensidad horaria -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label for="category_id" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Categoría *</label>
                    <select name="category_id" id="category_id" required
                        class="mt-1 w-full rounded-lg border-gray-300 shadow-sm focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 text-xs px-3 py-2 border">
                        <option value="">Selecciona una categoría temática...</option>
                        @foreach($categories as $category)
                            <option value="{{ $category->id }}" {{ old('category_id') == $category->id ? 'selected' : '' }}>
                                {{ $category->name }}
                            </option>
                        @endforeach
                    </select>
                    @error('category_id')
                        <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label for="duration_hours" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Intensidad Horaria *</label>
                    <input type="number" name="duration_hours" id="duration_hours" min="1" max="500" required value="{{ old('duration_hours', 16) }}"
                        class="mt-1 w-full rounded-lg border-gray-300 shadow-sm focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 text-xs px-3 py-2 border">
                    @error('duration_hours')
                        <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                    @enderror
                </div>
            </div>

            <div>
                <label for="description" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Descripción *</label>
                <textarea name="description" id="description" rows="4" required
                    class="mt-1 w-full rounded-lg border-gray-300 shadow-sm focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 text-xs p-3 border"
                    placeholder="Describe el curso o certificación...">{{ old('description') }}</textarea>
                @error('description')
                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="syllabus" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Temario del Curso *</label>
                <textarea name="syllabus" id="syllabus" rows="4" required
                    class="mt-1 w-full rounded-lg border-gray-300 text-xs p-3 border">{{ old('syllabus') }}</textarea>
                @error('syllabus') <p class="mt-1 text-xs text-red-600">{{ $message }}</p> @enderror
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                    <label for="subtitles" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Subtítulos</label>
                    <textarea name="subtitles" id="subtitles" rows="3" class="mt-1 w-full rounded-lg border-gray-300 text-xs p-3 border">{{ old('subtitles') }}</textarea>
                </div>
                <div>
                    <label for="prerequisites" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Prerrequisitos</label>
                    <textarea name="prerequisites" id="prerequisites" rows="3" class="mt-1 w-full rounded-lg border-gray-300 text-xs p-3 border">{{ old('prerequisites') }}</textarea>
                </div>
                <div>
                    <label for="level" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Nivel</label>
                    <input type="text" name="level" id="level" value="{{ old('level') }}" class="mt-1 w-full rounded-lg border-gray-300 text-xs px-3 py-2 border">
                </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                @foreach([
                    'digital_badge' => 'Insignia Digital *',
                    'for_internal_staff' => 'Para Personal Interno *',
                    'for_external_staff' => 'Para Personal Externo *',
                ] as $field => $label)
                    <div>
                        <label for="{{ $field }}" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">{{ $label }}</label>
                        <select name="{{ $field }}" id="{{ $field }}" required class="mt-1 w-full rounded-lg border-gray-300 text-xs px-3 py-2 border">
                            <option value="">Selecciona...</option>
                            <option value="1" {{ old($field) === '1' ? 'selected' : '' }}>Sí</option>
                            <option value="0" {{ old($field) === '0' ? 'selected' : '' }}>No</option>
                        </select>
                        @error($field) <p class="mt-1 text-xs text-red-600">{{ $message }}</p> @enderror
                    </div>
                @endforeach
            </div>

            <div class="space-y-3 rounded-lg border border-gray-200 p-4">
                <div class="flex items-center">
                    <input type="hidden" name="has_certificate" value="0">
                    <input type="checkbox" name="has_certificate" id="has_certificate" value="1"
                        @checked(old('has_certificate')) class="h-4 w-4 rounded border-gray-300 text-[#19A885] focus:ring-[#19A885]">
                    <label for="has_certificate" class="ml-2 text-xs font-semibold text-gray-900">
                        Genera certificado oficial de aprobación
                    </label>
                </div>
                @error('has_certificate') <p class="text-xs text-red-600">{{ $message }}</p> @enderror
                <div>
                    <label for="certificate_template_url" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">URL de Plantilla del Certificado</label>
                    <input type="url" name="certificate_template_url" id="certificate_template_url" value="{{ old('certificate_template_url') }}"
                        class="mt-1 w-full rounded-lg border-gray-300 text-xs px-3 py-2 border">
                    @error('certificate_template_url') <p class="mt-1 text-xs text-red-600">{{ $message }}</p> @enderror
                </div>
            </div>

            <!-- Botones -->
            <div class="flex items-center justify-end gap-3 pt-4 border-t border-gray-100">
                <a href="{{ route('trainings.index') }}" class="px-4 py-2 text-xs font-semibold text-gray-600 hover:text-gray-800">
                    Cancelar
                </a>
                <button type="submit" class="px-6 py-2.5 bg-[#19A885] hover:bg-[#14866A] text-white text-xs font-bold rounded-lg shadow-sm transition-colors">
                    Guardar curso o certificación
                </button>
            </div>
        </form>
    </div>
</div>
@endsection

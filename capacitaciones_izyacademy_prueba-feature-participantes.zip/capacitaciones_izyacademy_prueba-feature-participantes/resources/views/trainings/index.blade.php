{{-- Listado administrativo de capacitaciones. --}}
{{-- Permite filtrar, cambiar la presentación y acceder a crear, ver, editar o eliminar. --}}
@extends('layouts.app')

@section('title', 'Catálogo de Capacitaciones')
@section('header_title', 'Catálogo de Capacitaciones Corporativas')

@section('content')
<div class="space-y-6" x-data="{
    viewMode: '{{ request('view', 'grid') }}',
    certificateModalOpen: false,
    selectedCertificateUrl: '',
    selectedTrainingTitle: '',
    openCertificate(url, title) {
        this.selectedCertificateUrl = url;
        this.selectedTrainingTitle = title;
        this.certificateModalOpen = true;
    }
}">

    <!-- Cabecera y Controles de Acción -->
    <div class="sm:flex sm:items-center sm:justify-between">
        <div>
            <h2 class="text-xl font-bold text-[#1D3A6C]">Programas de Capacitación</h2>
            <p class="text-xs text-gray-500 mt-1">Explora la oferta formativa institucional en tecnologías, metodologías y calidad.</p>
        </div>
        <div class="mt-4 flex flex-wrap items-center gap-3 sm:mt-0">
            <!-- Alternador Grid / Tabla -->
            <div class="inline-flex rounded-lg border border-gray-200 bg-white p-1 shadow-sm">
                <button type="button" @click="viewMode = 'grid'" :class="viewMode === 'grid' ? 'bg-[#1D3A6C] text-white' : 'text-gray-500 hover:text-gray-700'" class="px-2.5 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1.5 transition-colors">
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/>
                    </svg>
                    Cuadrícula
                </button>
                <button type="button" @click="viewMode = 'table'" :class="viewMode === 'table' ? 'bg-[#1D3A6C] text-white' : 'text-gray-500 hover:text-gray-700'" class="px-2.5 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1.5 transition-colors">
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 10h16M4 14h16M4 18h16"/>
                    </svg>
                    Tabla
                </button>
            </div>

            @hasPermission('trainings.manage')
            <a href="{{ route('trainings.create') }}" class="inline-flex items-center gap-2 px-4 py-2.5 bg-[#19A885] hover:bg-[#14866A] text-white text-xs font-bold rounded-lg shadow-sm transition-colors">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                </svg>
                Crear curso
            </a>
            @endhasPermission
            @hasPermission('trainings.import')
            <a href="{{ route('trainings.import') }}" class="inline-flex items-center gap-2 px-4 py-2.5 bg-white hover:bg-gray-50 text-[#1D3A6C] text-xs font-bold rounded-lg border border-[#1D3A6C] shadow-sm transition-colors">
                Importar Excel
            </a>
            @endhasPermission
            @hasPermission('trainings.export')
            <a href="{{ route('trainings.export') }}" class="inline-flex items-center gap-2 px-4 py-2.5 bg-white hover:bg-gray-50 text-[#1D3A6C] text-xs font-bold rounded-lg border border-gray-300 shadow-sm transition-colors">
                Exportar Excel
            </a>
            @endhasPermission
        </div>
    </div>

    <!-- Barra de Filtros y Búsqueda -->
    <div class="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
        <form method="GET" action="{{ route('trainings.index') }}" class="grid grid-cols-1 sm:grid-cols-12 gap-3">
            <input type="hidden" name="view" :value="viewMode">

            <!-- Buscador -->
            <div class="sm:col-span-6">
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                        </svg>
                    </div>
                    <label for="training-search" class="sr-only">Buscar capacitaciones por título, temática o facilitador</label>
                    <input id="training-search" type="text" name="search" value="{{ request('search') }}"
                        class="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-gray-300 focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20"
                        placeholder="Buscar por título, temática o facilitador...">
                </div>
            </div>

            <!-- Filtro por Categoría -->
            <div class="sm:col-span-4">
                <label for="training-category" class="sr-only">Filtrar capacitaciones por categoría</label>
                <select id="training-category" name="category_id" class="w-full py-2 px-3 text-xs rounded-lg border border-gray-300 focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20">
                    <option value="">Todas las Categorías</option>
                    @foreach($categories as $category)
                        <option value="{{ $category->id }}" {{ request('category_id') == $category->id ? 'selected' : '' }}>
                            {{ $category->name }}
                        </option>
                    @endforeach
                </select>
            </div>

            <!-- Botón Filtrar -->
            <div class="sm:col-span-2 flex gap-2">
                <button type="submit" class="flex-1 py-2 px-3 bg-[#1D3A6C] hover:bg-[#13274A] text-white text-xs font-semibold rounded-lg transition-colors">
                    Filtrar
                </button>
                @if(request()->anyFilled(['search', 'category_id']))
                    <a href="{{ route('trainings.index', ['view' => request('view', 'grid')]) }}" class="py-2 px-3 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-semibold rounded-lg transition-colors">
                        Limpiar
                    </a>
                @endif
            </div>
        </form>
    </div>

    <!-- 1. MODO CUADRÍCULA (GRID) -->
    <div x-show="viewMode === 'grid'" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        @forelse($trainings as $training)
            <div class="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between">
                <div>
                    <!-- Banner superior con categoría y visibilidad -->
                    <div class="p-5 pb-3 flex items-center justify-between">
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[#EBF3FC] text-[#0055AF]">
                            {{ $training->category->name }}
                        </span>

                        @if(!$training->is_available_for_externals)
                            <span class="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200" title="Solo visible para colaboradores internos">
                                🔒 Solo Internos
                            </span>
                        @else
                            <span class="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-700" title="Visible para clientes y aliados externos">
                                🌐 Pública
                            </span>
                        @endif
                    </div>

                    <div class="px-5">
                        <h3 class="text-base font-bold text-[#1D3A6C] leading-snug hover:text-[#0055AF]">
                            <a href="{{ route('trainings.show', $training) }}">{{ $training->title }}</a>
                        </h3>
                        <p class="mt-2 text-xs text-gray-600 line-clamp-3 leading-relaxed">
                            {{ $training->description }}
                        </p>

                        <!-- Datos del catálogo -->
                        <div class="mt-4 pt-4 border-t border-gray-100 space-y-1.5 text-xs text-gray-600">
                            <div class="flex items-center gap-2">
                                <svg class="w-4 h-4 text-gray-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                </svg>
                                <span>Tipo: <strong class="text-gray-900">{{ $training->course_type ?: 'No especificado' }}</strong></span>
                            </div>
                            <div class="flex items-start gap-2">
                                <svg class="w-4 h-4 text-gray-400 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                                </svg>
                                <span class="truncate">Proveedor: {{ $training->training_provider ?: 'No especificado' }}</span>
                            </div>
                            <div>
                                <span>Intensidad: <strong class="text-gray-900">{{ $training->duration_hours ?: 'No especificada' }}{{ $training->duration_hours ? ' horas' : '' }}</strong></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Footer de la Tarjeta -->
                <div class="px-5 py-4 bg-gray-50 border-t border-gray-100 mt-4 flex items-center justify-between">
                    <div class="text-xs font-medium text-gray-700">
                        {{ $training->for_internal_staff ? 'Personal interno' : '' }}{{ $training->for_internal_staff && $training->is_available_for_externals ? ' · ' : '' }}{{ $training->is_available_for_externals ? 'Personal externo' : '' }}
                    </div>

                    <div class="flex items-center gap-2">
                        @if($training->has_certificate)
                            <button type="button" @click="openCertificate('{{ asset('images/CertificadoIzyAcademy.png') }}', '{{ addslashes($training->title) }}')"
                                class="p-1.5 text-xs text-[#19A885] hover:bg-[#E8F6F3] rounded-lg transition-colors" title="Previsualizar Certificado Oficial">
                                🏅
                            </button>
                        @endif

                        <a href="{{ route('trainings.show', $training) }}" class="inline-flex items-center px-2.5 py-1 text-xs font-semibold text-white bg-[#19A885] hover:bg-[#14866A] rounded-lg transition-colors">
                            Detalles
                        </a>
                    </div>
                </div>
            </div>
        @empty
            <div class="col-span-3 bg-white p-12 text-center rounded-xl border border-gray-200">
                <p class="text-gray-500 text-sm">No se encontraron capacitaciones disponibles con los filtros aplicados.</p>
            </div>
        @endforelse
    </div>

    <!-- 2. MODO TABLA -->
    <div x-show="viewMode === 'table'" class="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden" style="display: none;">
        <div class="overflow-x-auto">
            <table class="responsive-table min-w-full divide-y divide-gray-200 text-left text-xs">
                <thead class="bg-[#F8FAFC] text-gray-600 uppercase font-semibold tracking-wider">
                    <tr>
                        <th class="px-6 py-3.5">Capacitación</th>
                        <th class="px-6 py-3.5">Categoría</th>
                        <th class="px-6 py-3.5">Proveedor</th>
                        <th class="px-6 py-3.5">Duración</th>
                        <th class="px-6 py-3.5">Alcance</th>
                        <th class="px-6 py-3.5">Certificado</th>
                        <th class="px-6 py-3.5 text-right">Acciones</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    @forelse($trainings as $training)
                        <tr class="hover:bg-gray-50/80 transition-colors">
                            <td class="px-6 py-4">
                                <a href="{{ route('trainings.show', $training) }}" class="font-bold text-[#1D3A6C] hover:underline block">
                                    {{ $training->title }}
                                </a>
                                <span class="text-gray-500 text-[11px] truncate block max-w-xs">{{ $training->course_type ?: 'Tipo no especificado' }}</span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[#EBF3FC] text-[#0055AF]">
                                    {{ $training->category->name }}
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center gap-2">
                                    <span>{{ $training->training_provider ?: 'No especificado' }}</span>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap font-medium text-gray-900">
                                {{ $training->duration_hours }} hrs
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                @if($training->is_available_for_externals)
                                    <span class="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded text-[11px] font-semibold">Pública</span>
                                @else
                                    <span class="text-amber-700 bg-amber-50 px-2 py-0.5 rounded text-[11px] font-semibold">Interna</span>
                                @endif
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                @if($training->has_certificate)
                                    <button type="button" @click="openCertificate('{{ asset('images/CertificadoIzyAcademy.png') }}', '{{ addslashes($training->title) }}')" class="text-xs text-[#19A885] font-semibold hover:underline">
                                        Previsualizar
                                    </button>
                                @else
                                    <span class="text-gray-400">Sin cert.</span>
                                @endif
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right space-x-2">
                                <a href="{{ route('trainings.show', $training) }}" class="text-xs font-semibold text-[#0055AF] hover:underline">Ver</a>
                                @hasPermission('trainings.manage')
                                    <a href="{{ route('trainings.edit', $training) }}" class="text-xs font-semibold text-gray-600 hover:underline">Editar</a>
                                @endhasPermission
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7" class="px-6 py-8 text-center text-gray-500 text-xs">
                                No se encontraron capacitaciones registradas.
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <!-- Paginación de Servidor -->
    @if($trainings->hasPages())
        <div class="px-6 py-4 bg-white rounded-xl border border-gray-200 shadow-sm">
            {{ $trainings->links() }}
        </div>
    @endif

    <!-- MODAL LIVIANO DE PREVISUALIZACIÓN DE CERTIFICADO -->
    <div x-show="certificateModalOpen" class="fixed inset-0 z-50 overflow-y-auto" style="display: none;"
        x-transition:enter="transition ease-out duration-200"
        x-transition:enter-start="opacity-0"
        x-transition:enter-end="opacity-100"
        x-transition:leave="transition ease-in duration-150"
        x-transition:leave-start="opacity-100"
        x-transition:leave-end="opacity-0">
        
        <!-- Backdrop -->
        <div class="fixed inset-0 bg-black/60 backdrop-blur-sm" @click="certificateModalOpen = false"></div>

        <div class="flex min-h-full items-center justify-center p-4">
            <div class="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl p-6 overflow-hidden" @click.away="certificateModalOpen = false">
                <div class="flex items-center justify-between pb-4 border-b border-gray-100">
                    <div class="flex items-center gap-2">
                        <span class="text-xl">🏅</span>
                        <h3 class="font-bold text-[#1D3A6C] text-sm sm:text-base"
                            x-text="selectedTrainingTitle || 'Certificado de capacitación'">Certificado de capacitación</h3>
                    </div>
                    <button @click="certificateModalOpen = false" class="text-gray-400 hover:text-gray-600 p-1 rounded-lg">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                        </svg>
                    </button>
                </div>

                <div class="mt-4 rounded-xl overflow-hidden border border-gray-200 bg-gray-100 flex items-center justify-center min-h-[300px]">
                    <img :src="selectedCertificateUrl" alt="Previsualización de Certificado" class="w-full h-auto object-contain max-h-[420px]" loading="lazy">
                </div>

                <div class="mt-4 flex items-center justify-between text-xs text-gray-500">
                    <span>Certificado oficial avalado por izyAcademy</span>
                    <button @click="certificateModalOpen = false" class="px-4 py-2 bg-[#1D3A6C] text-white rounded-lg font-semibold hover:bg-[#13274A] transition-colors">
                        Cerrar Ventana
                    </button>
                </div>
            </div>
        </div>
    </div>

</div>
@endsection

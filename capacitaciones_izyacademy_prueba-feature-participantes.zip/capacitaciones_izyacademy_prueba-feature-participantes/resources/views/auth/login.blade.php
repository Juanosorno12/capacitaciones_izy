{{-- Formulario de inicio de sesión. --}}
{{-- Envía email, contraseña y preferencia de recordar sesión al AuthController. --}}
@extends('layouts.guest')

@section('content')
<div class="bg-white py-8 px-6 shadow-xl rounded-2xl sm:px-10 border border-gray-100">
    <div class="mb-6">
        <h3 class="text-xl font-bold text-[#1D3A6C]">Iniciar Sesión</h3>
        <p class="text-sm text-gray-500">Ingresa con tus credenciales corporativas autorizadas.</p>
    </div>

    <a href="{{ route('home') }}" class="mb-5 inline-flex items-center gap-2 text-sm font-semibold text-[#0055AF] hover:text-[#003E80] hover:underline">
        <span aria-hidden="true">&larr;</span>
        Volver a la página de inicio
    </a>

    <form class="space-y-5" action="{{ route('login') }}" method="POST">
        @csrf

        <div>
            <label for="email" class="block text-sm font-medium text-gray-700">Correo Electrónico Corporativo</label>
            <div class="mt-1">
                <input id="email" name="email" type="email" autocomplete="email" required value="{{ old('email') }}"
                    class="w-full rounded-lg border-gray-300 shadow-sm focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 text-sm px-3 py-2.5 border"
                    placeholder="ejemplo@izyacademy.com">
            </div>
            @error('email')
                <p class="mt-1.5 text-xs text-red-600">{{ $message }}</p>
            @enderror
        </div>

        <div>
            <label for="password" class="block text-sm font-medium text-gray-700">Contraseña</label>
            <div class="mt-1">
                <input id="password" name="password" type="password" autocomplete="current-password" required
                    class="w-full rounded-lg border-gray-300 shadow-sm focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 text-sm px-3 py-2.5 border"
                    placeholder="••••••••">
            </div>
        </div>

        <div class="flex items-center justify-between">
            <div class="flex items-center">
                <input id="remember" name="remember" type="checkbox"
                    class="h-4 w-4 rounded border-gray-300 text-[#19A885] focus:ring-[#19A885]">
                <label for="remember" class="ml-2 block text-xs text-gray-600">Recordar sesión</label>
            </div>
        </div>

        <div>
            <button type="submit"
                class="w-full flex justify-center py-2.5 px-4 border border-transparent rounded-lg shadow-sm text-sm font-semibold text-white bg-[#19A885] hover:bg-[#14866A] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#19A885] transition duration-150">
                Acceder al Portal
            </button>
        </div>
    </form>

    <!-- Credenciales Demo para Pruebas Rápidas -->
    <div class="mt-8 pt-6 border-t border-gray-100">
        <p class="text-xs font-semibold uppercase tracking-wider text-gray-400 mb-3 text-center">Cuentas Demo Preconfiguradas</p>
        <div class="space-y-2 text-xs text-gray-600 bg-[#F8FAFC] p-3 rounded-lg border border-gray-200">
            <div class="flex justify-between items-center py-0.5">
                <span class="font-medium text-[#1D3A6C]">Administrador:</span>
                <code class="bg-gray-100 px-1.5 py-0.5 rounded text-[11px]">admin@izyacademy.com</code>
            </div>
            <div class="flex justify-between items-center py-0.5">
                <span class="font-medium text-[#1D3A6C]">Director/Líder QA:</span>
                <code class="bg-gray-100 px-1.5 py-0.5 rounded text-[11px]">lider.qa@izyacademy.com</code>
            </div>
            <div class="flex justify-between items-center py-0.5">
                <span class="font-medium text-[#1D3A6C]">Externo (Cliente):</span>
                <code class="bg-gray-100 px-1.5 py-0.5 rounded text-[11px]">externo.consultor@cliente.com</code>
            </div>
            <div class="text-center pt-1 border-t border-gray-200/60 text-gray-400">
                Contraseña universal: <strong class="text-gray-700">Password123!</strong>
            </div>
        </div>
    </div>
</div>
@endsection

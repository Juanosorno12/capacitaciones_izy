{{-- Formulario para editar un usuario existente. --}}
{{-- Permite modificar datos, rol, estado y opcionalmente la contraseña. --}}
@extends('layouts.app')

@section('title', 'Editar Usuario')
@section('header_title', 'Modificar Usuario Corporativo')

@section('content')
<div class="max-w-3xl mx-auto space-y-6">
    <div class="flex items-center justify-between">
        <div>
            <h2 class="text-xl font-bold text-[#1D3A6C]">Editar Usuario: {{ $user->name }}</h2>
            <p class="text-xs text-gray-500">Actualiza los datos personales, asignación de rol o estado de la cuenta.</p>
        </div>
        <a href="{{ route('users.index') }}" class="text-xs font-semibold text-gray-600 hover:text-[#1D3A6C]">
            &larr; Volver al listado
        </a>
    </div>

    @if($user->id === auth()->id())
        <div class="bg-blue-50 border-l-4 border-[#0055AF] p-4 text-xs text-blue-800 rounded-r-lg">
            <p class="font-semibold">Regla de Protección de Cuenta:</p>
            <p>Estás editando tu propia cuenta activa de Administrador. El sistema impedirá que desactives tu propio usuario para evitar bloqueos del sistema.</p>
        </div>
    @endif

    <div class="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
        <form action="{{ route('users.update', $user) }}" method="POST" enctype="multipart/form-data" class="space-y-5">
            @csrf
            @method('PUT')

            <!-- Nombre Completo -->
            <div>
                <label for="name" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Nombre Completo *</label>
                <input type="text" name="name" id="name" required value="{{ old('name', $user->name) }}"
                    class="mt-1 w-full rounded-lg border-gray-300 shadow-sm focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 text-xs px-3 py-2 border">
                @error('name')
                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <!-- Foto de perfil -->
            <div>
                <label for="profile_photo" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Foto de perfil</label>
                @if($user->profile_photo_url)
                    <img src="{{ $user->profile_photo_url }}" alt="Foto de perfil actual de {{ $user->name }}" class="mt-2 mb-3 w-16 h-16 rounded-full object-cover">
                @endif
                <input type="file" name="profile_photo" id="profile_photo" accept=".webp,image/webp"
                    class="mt-1 block w-full text-xs text-gray-600 file:mr-3 file:rounded-lg file:border-0 file:bg-[#EBF3FC] file:px-3 file:py-2 file:text-xs file:font-semibold file:text-[#1D3A6C] hover:file:bg-blue-100">
                <p class="mt-1 text-[11px] text-gray-500">Opcional. Selecciona una imagen WebP para reemplazar la actual. Tamaño máximo: 2 MB.</p>
                @error('profile_photo')
                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <!-- Correo Electrónico Corporativo -->
            <div>
                <label for="email" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Correo Electrónico *</label>
                <input type="email" name="email" id="email" required value="{{ old('email', $user->email) }}"
                    class="mt-1 w-full rounded-lg border-gray-300 shadow-sm focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 text-xs px-3 py-2 border">
                @error('email')
                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <!-- Rol Institucional -->
            <div>
                <label for="role_id" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Rol Institucional *</label>
                <select name="role_id" id="role_id" required
                    class="mt-1 w-full rounded-lg border-gray-300 shadow-sm focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 text-xs px-3 py-2 border">
                    @foreach($roles as $role)
                        <option value="{{ $role->id }}" {{ old('role_id', $user->role_id) == $role->id ? 'selected' : '' }}>
                            {{ $role->name }} &mdash; {{ $role->description }}
                        </option>
                    @endforeach
                </select>
                @error('role_id')
                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <!-- Contraseña Opcional (si se desea cambiar) -->
            <div class="pt-2 border-t border-gray-100">
                <p class="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Modificar Contraseña (Opcional)</p>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label for="password" class="block text-xs text-gray-600">Nueva Contraseña</label>
                        <input type="password" name="password" id="password"
                            class="mt-1 w-full rounded-lg border-gray-300 shadow-sm focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 text-xs px-3 py-2 border"
                            placeholder="Dejar en blanco para mantener la actual">
                        @error('password')
                            <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                        @enderror
                    </div>
                    <div>
                        <label for="password_confirmation" class="block text-xs text-gray-600">Confirmar Nueva Contraseña</label>
                        <input type="password" name="password_confirmation" id="password_confirmation"
                            class="mt-1 w-full rounded-lg border-gray-300 shadow-sm focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 text-xs px-3 py-2 border"
                            placeholder="Repite la nueva contraseña">
                    </div>
                </div>
            </div>

            <!-- Estado Activo -->
            <div class="flex items-center pt-2">
                <input type="checkbox" name="is_active" id="is_active" value="1"
                    {{ old('is_active', $user->is_active) ? 'checked' : '' }}
                    {{ $user->id === auth()->id() ? 'disabled' : '' }}
                    class="h-4 w-4 rounded border-gray-300 text-[#19A885] focus:ring-[#19A885]">
                <label for="is_active" class="ml-2 block text-xs font-medium text-gray-900">
                    Cuenta activa (Permite el inicio de sesión)
                </label>
                @if($user->id === auth()->id())
                    <input type="hidden" name="is_active" value="1">
                    <span class="ml-2 text-[11px] text-gray-400">(No puedes desactivar tu propia cuenta activa)</span>
                @endif
            </div>

            <!-- Botones -->
            <div class="flex items-center justify-end gap-3 pt-4 border-t border-gray-100">
                <a href="{{ route('users.index') }}" class="px-4 py-2 text-xs font-semibold text-gray-600 hover:text-gray-800">
                    Cancelar
                </a>
                <button type="submit" class="px-5 py-2.5 bg-[#19A885] hover:bg-[#14866A] text-white text-xs font-bold rounded-lg shadow-sm transition-colors">
                    Guardar Cambios
                </button>
            </div>
        </form>
    </div>
</div>
@endsection

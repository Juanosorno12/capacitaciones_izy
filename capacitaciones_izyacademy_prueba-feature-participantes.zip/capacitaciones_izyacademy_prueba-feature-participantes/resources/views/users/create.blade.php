{{-- Formulario para crear un usuario. --}}
{{-- Captura datos personales, rol, estado y contraseña con validación visual de requisitos. --}}
@extends('layouts.app')

@section('title', 'Nuevo Usuario')
@section('header_title', 'Crear Usuario Corporativo')

@section('content')
<div class="max-w-3xl mx-auto space-y-6">
    <div class="flex items-center justify-between">
        <div>
            <h2 class="text-xl font-bold text-[#1D3A6C]">Registrar Nuevo Usuario</h2>
            <p class="text-xs text-gray-500">Crea una cuenta corporativa y define su rol de acceso inicial.</p>
        </div>
        <a href="{{ route('users.index') }}" class="text-xs font-semibold text-gray-600 hover:text-[#1D3A6C]">
            &larr; Volver al listado
        </a>
    </div>

    <div class="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
        <form action="{{ route('users.store') }}" method="POST" enctype="multipart/form-data" class="space-y-5">
            @csrf

            <!-- Nombre Completo -->
            <div>
                <label for="name" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Nombre Completo *</label>
                <input type="text" name="name" id="name" required value="{{ old('name') }}"
                    class="mt-1 w-full rounded-lg border-gray-300 shadow-sm focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 text-xs px-3 py-2 border"
                    placeholder="Ej. Andrés Felipe Moreno">
                @error('name')
                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <!-- Foto de perfil -->
            <div>
                <label for="profile_photo" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Foto de perfil (opcional)</label>
                <input type="file" name="profile_photo" id="profile_photo" accept=".webp,image/webp"
                    class="mt-1 block w-full text-xs text-gray-600 file:mr-3 file:rounded-lg file:border-0 file:bg-[#EBF3FC] file:px-3 file:py-2 file:text-xs file:font-semibold file:text-[#1D3A6C] hover:file:bg-blue-100">
                <p class="mt-1 text-[11px] text-gray-500">Solo formato WebP. Tamaño máximo: 2 MB.</p>
                @error('profile_photo')
                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <!-- Correo Electrónico Corporativo -->
            <div>
                <label for="email" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Correo Electrónico *</label>
                <input type="email" name="email" id="email" required value="{{ old('email') }}"
                    class="mt-1 w-full rounded-lg border-gray-300 shadow-sm focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 text-xs px-3 py-2 border"
                    placeholder="andres.moreno@izyacademy.com">
                @error('email')
                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <!-- Rol Institucional -->
            <div>
                <label for="role_id" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Rol Institucional *</label>
                <select name="role_id" id="role_id" required
                    class="mt-1 w-full rounded-lg border-gray-300 shadow-sm focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 text-xs px-3 py-2 border">
                    <option value="">Selecciona un rol...</option>
                    @foreach($roles as $role)
                        <option value="{{ $role->id }}" {{ old('role_id') == $role->id ? 'selected' : '' }}>
                            {{ $role->name }} &mdash; {{ $role->description }}
                        </option>
                    @endforeach
                </select>
                @error('role_id')
                    <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <!-- Contraseñas -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label for="password" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Contraseña *</label>
                    <input type="password" name="password" id="password" required minlength="10" autocomplete="new-password"
                        class="mt-1 w-full rounded-lg border-gray-300 shadow-sm focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 text-xs px-3 py-2 border"
                        placeholder="Mínimo 10 caracteres">
                    <ul id="password-requirements" class="mt-2 space-y-1 text-[11px]" aria-live="polite">
                        <li data-password-rule="uppercase" class="flex items-center gap-2 text-gray-500">
                            <span data-rule-indicator class="w-4 text-center font-bold">○</span>
                            Al menos una letra mayúscula
                        </li>
                        <li data-password-rule="number" class="flex items-center gap-2 text-gray-500">
                            <span data-rule-indicator class="w-4 text-center font-bold">○</span>
                            Al menos un número
                        </li>
                        <li data-password-rule="special" class="flex items-center gap-2 text-gray-500">
                            <span data-rule-indicator class="w-4 text-center font-bold">○</span>
                            Al menos un carácter especial
                        </li>
                        <li data-password-rule="length" class="flex items-center gap-2 text-gray-500">
                            <span data-rule-indicator class="w-4 text-center font-bold">○</span>
                            Mínimo 10 caracteres
                        </li>
                    </ul>
                    @error('password')
                        <p class="mt-1 text-xs text-red-600">{{ $message }}</p>
                    @enderror
                </div>
                <div>
                    <label for="password_confirmation" class="block text-xs font-semibold text-gray-700 uppercase tracking-wider">Confirmar Contraseña *</label>
                    <input type="password" name="password_confirmation" id="password_confirmation" required
                        class="mt-1 w-full rounded-lg border-gray-300 shadow-sm focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 text-xs px-3 py-2 border"
                        placeholder="Repite la contraseña">
                </div>
            </div>

            <!-- Estado Activo -->
            <div class="flex items-center pt-2">
                <input type="checkbox" name="is_active" id="is_active" value="1" {{ old('is_active', true) ? 'checked' : '' }}
                    class="h-4 w-4 rounded border-gray-300 text-[#19A885] focus:ring-[#19A885]">
                <label for="is_active" class="ml-2 block text-xs font-medium text-gray-900">
                    Cuenta activa (Permite iniciar sesión en la plataforma)
                </label>
            </div>

            <!-- Botones -->
            <div class="flex items-center justify-end gap-3 pt-4 border-t border-gray-100">
                <a href="{{ route('users.index') }}" class="px-4 py-2 text-xs font-semibold text-gray-600 hover:text-gray-800">
                    Cancelar
                </a>
                <button type="submit" class="px-5 py-2.5 bg-[#19A885] hover:bg-[#14866A] text-white text-xs font-bold rounded-lg shadow-sm transition-colors">
                    Crear Usuario
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    (() => {
        const passwordInput = document.getElementById('password');
        const rules = {
            uppercase: (value) => /\p{Lu}/u.test(value),
            number: (value) => /\p{N}/u.test(value),
            special: (value) => /[^\p{L}\p{N}\s]/u.test(value),
            length: (value) => Array.from(value).length >= 10,
        };

        // Actualiza visualmente el cumplimiento de las reglas de contraseña.
        const updatePasswordRequirements = () => {
            Object.entries(rules).forEach(([name, isSatisfied]) => {
                const requirement = document.querySelector(`[data-password-rule="${name}"]`);
                const indicator = requirement.querySelector('[data-rule-indicator]');
                const satisfied = isSatisfied(passwordInput.value);

                requirement.classList.toggle('text-green-600', satisfied);
                requirement.classList.toggle('text-gray-500', !satisfied);
                indicator.textContent = satisfied ? '✓' : '○';
            });
        };

        passwordInput.addEventListener('input', updatePasswordRequirements);
        updatePasswordRequirements();
    })();
</script>
@endsection

{{-- Matriz de permisos directos de un usuario. --}}
{{-- Agrupa permisos por módulo y permite seleccionar o retirar accesos individuales. --}}
@extends('layouts.app')

@section('title', 'Matriz de Permisos')
@section('header_title', 'Checklist Dinámico de Permisos por Usuario')

@section('content')
<div class="space-y-6 max-w-6xl mx-auto">

    <!-- Header y Contexto del Usuario -->
    <div class="bg-white rounded-xl border border-gray-200 p-4 sm:p-6 shadow-sm flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div class="flex min-w-0 items-start gap-3 sm:items-center sm:gap-4">
            <div class="w-12 h-12 rounded-xl bg-[#1D3A6C] text-white flex items-center justify-center font-bold text-base shadow">
                {{ substr($user->name, 0, 2) }}
            </div>
            <div class="min-w-0">
                <div class="flex flex-wrap items-center gap-2">
                    <h2 class="break-words text-lg font-bold text-[#1D3A6C]">{{ $user->name }}</h2>
                    <span class="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[#E8F6F3] text-[#19A885]">
                        Rol: {{ $user->role?->name ?? 'Sin Rol' }}
                    </span>
                </div>
                <p class="break-words text-xs text-gray-500 mt-0.5">{{ $user->email }} &bull; Permisos adicionales asignados a esta persona</p>
            </div>
        </div>

        <a href="{{ route('users.index') }}" class="text-xs font-semibold text-gray-600 hover:text-[#1D3A6C] flex items-center gap-1">
            &larr; Volver al Directorio
        </a>
    </div>

    <!-- Banner Informativo de Roles vs Permisos Directos -->
    <div class="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200/80 rounded-xl p-4 text-xs text-blue-900 flex items-start gap-3 shadow-sm">
        <svg class="w-5 h-5 text-[#0055AF] flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
        </svg>
        <div>
            <p class="font-bold text-sm text-[#1D3A6C]">¿Qué puede hacer esta persona?</p>
            <p class="mt-1 leading-relaxed text-gray-700">
                Esta persona recibe los permisos de su rol. Aquí puedes marcar permisos adicionales para darle acceso a tareas específicas, sin cambiar su rol principal.
            </p>
        </div>
    </div>

    <!-- FORMULARIO DE CHECKLIST AGRUPADO POR MÓDULOS -->
    <form action="{{ route('users.permissions.sync', $user) }}" method="POST">
        @csrf
        @method('PUT')

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            @foreach($groupedPermissions as $moduleGroup => $permissionsList)
                <div class="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-sm flex flex-col" x-data="{
                    allChecked: false,
                    checkAll() {
                        const boxes = $el.closest('.module-card').querySelectorAll('input[type=checkbox]');
                        this.allChecked = !this.allChecked;
                        boxes.forEach(b => { if (!b.disabled) b.checked = this.allChecked; });
                    }
                }" class="module-card">
                    <!-- Cabecera del Módulo -->
                    <div class="px-5 py-3.5 bg-[#F8FAFC] border-b border-gray-200 flex items-center justify-between">
                        <div class="flex items-center gap-2">
                            <span class="w-2.5 h-2.5 rounded-full bg-[#19A885]"></span>
                            <h3 class="font-bold text-sm text-[#1D3A6C]">{{ $permissionsList->first()->display_module }}</h3>
                        </div>
                        <button type="button" @click="checkAll" class="text-[11px] font-semibold text-[#0055AF] hover:underline">
                            Marcar / Desmarcar todos
                        </button>
                    </div>

                    <!-- Lista de Checkboxes Granulares -->
                    <div class="p-5 space-y-4 flex-1 divide-y divide-gray-100">
                        @foreach($permissionsList as $permission)
                            @php
                                $isInheritedFromRole = in_array($permission->id, $rolePermissionIds);
                                $isDirectlyAssigned = in_array($permission->id, $directPermissionIds);
                                $isChecked = $isInheritedFromRole || $isDirectlyAssigned;
                                $isSelfAdminProtection = ($user->id === auth()->id() && $permission->name === 'users.manage');
                            @endphp
                            <div class="pt-3 first:pt-0 flex items-start justify-between gap-3">
                                <div class="flex items-start gap-3">
                                    <div class="flex items-center h-5">
                                        <input type="checkbox"
                                            id="perm_{{ $permission->id }}"
                                            name="permissions[]"
                                            value="{{ $permission->id }}"
                                            {{ $isChecked ? 'checked' : '' }}
                                            {{ $isSelfAdminProtection ? 'disabled' : '' }}
                                            class="h-4 w-4 rounded border-gray-300 text-[#19A885] focus:ring-[#19A885]">

                                        @if($isSelfAdminProtection)
                                            <!-- Hidden input so the value isn't lost on submission -->
                                            <input type="hidden" name="permissions[]" value="{{ $permission->id }}">
                                        @endif
                                    </div>
                                    <div>
                                        <label for="perm_{{ $permission->id }}" class="text-xs font-bold text-gray-900 cursor-pointer block">
                                            {{ $permission->display_name }}
                                        </label>
                                        <p class="text-[11px] text-gray-500 leading-normal mt-0.5">
                                            {{ $permission->description }}
                                        </p>
                                    </div>
                                </div>

                                <!-- Etiqueta de Origen del Permiso -->
                                <div class="flex-shrink-0">
                                    @if($isInheritedFromRole)
                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-[#EBF3FC] text-[#0055AF]" title="Heredado por pertenecer al rol {{ $user->role?->name }}">
                                            Heredado por Rol
                                        </span>
                                    @elseif($isDirectlyAssigned)
                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-[#FFF2EB] text-[#FF5F00]">
                                            Personalizado Directo
                                        </span>
                                    @endif
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            @endforeach
        </div>

        <!-- Barra Fija / Inferior de Guardado -->
        <div class="sticky bottom-4 z-10 mt-8 flex flex-col items-stretch gap-3 rounded-xl border border-gray-200 bg-white/95 p-4 shadow-xl backdrop-blur sm:flex-row sm:items-center sm:justify-between">
            <div class="text-xs text-gray-600">
                Recuerda que los cambios surten efecto de manera inmediata en la sesión del usuario.
            </div>
            <div class="flex items-center gap-3">
                <a href="{{ route('users.index') }}" class="px-4 py-2 text-xs font-semibold text-gray-600 hover:text-gray-800">
                    Cancelar
                </a>
                <button type="submit" class="px-6 py-2.5 bg-[#19A885] hover:bg-[#14866A] text-white text-xs font-bold rounded-lg shadow-sm transition-colors flex items-center gap-2">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                    </svg>
                    Guardar Matriz de Permisos
                </button>
            </div>
        </div>
    </form>
</div>
@endsection

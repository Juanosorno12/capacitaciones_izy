{{-- Administración del directorio de usuarios. --}}
{{-- Permite consultar, buscar, crear y editar usuarios según los permisos disponibles. --}}
@extends('layouts.app')

@section('title', 'Directorio de Usuarios')
@section('header_title', 'Administración de Usuarios y Roles')

@section('content')
<div class="space-y-6">

    <!-- Header con Botón de Creación -->
    <div class="sm:flex sm:items-center sm:justify-between">
        <div>
            <h2 class="text-xl font-bold text-[#1D3A6C]">Directorio de Usuarios</h2>
            <p class="text-xs text-gray-500 mt-1">Control de cuentas de acceso, roles institucionales y personalización de permisos.</p>
        </div>
        @hasPermission('users.manage')
        <div class="mt-4 sm:mt-0">
            <a href="{{ route('users.create') }}" class="inline-flex items-center gap-2 px-4 py-2.5 bg-[#19A885] hover:bg-[#14866A] text-white text-xs font-bold rounded-lg shadow-sm transition-colors">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                </svg>
                Nuevo Usuario
            </a>
        </div>
        @endhasPermission
    </div>

    <!-- Barra de Búsqueda y Filtros de Servidor -->
    <div class="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
        <form method="GET" action="{{ route('users.index') }}" class="grid grid-cols-1 sm:grid-cols-12 gap-3">
            <!-- Buscar por Nombre o Email -->
            <div class="sm:col-span-5">
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                        </svg>
                    </div>
                    <label for="user-search" class="sr-only">Buscar usuarios por nombre o correo corporativo</label>
                    <input id="user-search" type="text" name="search" value="{{ request('search') }}"
                        class="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-gray-300 focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20"
                        placeholder="Buscar por nombre o correo corporativo...">
                </div>
            </div>

            <!-- Filtro por Rol -->
            <div class="sm:col-span-3">
                <label for="user-role" class="sr-only">Filtrar usuarios por rol</label>
                <select id="user-role" name="role_id" class="w-full py-2 px-3 text-xs rounded-lg border border-gray-300 focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20">
                    <option value="">Todos los Roles</option>
                    @foreach($roles as $role)
                        <option value="{{ $role->id }}" {{ request('role_id') == $role->id ? 'selected' : '' }}>
                            {{ $role->name }}
                        </option>
                    @endforeach
                </select>
            </div>

            <!-- Filtro por Estado -->
            <div class="sm:col-span-2">
                <label for="user-status" class="sr-only">Filtrar usuarios por estado</label>
                <select id="user-status" name="is_active" class="w-full py-2 px-3 text-xs rounded-lg border border-gray-300 focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20">
                    <option value="">Todos los Estados</option>
                    <option value="1" {{ request('is_active') === '1' ? 'selected' : '' }}>Activo</option>
                    <option value="0" {{ request('is_active') === '0' ? 'selected' : '' }}>Inactivo</option>
                </select>
            </div>

            <!-- Botones de Acción -->
            <div class="sm:col-span-2 flex gap-2">
                <button type="submit" class="flex-1 py-2 px-3 bg-[#1D3A6C] hover:bg-[#13274A] text-white text-xs font-semibold rounded-lg transition-colors">
                    Filtrar
                </button>
                @if(request()->anyFilled(['search', 'role_id', 'is_active']))
                    <a href="{{ route('users.index') }}" class="py-2 px-3 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-semibold rounded-lg transition-colors">
                        Limpiar
                    </a>
                @endif
            </div>
        </form>
    </div>

    <!-- Tabla Paginada de Usuarios -->
    <div class="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
            <table class="responsive-table min-w-full divide-y divide-gray-200 text-left text-xs">
                <thead class="bg-[#F8FAFC] text-gray-600 uppercase font-semibold tracking-wider">
                    <tr>
                        <th class="px-6 py-3.5">Colaborador</th>
                        <th class="px-6 py-3.5">Rol Institucional</th>
                        <th class="px-6 py-3.5">Estado</th>
                        <th class="px-6 py-3.5">Permisos Específicos</th>
                        <th class="px-6 py-3.5 text-right">Acciones</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    @forelse($users as $user)
                        <tr class="hover:bg-gray-50/80 transition-colors">
                            <!-- Colaborador -->
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center gap-3">
                                    @if($user->profile_photo_url)
                                        <img src="{{ $user->profile_photo_url }}" alt="Foto de perfil de {{ $user->name }}" class="w-8 h-8 rounded-full object-cover">
                                    @else
                                        <div class="w-8 h-8 rounded-full bg-[#1D3A6C] text-white flex items-center justify-center font-bold text-xs">
                                            {{ substr($user->name, 0, 2) }}
                                        </div>
                                    @endif
                                    <div>
                                        <p class="font-semibold text-gray-900">{{ $user->name }}</p>
                                        <p class="text-gray-500 text-[11px]">{{ $user->email }}</p>
                                    </div>
                                </div>
                            </td>

                            <!-- Rol -->
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold
                                    {{ $user->role?->slug === 'administrador' ? 'bg-[#EBF3FC] text-[#0055AF]' : '' }}
                                    {{ $user->role?->slug === 'directores-y-lideres' ? 'bg-[#E8F6F3] text-[#19A885]' : '' }}
                                    {{ $user->role?->slug === 'externos' ? 'bg-[#FFF2EB] text-[#FF5F00]' : '' }}">
                                    {{ $user->role?->name ?? 'Sin Rol' }}
                                </span>
                            </td>

                            <!-- Estado -->
                            <td class="px-6 py-4 whitespace-nowrap">
                                @if($user->is_active)
                                    <span class="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700">
                                        <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Activo
                                    </span>
                                @else
                                    <span class="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-red-50 text-red-600">
                                        <span class="w-1.5 h-1.5 rounded-full bg-red-500"></span> Inactivo
                                    </span>
                                @endif
                            </td>

                            <!-- Permisos Granulares Directos -->
                            <td class="px-6 py-4 whitespace-nowrap">
                                @if($user->directPermissions->count() > 0)
                                    <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-[#FFF2EB] text-[#D95100]">
                                        +{{ $user->directPermissions->count() }} directos
                                    </span>
                                @else
                                    <span class="text-gray-400 text-xs">Heredados del rol</span>
                                @endif
                            </td>

                            <!-- Acciones -->
                            <td class="px-6 py-4 whitespace-nowrap text-right space-x-2">
                                @hasPermission('users.permissions')
                                    <a href="{{ route('users.permissions', $user) }}" class="inline-flex items-center px-2.5 py-1 text-xs font-semibold text-[#FF5F00] bg-[#FFF2EB] hover:bg-[#FF5F00] hover:text-white rounded transition-colors" title="Matriz de Permisos">
                                        Checklist Permisos
                                    </a>
                                @endhasPermission

                                @hasPermission('users.manage')
                                    <a href="{{ route('users.edit', $user) }}" class="inline-flex items-center px-2.5 py-1 text-xs font-semibold text-[#0055AF] bg-[#EBF3FC] hover:bg-[#0055AF] hover:text-white rounded transition-colors">
                                        Editar
                                    </a>
                                @endhasPermission
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="px-6 py-8 text-center text-gray-500 text-xs">
                                No se encontraron usuarios con los criterios de búsqueda seleccionados.
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <!-- Paginación en Servidor -->
        @if($users->hasPages())
            <div class="px-6 py-4 border-t border-gray-200 bg-[#F8FAFC]">
                {{ $users->links() }}
            </div>
        @endif
    </div>

</div>
@endsection

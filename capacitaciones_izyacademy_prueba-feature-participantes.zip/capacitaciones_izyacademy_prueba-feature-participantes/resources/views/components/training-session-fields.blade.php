{{-- Componente reutilizable para capturar fechas y horarios de sesiones. --}}
{{-- Usa sesiones antiguas o existentes, calcula duraciones y permite agregar o eliminar filas. --}}
@props(['sessions' => []])

@php
    $sessionRows = old('sessions', $sessions);
    if (!is_array($sessionRows) || $sessionRows === []) {
        $sessionRows = [['session_date' => '', 'start_time' => '', 'end_time' => '']];
    }
@endphp

<section class="space-y-4 rounded-xl border border-gray-200 p-4" data-session-editor>
    <div class="flex flex-wrap items-center justify-between gap-3">
        <div>
            <h3 class="text-sm font-bold text-[#1D3A6C]">Fechas y horarios de las sesiones *</h3>
            <p class="text-[11px] text-gray-500">Agrega cada fecha de la capacitación. Los horarios usan la zona horaria {{ config('app.timezone') }}.</p>
        </div>
        <button type="button" data-add-session class="rounded-lg border border-[#0055AF]/30 px-3 py-2 text-xs font-semibold text-[#0055AF] hover:bg-[#EBF3FC]">
            + Agregar sesión
        </button>
    </div>

    @error('sessions')
        <p class="text-xs text-red-600">{{ $message }}</p>
    @enderror

    <div class="space-y-3" data-session-list>
        @foreach($sessionRows as $index => $session)
            @php
                $sessionDate = is_array($session) ? ($session['session_date'] ?? '') : ($session->session_date?->format('Y-m-d') ?? '');
                $startTime = is_array($session) ? ($session['start_time'] ?? '') : substr((string) $session->start_time, 0, 5);
                $endTime = is_array($session) ? ($session['end_time'] ?? '') : substr((string) $session->end_time, 0, 5);
                $durationMinutes = $startTime !== '' && $endTime !== ''
                    ? (int) ((strtotime($endTime) - strtotime($startTime)) / 60)
                    : 0;
                $durationOption = $endTime === ''
                    ? '60'
                    : (in_array($durationMinutes, [30, 60, 120], true) ? (string) $durationMinutes : 'custom');
            @endphp
            <div class="grid grid-cols-1 items-end gap-3 rounded-lg bg-gray-50 p-3 sm:grid-cols-2 xl:grid-cols-5" data-session-row>
                <div>
                    <label for="session-date-{{ $index }}" class="block text-xs font-medium text-gray-700">Fecha *</label>
                    <input id="session-date-{{ $index }}" type="date" name="sessions[{{ $index }}][session_date]" value="{{ $sessionDate }}" required data-session-field="session_date"
                        class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-xs focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20">
                    @error("sessions.$index.session_date")<p class="mt-1 text-xs text-red-600">{{ $message }}</p>@enderror
                </div>
                <div>
                    <label for="session-start-{{ $index }}" class="block text-xs font-medium text-gray-700">Hora de inicio *</label>
                    <input id="session-start-{{ $index }}" type="time" name="sessions[{{ $index }}][start_time]" value="{{ $startTime }}" required data-session-field="start_time"
                        class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-xs focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20">
                    @error("sessions.$index.start_time")<p class="mt-1 text-xs text-red-600">{{ $message }}</p>@enderror
                </div>
                <div>
                    <label for="session-duration-{{ $index }}" class="block text-xs font-medium text-gray-700">Duración de sesión *</label>
                    <select id="session-duration-{{ $index }}" data-session-duration required
                        class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-xs focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20">
                        <option value="30" {{ $durationOption === '30' ? 'selected' : '' }}>30 minutos</option>
                        <option value="60" {{ $durationOption === '60' ? 'selected' : '' }}>1 hora</option>
                        <option value="120" {{ $durationOption === '120' ? 'selected' : '' }}>2 horas</option>
                        <option value="custom" {{ $durationOption === 'custom' ? 'selected' : '' }}>Personalizada</option>
                    </select>
                </div>
                <div>
                    <label for="session-end-{{ $index }}" class="block text-xs font-medium text-gray-700">Hora de finalización *</label>
                    <input id="session-end-{{ $index }}" type="time" name="sessions[{{ $index }}][end_time]" value="{{ $endTime }}" required data-session-field="end_time" {{ $durationOption !== 'custom' ? 'readonly' : '' }}
                        class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-xs focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 read-only:bg-gray-100 read-only:text-gray-600">
                    @error("sessions.$index.end_time")<p class="mt-1 text-xs text-red-600">{{ $message }}</p>@enderror
                </div>
                <button type="button" data-remove-session class="mb-1 rounded-lg px-3 py-2 text-xs font-semibold text-red-600 hover:bg-red-50">
                    Eliminar sesión
                </button>
            </div>
        @endforeach
    </div>
</section>

@once
    <template id="training-session-template">
        <div class="grid grid-cols-1 items-end gap-3 rounded-lg bg-gray-50 p-3 sm:grid-cols-2 xl:grid-cols-5" data-session-row>
            <div>
                <label for="session-date-__INDEX__" class="block text-xs font-medium text-gray-700">Fecha *</label>
                <input id="session-date-__INDEX__" type="date" name="sessions[__INDEX__][session_date]" required data-session-field="session_date"
                    class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-xs focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20">
            </div>
            <div>
                <label for="session-start-__INDEX__" class="block text-xs font-medium text-gray-700">Hora de inicio *</label>
                <input id="session-start-__INDEX__" type="time" name="sessions[__INDEX__][start_time]" required data-session-field="start_time"
                    class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-xs focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20">
            </div>
            <div>
                <label for="session-duration-__INDEX__" class="block text-xs font-medium text-gray-700">Duración de sesión *</label>
                <select id="session-duration-__INDEX__" data-session-duration required
                    class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-xs focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20">
                    <option value="30">30 minutos</option>
                    <option value="60" selected>1 hora</option>
                    <option value="120">2 horas</option>
                    <option value="custom">Personalizada</option>
                </select>
            </div>
            <div>
                <label for="session-end-__INDEX__" class="block text-xs font-medium text-gray-700">Hora de finalización *</label>
                <input id="session-end-__INDEX__" type="time" name="sessions[__INDEX__][end_time]" required data-session-field="end_time" readonly
                    class="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-xs focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20 read-only:bg-gray-100 read-only:text-gray-600">
            </div>
            <button type="button" data-remove-session class="mb-1 rounded-lg px-3 py-2 text-xs font-semibold text-red-600 hover:bg-red-50">
                Eliminar sesión
            </button>
        </div>
    </template>
@endonce

@push('scripts')
    <script>
        document.querySelectorAll('[data-session-editor]').forEach((editor) => {
            const list = editor.querySelector('[data-session-list]');
            const template = document.getElementById('training-session-template');
            let nextIndex = Array.from(list.querySelectorAll('[data-session-field]')).reduce((next, field) => {
                const match = field.name.match(/^sessions\[(\d+)\]/);
                return match ? Math.max(next, Number(match[1]) + 1) : next;
            }, 0);

            // Habilita el botón de eliminar solo cuando existe más de una sesión.
            const updateRows = () => {
                const rows = list.querySelectorAll('[data-session-row]');
                rows.forEach((row) => {
                    row.querySelector('[data-remove-session]').disabled = rows.length === 1;
                });
            };

            // Calcula la hora final según la duración elegida y valida medianoche.
            const updateEndTime = (row) => {
                const duration = row.querySelector('[data-session-duration]');
                const start = row.querySelector('[data-session-field="start_time"]');
                const end = row.querySelector('[data-session-field="end_time"]');
                const custom = duration.value === 'custom';

                end.readOnly = !custom;
                duration.setCustomValidity('');
                if (custom || !start.value) {
                    return;
                }

                const [hours, minutes] = start.value.split(':').map(Number);
                const endMinutes = hours * 60 + minutes + Number(duration.value);
                if (endMinutes >= 1440) {
                    end.value = '';
                    duration.setCustomValidity('La duración seleccionada termina después de la medianoche. Elige una menor o personaliza el horario.');
                    return;
                }

                end.value = `${String(Math.floor(endMinutes / 60)).padStart(2, '0')}:${String(endMinutes % 60).padStart(2, '0')}`;
            };

            list.querySelectorAll('[data-session-row]').forEach((row) => {
                row.querySelector('[data-session-duration]').addEventListener('change', () => updateEndTime(row));
                row.querySelector('[data-session-field="start_time"]').addEventListener('change', () => updateEndTime(row));
                updateEndTime(row);
            });

            // Clona la plantilla, asigna un índice único y agrega una nueva sesión.
            editor.querySelector('[data-add-session]').addEventListener('click', () => {
                const row = template.content.cloneNode(true);
                row.querySelectorAll('[name]').forEach((field) => {
                    field.name = field.name.replace('__INDEX__', nextIndex);
                });
                row.querySelectorAll('[id]').forEach((field) => {
                    field.id = field.id.replace('__INDEX__', nextIndex);
                });
                row.querySelectorAll('label[for]').forEach((label) => {
                    label.htmlFor = label.htmlFor.replace('__INDEX__', nextIndex);
                });
                nextIndex += 1;
                const newRow = row.querySelector('[data-session-row]');
                newRow.querySelector('[data-session-duration]').addEventListener('change', () => updateEndTime(newRow));
                newRow.querySelector('[data-session-field="start_time"]').addEventListener('change', () => updateEndTime(newRow));
                list.appendChild(row);
                updateRows();
            });

            // Elimina la fila seleccionada sin permitir dejar el formulario vacío.
            list.addEventListener('click', (event) => {
                const removeButton = event.target.closest('[data-remove-session]');
                if (removeButton && list.querySelectorAll('[data-session-row]').length > 1) {
                    removeButton.closest('[data-session-row]').remove();
                    updateRows();
                }
            });

            updateRows();
        });
    </script>
@endpush

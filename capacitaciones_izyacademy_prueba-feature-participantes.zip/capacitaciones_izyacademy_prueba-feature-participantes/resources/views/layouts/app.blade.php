{{-- Plantilla principal del área autenticada. --}}
{{-- Renderiza navegación, menú según permisos, alertas de sesión, errores y contenido. --}}
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="min-h-full bg-[#F8FAFC]">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Portal') - {{ config('branding.app_name', 'IzyCapacitaciones') }}</title>

    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <style>
        .sidebar-scrollbar {
            scrollbar-color: #2a5298 #1d3a6c;
            scrollbar-width: thin;
        }

        .sidebar-scrollbar::-webkit-scrollbar {
            width: 10px;
        }

        .sidebar-scrollbar::-webkit-scrollbar-track {
            background: #1d3a6c;
        }

        .sidebar-scrollbar::-webkit-scrollbar-thumb {
            background: #2a5298;
            border: 2px solid #1d3a6c;
            border-radius: 9999px;
        }
    </style>
    @stack('styles')
</head>
<body class="min-h-screen overflow-x-hidden overflow-y-auto font-sans antialiased text-[#111111]" x-data="{ mobileMenuOpen: false }" @keydown.escape.window="mobileMenuOpen = false">
    <div class="min-h-full flex">
        
        <!-- SIDEBAR PARA DESKTOP -->
        <div class="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0 bg-[#1D3A6C] text-white shadow-xl z-30">
            <!-- Brand Logo Header -->
            <div class="flex h-36 w-full items-center justify-center overflow-hidden bg-[#13274A] border-b border-white/10">
                <img src="{{ asset('images/miniaturaIzy.png') }}" alt="izyAcademy" class="block h-full w-full object-contain" style="transform: scale(1.5); transform-origin: center;">
            </div>

            <!-- Navegación con Renderizado Condicional por Permisos -->
            <div class="sidebar-scrollbar flex-1 flex flex-col justify-between overflow-y-auto px-4 py-6 space-y-6">
                <nav class="space-y-1">
                    <p class="px-3 text-[11px] font-semibold text-white/40 uppercase tracking-wider mb-2">Plataforma</p>

                    <!-- Inicio / Dashboard -->
                    <a href="{{ route('dashboard') }}" class="flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-lg transition-colors {{ request()->routeIs('dashboard') ? 'bg-white/15 text-white font-semibold' : 'text-white/80 hover:bg-white/10 hover:text-white' }}">
                        <svg class="w-5 h-5 text-[#19A885]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
                        </svg>
                        Dashboard
                    </a>

                    <!-- Módulo Capacitaciones -->
                    @hasPermission('trainings.view')
                    <a href="{{ route('trainings.index') }}" class="flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-lg transition-colors {{ request()->routeIs('trainings.*') ? 'bg-white/15 text-white font-semibold' : 'text-white/80 hover:bg-white/10 hover:text-white' }}">
                        <svg class="w-5 h-5 text-blue-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
                        </svg>
                        Capacitaciones
                    </a>
                    @endhasPermission

                    @if(auth()->user()?->hasRole(\App\Models\Role::SLUG_ADMIN) && auth()->user()?->hasPermissionTo('audit-logs.view'))
                    <a href="{{ route('audit-logs.index') }}" class="flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-lg transition-colors {{ request()->routeIs('audit-logs.*') ? 'bg-white/15 text-white font-semibold' : 'text-white/80 hover:bg-white/10 hover:text-white' }}">
                        <svg class="w-5 h-5 text-amber-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 012-2V5a2 2 0 012-2h5.586l5.414 5.414V19a2 2 0 01-2 2z"/>
                        </svg>
                        Auditoría
                    </a>
                    @endif

                    <!-- Módulo Solicitudes -->
                    @hasPermission('requests.view')
                    <a href="{{ route('requests.index') }}" class="flex items-center justify-between px-3 py-2.5 text-sm font-medium rounded-lg transition-colors {{ request()->routeIs('requests.*') ? 'bg-white/15 text-white font-semibold' : 'text-white/80 hover:bg-white/10 hover:text-white' }}">
                        <div class="flex items-center gap-3">
                            <svg class="w-5 h-5 text-[#FF5F00]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                            </svg>
                            Solicitudes
                        </div>
                    </a>
                    @endhasPermission

                    <!-- Módulo Reportes -->
                    @hasPermission('reports.view')
                    <a href="{{ route('reports.index') }}" class="flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-lg transition-colors {{ request()->routeIs('reports.*') ? 'bg-white/15 text-white font-semibold' : 'text-white/80 hover:bg-white/10 hover:text-white' }}">
                        <svg class="w-5 h-5 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
                        </svg>
                        Reportes & Analítica
                    </a>
                    @endhasPermission

                    <!-- Módulo Administración: Usuarios y Matriz -->
                    @hasPermission('users.view')
                    <p class="px-3 text-[11px] font-semibold text-white/40 uppercase tracking-wider pt-4 mb-2">Administración</p>
                    <a href="{{ route('users.index') }}" class="flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-lg transition-colors {{ request()->routeIs('users.*') ? 'bg-white/15 text-white font-semibold' : 'text-white/80 hover:bg-white/10 hover:text-white' }}">
                        <svg class="w-5 h-5 text-indigo-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
                        </svg>
                        Usuarios & Permisos
                    </a>
                    @endhasPermission

                    @if(auth()->user()->hasRole(\App\Models\Role::SLUG_ADMIN))
                    <a href="{{ route('calendar.index') }}" class="flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-lg transition-colors {{ request()->routeIs('calendar.*') ? 'bg-white/15 text-white font-semibold' : 'text-white/80 hover:bg-white/10 hover:text-white' }}">
                        <svg class="w-5 h-5 text-[#FF5F00]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3M4 11h16M5 5h14a1 1 0 011 1v13a1 1 0 01-1 1H5a1 1 0 01-1-1V6a1 1 0 011-1z"/>
                        </svg>
                        Calendario
                    </a>
                    @hasPermission('participants.view')
                    <a href="{{ route('participants.index') }}" class="flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-lg transition-colors {{ request()->routeIs('participants.*') ? 'bg-white/15 text-white font-semibold' : 'text-white/80 hover:bg-white/10 hover:text-white' }}">
                        <svg class="w-5 h-5 text-[#19A885]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                        </svg>
                        Participantes
                    </a>
                    @endhasPermission
                    @endif
                </nav>

                <!-- User profile snippet in sidebar footer -->
                <div class="pt-4 border-t border-white/10">
                    <a href="{{ route('users.edit', auth()->user()) }}"
                        class="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-white/10 transition-colors group"
                        title="Editar mi perfil">
                        @if(auth()->user()->profile_photo_url)
                            <img src="{{ auth()->user()->profile_photo_url }}" alt="Foto de perfil de {{ auth()->user()->name }}" class="w-10 h-10 rounded-full object-cover shadow">
                        @else
                            <div class="w-10 h-10 rounded-full bg-[#19A885] flex items-center justify-center font-bold text-white text-sm shadow">
                                {{ substr(auth()->user()->name, 0, 2) }}
                            </div>
                        @endif
                        <div class="flex-1 min-w-0">
                            <p class="text-sm font-medium text-white truncate">{{ auth()->user()->name }}</p>
                            <span class="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-medium bg-white/20 text-white/90">
                                {{ auth()->user()->role?->name ?? 'Usuario' }}
                            </span>
                        </div>
                        <svg class="w-4 h-4 text-white/40 group-hover:text-white/80 transition-colors flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536M4 20h4l10.768-10.768a2.5 2.5 0 00-3.536-3.536L4.464 16.464A2 2 0 004 17.879V20z"/>
                        </svg>
                    </a>
                </div>
            </div>
        </div>

        <div x-cloak x-show="mobileMenuOpen" class="fixed inset-0 z-40 lg:hidden" role="dialog" aria-modal="true" aria-label="Menú principal">
            <div class="absolute inset-0 bg-gray-900/50" @click="mobileMenuOpen = false"></div>
            <aside x-show="mobileMenuOpen" x-transition:enter="transition ease-out duration-200"
                x-transition:enter-start="-translate-x-full" x-transition:enter-end="translate-x-0"
                x-transition:leave="transition ease-in duration-150" x-transition:leave-start="translate-x-0"
                x-transition:leave-end="-translate-x-full"
                class="relative flex h-full w-[min(18rem,85vw)] flex-col bg-[#1D3A6C] text-white shadow-xl">
                <div class="flex items-center justify-between border-b border-white/10 bg-[#13274A] px-4 py-3">
                    <img src="{{ asset('images/miniaturaIzy.png') }}" alt="izyAcademy" class="h-10 w-auto object-contain">
                    <button type="button" @click="mobileMenuOpen = false" class="rounded-lg p-2 text-white/80 hover:bg-white/10 hover:text-white" aria-label="Cerrar menú">
                        <svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                        </svg>
                    </button>
                </div>
                <nav class="flex-1 space-y-1 overflow-y-auto px-4 py-6">
                    <p class="mb-2 px-3 text-[11px] font-semibold uppercase tracking-wider text-white/40">Plataforma</p>
                    <a @click="mobileMenuOpen = false" href="{{ route('dashboard') }}" class="flex items-center rounded-lg px-3 py-3 text-sm font-medium text-white/90 hover:bg-white/10">Dashboard</a>
                    @hasPermission('trainings.view')
                    <a @click="mobileMenuOpen = false" href="{{ route('trainings.index') }}" class="flex items-center rounded-lg px-3 py-3 text-sm font-medium text-white/90 hover:bg-white/10">Capacitaciones</a>
                    @endhasPermission
                    @hasPermission('requests.view')
                    <a @click="mobileMenuOpen = false" href="{{ route('requests.index') }}" class="flex items-center rounded-lg px-3 py-3 text-sm font-medium text-white/90 hover:bg-white/10">Solicitudes</a>
                    @endhasPermission
                    @hasPermission('reports.view')
                    <a @click="mobileMenuOpen = false" href="{{ route('reports.index') }}" class="flex items-center rounded-lg px-3 py-3 text-sm font-medium text-white/90 hover:bg-white/10">Reportes y analítica</a>
                    @endhasPermission
                    @hasPermission('users.view')
                    <p class="mb-2 mt-5 px-3 text-[11px] font-semibold uppercase tracking-wider text-white/40">Administración</p>
                    <a @click="mobileMenuOpen = false" href="{{ route('users.index') }}" class="flex items-center rounded-lg px-3 py-3 text-sm font-medium text-white/90 hover:bg-white/10">Usuarios y permisos</a>
                    @endhasPermission
                    @if(auth()->user()->hasRole(\App\Models\Role::SLUG_ADMIN))
                    <a @click="mobileMenuOpen = false" href="{{ route('calendar.index') }}" class="flex items-center rounded-lg px-3 py-3 text-sm font-medium text-white/90 hover:bg-white/10">Calendario</a>
                    @hasPermission('participants.view')
                    <a @click="mobileMenuOpen = false" href="{{ route('participants.index') }}" class="flex items-center rounded-lg px-3 py-3 text-sm font-medium text-white/90 hover:bg-white/10">Participantes</a>
                    @endhasPermission
                    @endif
                </nav>
                <a href="{{ route('users.edit', auth()->user()) }}" class="border-t border-white/10 px-6 py-4 text-sm font-medium text-white/90 hover:bg-white/10">
                    Editar mi perfil
                </a>
            </aside>
        </div>

        <!-- MAIN CONTENT AREA -->
        <div class="lg:pl-64 flex flex-col flex-1 min-w-0">
            
            <!-- TOP NAVBAR -->
            <header class="bg-white border-b border-gray-200 sticky top-0 z-20 shadow-sm">
                <div class="flex items-center justify-between h-16 px-4 sm:px-6 lg:px-8">
                    <!-- Mobile Hamburger -->
                    <div class="flex items-center lg:hidden">
                        <button @click="mobileMenuOpen = true" class="rounded-lg p-2 text-gray-500 hover:bg-gray-100 hover:text-gray-700" aria-label="Abrir menú">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                            </svg>
                        </button>
                        <img src="{{ asset('images/miniaturaIzy.png') }}" alt="izyAcademy" class="ml-2 w-8 h-8 object-contain">
                    </div>

                    <!-- Page Title / Breadcrumb Placeholder -->
                    <div class="hidden sm:flex items-center gap-2">
                        <h1 class="text-lg font-bold text-[#1D3A6C]">@yield('header_title', 'Sistema de Capacitaciones')</h1>
                    </div>

                    <!-- Right Profile Actions -->
                    <div class="flex items-center gap-4">
                        <span class="hidden lg:inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-[#E8F6F3] text-[#19A885] border border-[#19A885]/20">
                            {{ auth()->user()->name }}
                        </span>

                        <form method="POST" action="{{ route('logout') }}" class="inline">
                            @csrf
                            <button type="submit" class="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-gray-700 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors border border-gray-200">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                                </svg>
                                Salir
                            </button>
                        </form>
                    </div>
                </div>
            </header>

            <!-- FLASH ALERTS CONTAINER -->
            <main class="min-h-0 flex-1 overflow-y-visible pb-12">
                <div class="mx-auto max-w-7xl px-3 pt-4 sm:px-6 sm:pt-6 lg:px-8">
                    @if(session('success'))
                        <div data-auto-dismiss class="mb-6 rounded-xl bg-[#E8F6F3] border-l-4 border-[#19A885] p-4 text-sm text-[#14866A] shadow-sm flex items-center justify-between transition-opacity duration-500">
                            <div class="flex items-center gap-3">
                                <svg class="w-5 h-5 text-[#19A885]" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                                </svg>
                                <span class="font-medium">{{ session('success') }}</span>
                            </div>
                        </div>
                    @endif

                    @if(session('warning'))
                        <div data-auto-dismiss class="mb-6 rounded-xl bg-[#FFF2EB] border-l-4 border-[#FF5F00] p-4 text-sm text-[#D95100] shadow-sm flex items-center justify-between transition-opacity duration-500">
                            <div class="flex items-center gap-3">
                                <svg class="w-5 h-5 text-[#FF5F00]" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
                                </svg>
                                <span class="font-medium">{{ session('warning') }}</span>
                            </div>
                        </div>
                    @endif

                    @if($errors->any())
                        <div class="mb-6 rounded-xl bg-red-50 border-l-4 border-red-500 p-4 text-sm text-red-700 shadow-sm">
                            <p class="font-bold mb-1">Por favor verifica los siguientes campos:</p>
                            <ul class="list-disc list-inside space-y-1 text-xs">
                                @foreach($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    <!-- Content Injected Here -->
                    @yield('content')
                </div>
            </main>
        </div>
    </div>

    @stack('scripts')
</body>
</html>

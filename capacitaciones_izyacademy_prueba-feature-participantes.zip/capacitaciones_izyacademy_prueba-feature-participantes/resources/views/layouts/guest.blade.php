{{-- Plantilla base para páginas de invitados, principalmente autenticación. --}}
{{-- Carga estilos, identidad visual y el contenido definido por cada vista hija. --}}
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('branding.app_name', 'Capacitaciones Corporativas') }}</title>

    @vite('resources/css/app.css')
</head>
<body class="bg-[#F8FAFC] text-[#111111] antialiased min-h-screen flex flex-col justify-center py-12 sm:px-6 lg:px-8 font-sans">
    <div class="sm:mx-auto sm:w-full sm:max-w-md">
        <div class="flex justify-center">
            <img src="{{ asset('images/miniaturaIzy.png') }}" alt="izyAcademy" class="block w-32 h-32 rounded-full object-cover shadow-lg shadow-[#1D3A6C]/20">
        </div>
        <h2 class="mt-4 text-center text-2xl font-bold tracking-tight text-[#1D3A6C]">
            {{ config('branding.app_name', 'IzyCapacitaciones') }}
        </h2>
        <p class="mt-1 text-center text-sm text-gray-500">
            {{ config('branding.company_name', 'izyAcademy Corporativo') }}
        </p>
    </div>

    <div class="mt-8 sm:mx-auto sm:w-full sm:max-w-md px-4 sm:px-0">
        @yield('content')
    </div>
</body>
</html>

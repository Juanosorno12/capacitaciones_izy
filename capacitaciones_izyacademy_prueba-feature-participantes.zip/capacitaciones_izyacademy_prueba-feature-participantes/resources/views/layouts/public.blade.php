{{-- Plantilla base para páginas públicas visibles sin autenticación. --}}
{{-- Incluye navegación hacia el inicio, acceso al login, contenido y pie de página. --}}
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Capacitaciones') - {{ config('branding.app_name', 'IzyCapacitaciones') }}</title>

    @vite('resources/css/app.css')
</head>
<body class="min-h-screen bg-[#F8FAFC] font-sans text-[#111111] antialiased">
    <header class="border-b border-gray-200 bg-white">
        <div class="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6 lg:px-8">
            <a href="{{ route('home') }}" class="flex items-center gap-3">
                <img src="{{ asset('images/miniaturaIzy.png') }}" alt="izyAcademy" class="h-10 w-10 rounded-full object-cover">
                <span class="text-sm font-bold text-[#1D3A6C] sm:text-base">{{ config('branding.app_name', 'IzyAcademy Capacitaciones') }}</span>
            </a>
            <a href="{{ route('login') }}" class="inline-flex shrink-0 items-center rounded-lg bg-[#19A885] px-2.5 py-1.5 text-[10px] font-bold leading-tight text-white transition-colors hover:bg-[#14866A] sm:px-4 sm:py-2.5 sm:text-sm">
                Iniciar sesión
            </a>
        </div>
    </header>

    <main class="mx-auto max-w-7xl px-4 py-8 sm:px-6 sm:py-12 lg:px-8">
        @yield('content')
    </main>

    <footer class="mt-8 border-t border-gray-200 bg-white">
        <div class="mx-auto max-w-7xl px-4 py-5 text-center text-xs text-gray-500 sm:px-6 lg:px-8">
            {{ config('branding.company_name', 'izyAcademy Corporativo') }}
        </div>
    </footer>
</body>
</html>

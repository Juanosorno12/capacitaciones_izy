{{-- Panel principal del usuario autenticado. --}}
{{-- Presenta métricas, solicitudes recientes y capacitaciones según el rol y permisos. --}}
@extends('layouts.app')

@section('title', 'Dashboard')
@section('header_title', 'Capacitaciones IzyAcademy')

@section('content')
<div class="space-y-8">

    {{-- 1. VISTA DE DASHBOARD PARA ROL ADMINISTRADOR --}}
    @hasRole('administrador')
    @isset($metrics)
    <!-- Métricas Clave de Desempeño (KPIs) -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <!-- KPI 1: Capacitaciones Totales -->
        <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm hover:shadow transition-shadow">
            <div class="flex items-center justify-between">
                <p class="text-xs font-semibold text-gray-500 uppercase tracking-wider">Capacitaciones</p>
                <div class="w-9 h-9 rounded-lg bg-[#EBF3FC] flex items-center justify-center text-[#0055AF]">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/>
                    </svg>
                </div>
            </div>
            <p class="text-3xl font-extrabold text-[#1D3A6C] mt-3">{{ $metrics['kpis']['total_trainings'] }}</p>
            <p class="text-xs text-gray-500 mt-1">Programas registrados activos</p>
        </div>

        <!-- KPI 2: Total Horas -->
        <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm hover:shadow transition-shadow">
            <div class="flex items-center justify-between">
                <p class="text-xs font-semibold text-gray-500 uppercase tracking-wider">Horas Impartidas</p>
                <div class="w-9 h-9 rounded-lg bg-[#E8F6F3] flex items-center justify-center text-[#19A885]">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                </div>
            </div>
            <p class="text-3xl font-extrabold text-[#19A885] mt-3">{{ $metrics['kpis']['total_hours'] }}h</p>
            <p class="text-xs text-gray-500 mt-1">Acumulado de formación técnica</p>
        </div>

        <!-- KPI 3: Solicitudes Pendientes -->
        <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm hover:shadow transition-shadow">
            <div class="flex items-center justify-between">
                <p class="text-xs font-semibold text-gray-500 uppercase tracking-wider">Por Revisar</p>
                <div class="w-9 h-9 rounded-lg bg-[#FFF2EB] flex items-center justify-center text-[#FF5F00]">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
                    </svg>
                </div>
            </div>
            <p class="text-3xl font-extrabold text-[#FF5F00] mt-3">{{ $metrics['kpis']['pending_requests'] }}</p>
            <p class="text-xs text-gray-500 mt-1">Solicitudes esperando aprobación</p>
        </div>

        <!-- KPI 4: Usuarios Activos -->
        <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm hover:shadow transition-shadow">
            <div class="flex items-center justify-between">
                <p class="text-xs font-semibold text-gray-500 uppercase tracking-wider">Colaboradores</p>
                <div class="w-9 h-9 rounded-lg bg-purple-50 flex items-center justify-center text-purple-600">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                    </svg>
                </div>
            </div>
            <p class="text-3xl font-extrabold text-[#1D3A6C] mt-3">{{ $metrics['kpis']['active_users'] }}</p>
            <p class="text-xs text-gray-500 mt-1">Usuarios activos en la plataforma</p>
        </div>
    </div>

    <!-- Sección de Solicitudes Recientes y Acciones Rápidas -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Tabla de Solicitudes Recientes -->
        <div class="lg:col-span-2 bg-white rounded-xl border border-gray-200 overflow-hidden shadow-sm">
            <div class="p-5 border-b border-gray-100 flex items-center justify-between">
                <div>
                    <h3 class="font-bold text-[#1D3A6C] text-base">Últimas Solicitudes de Capacitación</h3>
                    <p class="text-xs text-gray-500">Requerimientos enviados por directores y líderes</p>
                </div>
                <a href="{{ route('requests.index') }}" class="text-xs font-semibold text-[#0055AF] hover:underline">
                    Ver todas &rarr;
                </a>
            </div>
            <div class="divide-y divide-gray-100">
                @forelse($recentRequests as $req)
                    <div class="p-4 flex items-center justify-between hover:bg-gray-50/80 transition-colors">
                        <div class="min-w-0 flex-1 pr-4">
                            <div class="flex items-center gap-2">
                                <span class="text-xs font-semibold px-2 py-0.5 rounded-full
                                    {{ $req->status === 'pending' ? 'bg-[#FFF2EB] text-[#FF5F00]' : '' }}
                                    {{ $req->status === 'approved' ? 'bg-[#E8F6F3] text-[#19A885]' : '' }}
                                    {{ $req->status === 'reviewing' ? 'bg-[#EBF3FC] text-[#0055AF]' : '' }}
                                    {{ $req->status === 'rejected' ? 'bg-red-50 text-red-600' : '' }}">
                                    {{ ucfirst($req->status) }}
                                </span>
                                <span class="text-xs text-gray-400">• {{ $req->category->name }}</span>
                            </div>
                            <h4 class="text-sm font-semibold text-[#111111] truncate mt-1">{{ $req->title }}</h4>
                            <p class="text-xs text-gray-500">Solicitado por: {{ $req->requester->name }} ({{ $req->estimated_participants }} participantes)</p>
                        </div>
                        <a href="{{ route('requests.show', $req) }}" class="inline-flex items-center px-3 py-1.5 text-xs font-medium text-[#0055AF] bg-[#EBF3FC] hover:bg-[#0055AF] hover:text-white rounded-lg transition-colors">
                            Revisar
                        </a>
                    </div>
                @empty
                    <div class="p-8 text-center text-sm text-gray-500">
                        No hay solicitudes recientes registradas.
                    </div>
                @endforelse
            </div>
        </div>

        <!-- Atajos Rápidos de Gestión -->
        <div class="space-y-4">
            <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
                <h3 class="font-bold text-[#1D3A6C] text-base mb-4">Acciones de Gestión</h3>
                <div class="space-y-2.5">
                    <a href="{{ route('trainings.create') }}" class="w-full flex items-center justify-between p-3 rounded-lg bg-[#E8F6F3] text-[#14866A] hover:bg-[#19A885] hover:text-white transition-colors group">
                        <span class="text-sm font-semibold">Programar Capacitación</span>
                        <svg class="w-4 h-4 transform group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                        </svg>
                    </a>

                    <a href="{{ route('users.create') }}" class="w-full flex items-center justify-between p-3 rounded-lg bg-[#EBF3FC] text-[#0055AF] hover:bg-[#0055AF] hover:text-white transition-colors group">
                        <span class="text-sm font-semibold">Registrar Nuevo Usuario</span>
                        <svg class="w-4 h-4 transform group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"/>
                        </svg>
                    </a>

                    <a href="{{ route('reports.index') }}" class="w-full flex items-center justify-between p-3 rounded-lg bg-gray-50 text-gray-700 hover:bg-[#1D3A6C] hover:text-white transition-colors group border border-gray-200">
                        <span class="text-sm font-semibold">Ver Reportes Completos</span>
                        <svg class="w-4 h-4 transform group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </div>
    @endisset
    @endhasRole


    {{-- 2. VISTA DE DASHBOARD PARA DIRECTORES Y LÍDERES --}}
    @hasRole('directores-y-lideres')
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <!-- KPI Card: Mis Solicitudes Pendientes -->
        <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
            <p class="text-xs font-semibold text-gray-500 uppercase tracking-wider">Mis Solicitudes Pendientes</p>
            <p class="text-3xl font-extrabold text-[#FF5F00] mt-2">{{ $pendingCount ?? 0 }}</p>
            <p class="text-xs text-gray-500 mt-1">Esperando revisión y programación</p>
        </div>

        <!-- KPI Card: Capacitaciones Aprobadas para mi equipo -->
        <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
            <p class="text-xs font-semibold text-gray-500 uppercase tracking-wider">Solicitudes Aprobadas</p>
            <p class="text-3xl font-extrabold text-[#19A885] mt-2">{{ $approvedCount ?? 0 }}</p>
            <p class="text-xs text-gray-500 mt-1">Convertidas en cursos oficiales</p>
        </div>

        <!-- CTA Card -->
        <div class="bg-white rounded-xl border border-gray-200 p-5 shadow-sm flex flex-col justify-between">
            <div>
                <p class="text-xs font-semibold text-[#1D3A6C] uppercase tracking-wider">¿Tu equipo necesita formación?</p>
                <p class="text-xs text-gray-500 mt-1">Postula un requerimiento técnico para su programación.</p>
            </div>
            <a href="{{ route('requests.create') }}" class="mt-4 inline-flex items-center justify-center px-4 py-2 bg-[#19A885] hover:bg-[#14866A] text-white text-xs font-bold rounded-lg transition-colors">
                + Crear Solicitud de Capacitación
            </a>
        </div>
    </div>

    <!-- Seguimiento de Mis Solicitudes -->
    <div class="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-sm">
        <div class="p-5 border-b border-gray-100 flex items-center justify-between">
            <h3 class="font-bold text-[#1D3A6C] text-base">Mis Solicitudes de Capacitación</h3>
            <a href="{{ route('requests.index') }}" class="text-xs font-semibold text-[#0055AF] hover:underline">Ver historial</a>
        </div>
        <div class="divide-y divide-gray-100">
            @forelse($myRequests ?? [] as $req)
                <div class="p-4 flex items-center justify-between">
                    <div>
                        <span class="text-xs font-semibold px-2 py-0.5 rounded-full
                            {{ $req->status === 'pending' ? 'bg-[#FFF2EB] text-[#FF5F00]' : '' }}
                            {{ $req->status === 'approved' ? 'bg-[#E8F6F3] text-[#19A885]' : '' }}
                            {{ $req->status === 'reviewing' ? 'bg-[#EBF3FC] text-[#0055AF]' : '' }}
                            {{ $req->status === 'rejected' ? 'bg-red-50 text-red-600' : '' }}">
                            {{ ucfirst($req->status) }}
                        </span>
                        <h4 class="text-sm font-semibold text-[#111111] mt-1">{{ $req->title }}</h4>
                        <p class="text-xs text-gray-500">{{ $req->category->name }} • {{ $req->created_at->format('d/m/Y') }}</p>
                    </div>
                    <a href="{{ route('requests.show', $req) }}" class="text-xs font-medium text-[#0055AF] hover:underline">
                        Ver Detalles
                    </a>
                </div>
            @empty
                <div class="p-8 text-center text-sm text-gray-500">
                    Aún no has registrado solicitudes de capacitación.
                </div>
            @endforelse
        </div>
    </div>
    @endhasRole


    {{-- 3. VISTA DE DASHBOARD PARA ROL EXTERNOS --}}
    @hasRole('externos')
    <div class="space-y-4">
        <div class="flex items-center justify-between">
            <div>
                <h3 class="text-lg font-bold text-[#1D3A6C]">Capacitaciones Disponibles</h3>
                <p class="text-xs text-gray-500">Cursos corporativos públicos habilitados para participantes externos</p>
            </div>
            <a href="{{ route('trainings.index') }}" class="text-xs font-semibold text-[#0055AF] hover:underline">Ver catálogo completo &rarr;</a>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            @forelse($publicTrainings ?? [] as $item)
                <div class="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-sm hover:shadow transition-shadow flex flex-col">
                    <div class="p-5 flex-1">
                        <span class="inline-block px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[#EBF3FC] text-[#0055AF] mb-2">
                            {{ $item->category->name }}
                        </span>
                        <h4 class="text-base font-bold text-[#1D3A6C] mb-2 leading-snug">{{ $item->title }}</h4>
                        <p class="text-xs text-gray-600 line-clamp-3 mb-4 leading-relaxed">{{ $item->description }}</p>
                        
                        <div class="flex items-center gap-3 pt-3 border-t border-gray-100">
                            <img src="{{ $item->avatar_url }}" alt="{{ $item->expert_name }}" class="w-8 h-8 rounded-full object-cover" loading="lazy">
                            <div class="text-xs">
                                <p class="font-semibold text-gray-900">{{ $item->expert_name ?: 'izyacademy' }}</p>
                                <p class="text-gray-500">{{ $item->duration_hours }} horas académicas</p>
                            </div>
                        </div>
                    </div>
                    <div class="px-5 py-3 bg-gray-50 border-t border-gray-100 flex items-center justify-between">
                        <span class="text-xs text-gray-500">
                            {{ $item->has_certificate ? '🏅 Certificado Incluido' : 'Asistencia simple' }}
                        </span>
                        <a href="{{ route('trainings.show', $item) }}" class="text-xs font-bold text-[#19A885] hover:text-[#14866A]">
                            Ver Programa &rarr;
                        </a>
                    </div>
                </div>
            @empty
                <div class="col-span-3 bg-white p-8 rounded-xl text-center text-gray-500 text-sm border border-gray-200">
                    No hay capacitaciones públicas disponibles en este momento.
                </div>
            @endforelse
        </div>
    </div>
    @endhasRole

</div>
@endsection

{{-- Directorio de participantes. --}}
{{-- Permite buscar personas y consultar su historial de capacitaciones. --}}
@extends('layouts.app')

@section('title', 'Participantes')
@section('header_title', 'Directorio de Participantes')

@section('content')
<div class="space-y-6">
    <div>
        <h2 class="text-xl font-bold text-[#1D3A6C]">Directorio de Participantes</h2>
        <p class="mt-1 text-xs text-gray-500">Consulta las personas registradas y el historial de capacitaciones vinculado a cada una.</p>
    </div>

    <div class="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
        <form method="GET" action="{{ route('participants.index') }}" class="flex flex-col gap-3 sm:flex-row">
            <label for="search" class="sr-only">Buscar por nombre, apellidos o correo</label>
            <input id="search" type="search" name="search" value="{{ $search }}"
                placeholder="Buscar por nombre, apellidos o correo..."
                class="w-full rounded-lg border border-gray-300 px-3 py-2 text-xs focus:border-[#0055AF] focus:ring focus:ring-[#0055AF]/20">
            <div class="flex gap-2">
                <button type="submit" class="rounded-lg bg-[#1D3A6C] px-4 py-2 text-xs font-semibold text-white hover:bg-[#13274A]">Buscar</button>
                @if($search !== '')
                    <a href="{{ route('participants.index') }}" class="rounded-lg bg-gray-100 px-4 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-200">Limpiar</a>
                @endif
            </div>
        </form>
    </div>

    <div class="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
        <div class="overflow-x-auto">
            <table class="responsive-table min-w-full divide-y divide-gray-200 text-left text-xs">
                <thead class="bg-[#F8FAFC] text-gray-600">
                    <tr>
                        <th class="px-5 py-3.5 font-semibold uppercase tracking-wider">Participante</th>
                        <th class="px-5 py-3.5 font-semibold uppercase tracking-wider">Correo corporativo</th>
                        <th class="px-5 py-3.5 font-semibold uppercase tracking-wider">Correo personal</th>
                        <th class="px-5 py-3.5 font-semibold uppercase tracking-wider">Celular</th>
                        <th class="px-5 py-3.5 font-semibold uppercase tracking-wider">Ciudad</th>
                        <th class="px-5 py-3.5 text-center font-semibold uppercase tracking-wider">Capacitaciones</th>
                        <th class="px-5 py-3.5 text-right font-semibold uppercase tracking-wider">Historial</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    @forelse($participants as $participant)
                        <tr class="hover:bg-gray-50">
                            <td class="px-5 py-4 font-semibold text-gray-900">{{ $participant->first_name }} {{ $participant->last_name }}</td>
                            <td class="px-5 py-4 text-gray-600">{{ $participant->email }}</td>
                            <td class="px-5 py-4 text-gray-600">{{ $participant->personal_email ?: '—' }}</td>
                            <td class="px-5 py-4 text-gray-600">{{ $participant->phone ?: '—' }}</td>
                            <td class="px-5 py-4 text-gray-600">{{ $participant->city ?: '—' }}</td>
                            <td class="px-5 py-4 text-center">
                                <span class="inline-flex rounded-full bg-[#E8F6F3] px-2.5 py-1 font-bold text-[#14866A]">{{ $participant->trainings_count }}</span>
                            </td>
                            <td class="px-5 py-4 text-right">
                                <a href="{{ route('participants.show', $participant) }}" class="font-semibold text-[#0055AF] hover:underline">Ver historial</a>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7" class="px-5 py-10 text-center text-gray-500">
                                {{ $search !== '' ? 'No hay participantes que coincidan con la búsqueda.' : 'Todavía no hay participantes registrados.' }}
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($participants->hasPages())
            <div class="border-t border-gray-100 p-4">{{ $participants->links() }}</div>
        @endif
    </div>
</div>
@endsection

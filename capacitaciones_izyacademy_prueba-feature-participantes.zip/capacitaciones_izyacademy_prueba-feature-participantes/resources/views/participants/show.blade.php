{{-- Historial individual de un participante. --}}
{{-- Presenta sus datos de contacto y las capacitaciones relacionadas. --}}
@extends('layouts.app')

@section('title', 'Historial del Participante')
@section('header_title', 'Historial de Capacitaciones')

@section('content')
<div class="mx-auto max-w-4xl space-y-6">
    <a href="{{ route('participants.index') }}" class="text-xs font-semibold text-[#0055AF] hover:underline">&larr; Volver al directorio</a>

    <section class="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
        <div class="flex flex-wrap items-start justify-between gap-4">
            <div>
                <h2 class="text-xl font-bold text-[#1D3A6C]">{{ $participant->first_name }} {{ $participant->last_name }}</h2>
                <p class="mt-2 text-xs text-gray-600">Correo corporativo: {{ $participant->email }}</p>
                <p class="mt-1 text-xs text-gray-600">Correo personal: {{ $participant->personal_email ?: 'No registrado' }}</p>
                <p class="mt-1 text-xs text-gray-600">Celular: {{ $participant->phone ?: 'No registrado' }}</p>
                <p class="mt-1 text-xs text-gray-600">Ciudad: {{ $participant->city ?: 'No registrada' }}</p>
            </div>
            <div class="rounded-xl bg-[#E8F6F3] px-5 py-3 text-center">
                <p class="text-2xl font-bold text-[#14866A]">{{ $participant->trainings->count() }}</p>
                <p class="text-[11px] font-semibold text-gray-600">Capacitaciones vinculadas</p>
            </div>
        </div>
    </section>

    <section class="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
        <div class="border-b border-gray-100 px-5 py-4">
            <h3 class="text-sm font-bold text-[#1D3A6C]">Historial</h3>
            <p class="mt-1 text-[11px] text-gray-500">Capacitaciones asociadas a solicitudes aprobadas.</p>
        </div>
        <div class="divide-y divide-gray-100">
            @forelse($participant->trainings as $training)
                <a href="{{ route('trainings.show', $training) }}" class="flex flex-wrap items-center justify-between gap-2 px-5 py-4 hover:bg-gray-50">
                    <div>
                        <p class="text-xs font-semibold text-[#1D3A6C]">{{ $training->title }}</p>
                        <p class="mt-1 text-[11px] text-gray-500">{{ $training->category?->name ?: 'Sin categoría' }}</p>
                    </div>
                    <span class="text-[11px] text-gray-500">{{ $training->created_at->format('d/m/Y') }}</span>
                </a>
            @empty
                <p class="px-5 py-8 text-center text-xs text-gray-500">Este participante aún no tiene capacitaciones vinculadas.</p>
            @endforelse
        </div>
    </section>
</div>
@endsection

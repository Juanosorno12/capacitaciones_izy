import Chart from 'chart.js/auto';
import { downloadDeliveredTrainingReport } from './report-export';

window.Chart = Chart;

document.addEventListener('DOMContentLoaded', () => {
    const period = document.getElementById('period');
    if (period) {
        const updatePeriodFields = () => {
            document.querySelectorAll('[data-period-field]').forEach((group) => {
                const visible = group.dataset.periodField === period.value;
                group.hidden = !visible;
                group.querySelectorAll('input').forEach((input) => {
                    input.disabled = !visible;
                });
            });
        };

        period.addEventListener('change', updatePeriodFields);
        updatePeriodFields();
    }

    const exportButton = document.getElementById('export-delivered-trainings');
    const exportStatus = document.getElementById('report-export-status');
    if (exportButton && exportStatus) {
        exportButton.addEventListener('click', () => {
            downloadDeliveredTrainingReport(
                exportButton.dataset.exportUrl,
                exportButton,
                exportStatus
            ).catch((error) => {
                exportButton.disabled = false;
                exportStatus.textContent = error instanceof Error
                    ? error.message
                    : 'Ocurrió un error al exportar el reporte.';
            });
        });
    }
});

// Initialize corporate charts
window.initReportCharts = function(categoryData, statusData, trendData) {
    const brandColors = {
        navy: '#1D3A6C',
        teal: '#19A885',
        orange: '#FF5F00',
        blue: '#0055AF',
        gray: '#64748B',
        palette: ['#1D3A6C', '#19A885', '#FF5F00', '#0055AF', '#4F46E5', '#06B6D4', '#84CC16', '#F59E0B']
    };

    // Chart 1: Trainings by Category (Doughnut)
    const categoryCtx = document.getElementById('trainingsByCategoryChart');
    if (categoryCtx && categoryData) {
        new Chart(categoryCtx, {
            type: 'doughnut',
            data: {
                labels: categoryData.labels,
                datasets: [{
                    data: categoryData.values,
                    backgroundColor: brandColors.palette.slice(0, categoryData.labels.length),
                    borderWidth: 2,
                    borderColor: '#FFFFFF',
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            boxWidth: 12,
                            font: { family: 'Inter', size: 12 },
                            padding: 15
                        }
                    }
                },
                cutout: '65%'
            }
        });
    }

    // Chart 2: Requests by Status (Bar)
    const statusCtx = document.getElementById('requestsByStatusChart');
    if (statusCtx && statusData) {
        new Chart(statusCtx, {
            type: 'bar',
            data: {
                labels: statusData.labels,
                datasets: [{
                    label: 'Solicitudes',
                    data: statusData.values,
                    backgroundColor: [
                        brandColors.orange, // Pendientes
                        brandColors.blue,   // En revisión
                        brandColors.teal,   // Aprobadas
                        '#EF4444'           // Rechazadas
                    ],
                    borderRadius: 6,
                    borderSkipped: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: { stepSize: 1, font: { family: 'Inter' } },
                        grid: { color: '#E2E8F0' }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { font: { family: 'Inter' } }
                    }
                }
            }
        });
    }

    // Chart 3: Monthly Training Hours (Line)
    const trendCtx = document.getElementById('monthlyTrendChart');
    if (trendCtx && trendData) {
        new Chart(trendCtx, {
            type: 'line',
            data: {
                labels: trendData.labels,
                datasets: [{
                    label: 'Horas Capacitadas',
                    data: trendData.values,
                    borderColor: brandColors.teal,
                    backgroundColor: 'rgba(25, 168, 133, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.35,
                    pointBackgroundColor: brandColors.navy,
                    pointRadius: 5,
                    pointHoverRadius: 7
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: '#E2E8F0' },
                        ticks: { font: { family: 'Inter' } }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { font: { family: 'Inter' } }
                    }
                }
            }
        });
    }
};

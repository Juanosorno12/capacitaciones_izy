import { strToU8, zipSync } from 'fflate';

const headers = [
    ['date', 'Fecha'],
    ['training', 'Capacitación'],
    ['client', 'Cliente'],
    ['value_added', 'Valor agregado'],
    ['category', 'Categoría'],
    ['expert', 'Facilitador'],
    ['modality', 'Modalidad'],
    ['start_time', 'Hora de inicio'],
    ['end_time', 'Hora de finalización'],
    ['hours', 'Horas impartidas'],
    ['participant_count', 'Cantidad de participantes'],
    ['participants', 'Participantes (nombre y correo)'],
];

const escapeXml = (value) => String(value ?? '')
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');

const columnName = (index) => {
    let name = '';
    while (index > 0) {
        const remainder = (index - 1) % 26;
        name = String.fromCharCode(65 + remainder) + name;
        index = Math.floor((index - 1) / 26);
    }
    return name;
};

const worksheetXml = (rows) => {
    const allRows = [headers.map(([, title]) => title), ...rows.map((row) => headers.map(([key]) => row[key] ?? ''))];
    const sheetRows = allRows.map((row, rowIndex) => {
        const cells = row.map((value, columnIndex) => {
            const reference = `${columnName(columnIndex + 1)}${rowIndex + 1}`;
            if (typeof value === 'number' && Number.isFinite(value)) {
                return `<c r="${reference}"><v>${value}</v></c>`;
            }
            return `<c r="${reference}" t="inlineStr"><is><t xml:space="preserve">${escapeXml(value)}</t></is></c>`;
        }).join('');
        return `<row r="${rowIndex + 1}">${cells}</row>`;
    }).join('');

    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${sheetRows}</sheetData></worksheet>`;
};

export const createWorkbook = (rows) => zipSync({
    '[Content_Types].xml': strToU8('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>'),
    '_rels/.rels': strToU8('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'),
    'xl/workbook.xml': strToU8('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Capacitaciones impartidas" sheetId="1" r:id="rId1"/></sheets></workbook>'),
    'xl/_rels/workbook.xml.rels': strToU8('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>'),
    'xl/worksheets/sheet1.xml': strToU8(worksheetXml(rows)),
});

export const downloadDeliveredTrainingReport = async (url, button, status) => {
    button.disabled = true;
    status.textContent = 'Preparando archivo de Excel…';

    try {
        const response = await fetch(url, {
            headers: { Accept: 'application/json' },
            credentials: 'same-origin',
        });
        const payload = await response.json();
        if (!response.ok) {
            throw new Error(payload.message || 'No fue posible generar el reporte.');
        }

        const workbook = createWorkbook(payload.rows);
        const file = new Blob([workbook], {
            type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });
        const downloadUrl = URL.createObjectURL(file);
        const link = document.createElement('a');
        link.href = downloadUrl;
        link.download = `capacitaciones_programadas_${new Date().toISOString().slice(0, 10)}.xlsx`;
        document.body.append(link);
        link.click();
        link.remove();
        window.setTimeout(() => URL.revokeObjectURL(downloadUrl), 1000);
        status.textContent = `${payload.rows.length} sesiones exportadas.`;
    } catch (error) {
        status.textContent = error instanceof Error ? error.message : 'Ocurrió un error al exportar el reporte.';
    } finally {
        button.disabled = false;
    }
};

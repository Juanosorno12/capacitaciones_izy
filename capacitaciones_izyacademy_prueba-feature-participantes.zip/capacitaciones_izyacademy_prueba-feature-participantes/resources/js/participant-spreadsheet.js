// Utilidades para leer y generar plantillas XLSX sin depender de un servidor.
import { strFromU8, strToU8, unzipSync, zipSync } from 'fflate';

const TEMPLATE_HEADERS = [
    ['Nombre', 'Apellido', 'Correo corporativo', 'Correo personal (opcional)', 'Celular', 'Ciudad'],
];

// Escapa valores para insertarlos de forma segura en XML.
const escapeXml = (value) => String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');

// Construye la hoja XML que contiene los encabezados de la plantilla.
const templateWorksheetXml = () => {
    const cells = TEMPLATE_HEADERS[0].map((header, index) => {
        const column = String.fromCharCode(65 + index);
        return `<c r="${column}1" t="inlineStr"><is><t>${escapeXml(header)}</t></is></c>`;
    }).join('');

    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData><row r="1">${cells}</row></sheetData></worksheet>`;
};

const HEADER_ALIASES = {
    first_name: ['nombre'],
    last_name: ['apellido', 'apellidos'],
    email: ['correo_corporativo', 'correo_electronico_corporativo'],
    personal_email: [
        'correo_personal',
        'correo_personal_opcional',
        'correo_electronico_personal',
        'correo_electronico_personal_opcional',
    ],
    phone: ['celular', 'numero_celular', 'telefono'],
    city: ['ciudad'],
};

const REQUIRED_FIELDS = ['first_name', 'last_name', 'email', 'phone', 'city'];

// Convierte encabezados del Excel a una forma comparable y sin acentos.
const normalizeHeader = (header) => header
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+/, '')
    .replace(/_+$/, '');

// Lee y valida un documento XML almacenado dentro del archivo XLSX.
const parseXml = (files, path) => {
    const file = files[path];
    if (!file) {
        throw new Error('El archivo de Excel no contiene las hojas necesarias.');
    }

    const document = new DOMParser().parseFromString(strFromU8(file), 'application/xml');
    if (document.querySelector('parsererror')) {
        throw new Error('No fue posible interpretar el contenido del archivo de Excel.');
    }

    return document;
};

// Devuelve todos los elementos XML con el nombre indicado, sin depender del namespace.
const allElements = (parent, name) => Array.from(parent.getElementsByTagNameNS('*', name));

// Normaliza rutas internas del contenedor ZIP y evita segmentos relativos.
const normalizeZipPath = (path) => {
    const segments = [];
    path.split('/').forEach((segment) => {
        if (!segment || segment === '.') {
            return;
        }
        if (segment === '..') {
            segments.pop();
            return;
        }
        segments.push(segment);
    });

    return segments.join('/');
};

// Convierte una referencia de columna Excel, como A o BC, a un índice numérico.
const getColumnIndex = (reference) => {
    const letters = reference.match(/^[A-Z]+/i)?.[0];
    if (!letters) {
        throw new Error('El archivo de Excel contiene una celda sin referencia válida.');
    }

    return [...letters.toUpperCase()].reduce(
        (index, letter) => index * 26 + letter.charCodeAt(0) - 64,
        0
    ) - 1;
};

// Obtiene el texto de una celda considerando cadenas inline y compartidas.
const getCellValue = (cell, sharedStrings) => {
    const type = cell.getAttribute('t');
    if (type === 'inlineStr') {
        return allElements(cell, 't').map((text) => text.textContent || '').join('');
    }

    const value = allElements(cell, 'v')[0]?.textContent || '';
    if (type === 's') {
        const index = Number(value);
        if (!Number.isInteger(index) || sharedStrings[index] === undefined) {
            throw new Error('El archivo de Excel contiene una referencia de texto inválida.');
        }
        return sharedStrings[index];
    }

    return value;
};

/** Lee un XLSX, valida sus columnas y devuelve participantes normalizados. */
export const readParticipantSpreadsheet = async (file) => {
    if (!file.name.toLowerCase().endsWith('.xlsx')) {
        throw new Error('Selecciona un archivo de Excel con extensión .xlsx.');
    }
    if (file.size > 5 * 1024 * 1024) {
        throw new Error('El archivo de Excel no puede superar los 5 MB.');
    }

    const files = unzipSync(new Uint8Array(await file.arrayBuffer()));
    const workbook = parseXml(files, 'xl/workbook.xml');
    const firstSheet = allElements(workbook, 'sheet')[0];
    const relationshipId = firstSheet?.getAttribute('r:id')
        || firstSheet?.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships', 'id');
    if (!relationshipId) {
        throw new Error('El libro de Excel no contiene una hoja de cálculo.');
    }

    const relationships = parseXml(files, 'xl/_rels/workbook.xml.rels');
    const relationship = allElements(relationships, 'Relationship')
        .find((item) => item.getAttribute('Id') === relationshipId);
    if (!relationship?.getAttribute('Target')) {
        throw new Error('No fue posible localizar la primera hoja del libro de Excel.');
    }

    const target = relationship.getAttribute('Target');
    const sheetPath = normalizeZipPath(target.startsWith('/') ? target.slice(1) : `xl/${target}`);
    const sheet = parseXml(files, sheetPath);
    const sharedStrings = files['xl/sharedStrings.xml']
        ? allElements(parseXml(files, 'xl/sharedStrings.xml'), 'si')
            .map((item) => allElements(item, 't').map((text) => text.textContent || '').join(''))
        : [];
    const rows = allElements(sheet, 'row').map((row) => {
        const values = [];
        allElements(row, 'c').forEach((cell) => {
            values[getColumnIndex(cell.getAttribute('r'))] = getCellValue(cell, sharedStrings);
        });
        return values;
    });
    const headerRowIndex = rows.findIndex((row) => row.some((value) => String(value || '').trim() !== ''));
    if (headerRowIndex === -1) {
        throw new Error('El archivo de Excel está vacío.');
    }

    const headers = {};
    rows[headerRowIndex].forEach((value, index) => {
        const normalized = normalizeHeader(String(value || ''));
        Object.entries(HEADER_ALIASES).forEach(([field, aliases]) => {
            if (aliases.includes(normalized)) {
                headers[field] = index;
            }
        });
    });

    const missingFields = REQUIRED_FIELDS.filter((field) => headers[field] === undefined);
    if (missingFields.length > 0) {
        const labels = {
            first_name: 'Nombre',
            last_name: 'Apellido',
            email: 'Correo corporativo',
            phone: 'Celular',
            city: 'Ciudad',
        };

        throw new Error(`Faltan columnas obligatorias: ${missingFields.map((field) => labels[field]).join(', ')}.`);
    }

    const participants = rows.slice(headerRowIndex + 1)
        .filter((row) => row.some((value) => String(value || '').trim() !== ''))
        .map((row) => Object.fromEntries(
            Object.entries(HEADER_ALIASES).map(([field]) => [
                field,
                String(headers[field] === undefined ? '' : row[headers[field]] ?? '').trim(),
            ])
        ));

    if (participants.length === 0) {
        throw new Error('El archivo no contiene participantes para importar.');
    }
    if (participants.length > 1000) {
        throw new Error('El archivo no puede contener más de 1000 participantes.');
    }

    return participants;
};

/** Genera los bytes de una plantilla XLSX con las columnas esperadas. */
export const createParticipantTemplate = () => zipSync({
    '[Content_Types].xml': strToU8('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>'),
    '_rels/.rels': strToU8('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'),
    'xl/workbook.xml': strToU8('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Participantes" sheetId="1" r:id="rId1"/></sheets></workbook>'),
    'xl/_rels/workbook.xml.rels': strToU8('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>'),
    'xl/worksheets/sheet1.xml': strToU8(templateWorksheetXml()),
});

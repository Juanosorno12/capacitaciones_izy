// Inicializa Alpine.js y expone las utilidades de importación de participantes.
import Alpine from 'alpinejs';
import { createParticipantTemplate, readParticipantSpreadsheet } from './participant-spreadsheet';

window.Alpine = Alpine;
window.readParticipantSpreadsheet = readParticipantSpreadsheet;
window.createParticipantTemplate = createParticipantTemplate;

// Global modal and UI helpers
document.addEventListener('DOMContentLoaded', () => {
    // Oculta y elimina alertas temporales cinco segundos después de mostrarlas.
    const alerts = document.querySelectorAll('[data-auto-dismiss]');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.transition = 'opacity 0.5s ease-out';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        }, 5000);
    });
});

Alpine.start();
